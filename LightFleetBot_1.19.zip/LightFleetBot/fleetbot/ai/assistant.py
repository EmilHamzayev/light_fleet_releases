"""Rozmowa biura z asystentem: pytanie -> Claude wybiera czynności (tools.py) -> odpowiedź + karty do potwierdzenia.

Asystent sam niczego nie zapisuje: czynności zapisu trafiają do ai_pending i czekają na "✅" biura.
Każda rozmowa trafia do dziennika ai_log (pytanie, odpowiedź, użyte czynności, tokeny).
"""
import datetime as dt
import json
import logging
import re
import time
from dataclasses import dataclass, field

from .. import db
from . import claude as claude_mod
from . import tools

log = logging.getLogger("fleetbot.ai")
MAX_STEPS = 6  # ile razy model może sięgnąć po dane w jednej odpowiedzi
HISTORY_MESSAGES = 12
HISTORY_IDLE = 30 * 60
DAYS = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")


def reply_language(text):
    """Język odpowiedzi według liter wiadomości: cyrylica -> rosyjski / ukraiński, łacińskie -> polski, brak liter -> None.
    Model sam się myli, gdy w rozmowie mieszają się języki i polskie nazwiska, więc mówimy mu to wprost."""
    cyr = re.findall(r"[а-яёіїєґ]", (text or "").lower())
    if cyr:  # nawet jedna litera («а Anosov?») - Polak nie pisze cyrylicą
        return "Ukrainian" if set(cyr) & set("іїєґ") else "Russian"
    return "Polish" if re.search(r"[a-ząćęłńóśźż]{2}", (text or "").lower()) else None


def plain(text):
    """Telegram pokazuje tekst bez formatowania - usuwamy znaczniki Markdown, gdyby model ich użył."""
    text = re.sub(r"\*\*(.+?)\*\*", r"\1", text or "", flags=re.S)
    text = re.sub(r"(?m)^#{1,6}\s+", "", text)
    return text.replace("`", "").strip()


@dataclass
class Reply:
    text: str = ""
    pending: list = field(default_factory=list)  # [{'id', 'action', 'args'}] - karty do potwierdzenia
    error: str | None = None  # klucz i18n, gdy asystent nie odpowiedział


class Assistant:
    def __init__(self, claude, system, daily_tokens=300000, vision_model=None):
        self.claude = claude
        self.vision_model = vision_model  # model do zdjęć i PDF (dokładniejszy odczyt dokumentów)
        self.system = system
        self.daily_tokens = daily_tokens
        self.history = {}  # telegram_id -> (czas, [wiadomości tekstowe])

    def _past(self, uid):
        at, msgs = self.history.get(uid, (0, []))
        return list(msgs) if time.monotonic() - at < HISTORY_IDLE else []

    def _remember(self, uid, msgs):
        msgs = msgs[-HISTORY_MESSAGES:]
        while msgs and msgs[0]["role"] != "user":  # rozmowa musi zaczynać się od wiadomości biura
            msgs = msgs[1:]
        self.history[uid] = (time.monotonic(), msgs)

    def note(self, uid, text):
        """Informacja dla modelu o tym, co stało się poza rozmową (np. biuro nacisnęło "✅")."""
        self._remember(uid, self._past(uid) + [{"role": "user", "content": "[%s]" % text}])

    async def reply(self, uid, text, now=None, media=None, default_lang=None):
        """media: bloki obrazu / PDF (zdjęcie dokumentu z Telegrama); default_lang - gdy wiadomość nie ma tekstu."""
        now = now or dt.datetime.now()
        if self.daily_tokens and await db.call(db.core.ai_tokens_today) >= self.daily_tokens:
            return Reply(error="ai_limit")
        lang = reply_language(text) or default_lang
        model = (self.vision_model if media else None) or self.claude.model
        stamp = "[%s %s%s]" % (now.strftime("%Y-%m-%d %H:%M"), DAYS[now.weekday()], "; reply in %s" % lang if lang else "")
        past = self._past(uid)
        shown = "%s\n%s" % (stamp, text or "(bez podpisu - biuro przysłało sam dokument)")
        content = list(media) + [{"type": "text", "text": shown}] if media else shown
        messages = past + [{"role": "user", "content": content}]
        text = ("[dokument] " + text).strip() if media else text  # do dziennika i pamięci rozmowy - bez samego pliku
        calls, pending, tin, tout, answer, err = [], [], 0, 0, "", None
        try:
            for _ in range(MAX_STEPS):
                resp = await self.claude.ask(self.system, tools.TOOLS, messages, model)
                a, b = claude_mod.usage(resp)
                tin, tout = tin + a, tout + b
                if resp.stop_reason == "refusal":
                    err = "refusal"
                    break
                uses = [x for x in resp.content if x.type == "tool_use"]
                answer = plain("\n".join(x.text for x in resp.content if x.type == "text"))
                if resp.stop_reason != "tool_use" or not uses:
                    break
                messages.append({"role": "assistant", "content": resp.content})
                results = []
                for u in uses:
                    results.append(await self._run(uid, u, calls, pending))
                messages.append({"role": "user", "content": results})
            else:
                err = "too_many_steps"
        except db.DbUnavailable:
            raise
        except Exception as e:
            key = claude_mod.error_key(e)
            log.error("Asystent: błąd Claude (%s): %s", type(e).__name__, e)
            await self._log(uid, text, "", calls, tin, tout, "%s: %s" % (type(e).__name__, e), model)
            if key is None:
                raise
            return Reply(pending=pending, error=key)
        await self._log(uid, text, answer, calls, tin, tout, err, model)
        if not answer and not pending:
            return Reply(error="ai_empty")
        self._remember(uid, past + [{"role": "user", "content": text}, {"role": "assistant", "content": answer or "(karta)"}])
        return Reply(text=answer, pending=pending)

    async def _run(self, uid, use, calls, pending):
        """Jedna czynność na życzenie modelu -> blok tool_result."""
        args = use.input if isinstance(use.input, dict) else {}
        calls.append({"name": use.name, "args": args})
        try:
            out = await db.call(tools.run, use.name, args, uid)
        except db.core.UserError as e:
            return {"type": "tool_result", "tool_use_id": use.id, "content": str(e), "is_error": True}
        if isinstance(out, dict) and out.get("pending_id"):
            pending.append({"id": out["pending_id"], "action": use.name, "args": out["prepared"]})
        return {"type": "tool_result", "tool_use_id": use.id, "content": json.dumps(out, ensure_ascii=False, default=str)}

    async def _log(self, uid, question, answer, calls, tin, tout, error, model=None):
        try:
            await db.call(db.core.ai_log_add, uid, model or self.claude.model, question, answer, calls, tin, tout, error)
        except db.DbUnavailable:
            log.warning("Asystent: nie zapisano dziennika (baza niedostępna)")


def build(cfg):
    """Asystent z ustawień albo None (brak klucza = bot działa jak dotąd, bez AI)."""
    if not cfg.anthropic_key:
        return None
    from . import persona
    from .. import kasa
    from ..config import ROOT
    if cfg.google_key and cfg.google_key.exists():  # arkusz KASA biura - tym samym kontem usługi co arkusz rozliczeń
        tools.KASA_READER = kasa.Reader(cfg.google_key, cfg.kasa_sheet_id)
    return Assistant(claude_mod.Claude(cfg.anthropic_key, cfg.ai_model, cfg.ai_effort), persona.load(ROOT), cfg.ai_daily_tokens,
                     cfg.ai_vision_model)
