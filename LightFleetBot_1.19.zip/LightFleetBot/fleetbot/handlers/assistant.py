"""Asystent AI w czacie biura: zwykła wiadomość -> odpowiedź; zapis tylko po "✅" na karcie.

Wiadomość trafia tu z office.search, gdy nie jest numerem rejestracyjnym ani imieniem kierowcy (te dają kartę od razu,
bez AI). Bez klucza ANTHROPIC_API_KEY asystenta nie ma i bot działa jak dotąd.
"""
import base64
import datetime as dt
import logging

from aiogram import F, Router
from aiogram.types import CallbackQuery, Message

from .. import db
from ..ai import tools
from ..i18n import t
from ..outbox import keyboard

log = logging.getLogger("fleetbot.assistant")
router = Router()
STATE_KEYS = {"done": "ai_done", "cancelled": "ai_cancelled", "expired": "ai_expired", "gone": "ai_expired"}


def _zl(n):
    return ("{:,.2f}".format(n or 0)).replace(",", " ").replace(".", ",").replace(",00", "") + " zł"


def _dmy(s):
    return "%s.%s.%s" % (s[8:10], s[5:7], s[:4]) if s else "—"


def _week(week):
    sun = (dt.date.fromisoformat(week) + dt.timedelta(days=6)).isoformat()
    return "%s – %s" % (_dmy(week)[:5], _dmy(sun)[:5])


def card_text(action, a, lang):
    """Tekst karty z danych sprawdzonych przez tools (nie z tekstu modelu)."""
    if action == "record_cash":
        text = t(lang, "ai_card_cash" if a["kind"] == "cash" else "ai_card_invoice", name=a["name"], sum=_zl(a["amount"]),
                 week=_week(a["week"]))
        return text + ("\n📝 " + a["note"] if a.get("note") else "")
    if action == "set_document_date":
        return t(lang, "ai_card_doc", plate=a["plate"], doc=a["label"], date=_dmy(a["date"]), old=_dmy(a.get("old")))
    if action == "add_car_note":
        return t(lang, "ai_card_note", plate=a["plate"], text=a["text"])
    if action == "set_mileage":
        return t(lang, "ai_card_mileage", plate=a["plate"], km=_km(a["km"]), old=_km(a["old"]) if a.get("old") else "—")
    if action == "add_repair":
        text = t(lang, "ai_card_repair", plate=a["plate"], text=a["text"])
        return text + ("\n" + t(lang, "ai_card_repair_cost", sum=_zl(a["cost"])) if a.get("cost") else "")
    if action == "record_rent_payment":
        text = t(lang, "ai_card_rent", plate=a["plate"], driver=a["driver"], sum=_zl(a["amount"]), week=_week(a["week"]))
        return text + ("\n📝 " + a["comment"] if a.get("comment") else "")
    if action == "save_car_from_document":
        kind = t(lang, "kind_fleet") + (" · " + a["city"] if a.get("city") else "") if a.get("kind") == "fleet" else t(lang, "kind_rent")
        lines = [t(lang, "ai_card_car_new", plate=a["plate"], kind=kind) if a.get("new") else t(lang, "ai_card_car_fill", plate=a["plate"])]
        for key, val in a["set"].items():
            show = _dmy(val) if key.endswith("_until") else str(val)
            old = a.get("old", {}).get(key)
            was = " (%s)" % t(lang, "ai_was", old=_dmy(old) if key.endswith("_until") else old) if old else ""
            lines.append("%s: %s%s" % (t(lang, "ai_f_" + key), show, was))
        return "\n".join(lines)
    return action


def _km(n):
    return "{:,}".format(int(n)).replace(",", " ")


def card_buttons(pid, lang):
    return [[[t(lang, "ai_btn_ok"), "ai:ok:%d" % pid], [t(lang, "ai_btn_no"), "ai:no:%d" % pid]]]


LANG_NAMES = {"pl": "Polish", "ru": "Russian", "uk": "Ukrainian"}
IMAGE_TYPES = ("image/jpeg", "image/png", "image/webp", "image/gif")
MAX_FILE = 8 * 1024 * 1024


async def talk(message: Message, lang: str, ai, media=None):
    """Pytanie biura do asystenta (media - zdjęcie albo PDF dokumentu)."""
    await message.bot.send_chat_action(message.chat.id, "typing")
    text = (message.text or message.caption or "").strip()
    try:
        if media:
            r = await ai.reply(message.from_user.id, text, media=media, default_lang=LANG_NAMES.get(lang))
        else:
            r = await ai.reply(message.from_user.id, text)
    except db.DbUnavailable:
        return await message.answer(t(lang, "db_unavailable"))
    except Exception:
        log.exception("Asystent: nieoczekiwany błąd")
        return await message.answer(t(lang, "ai_unavailable"))
    if r.text:
        await message.answer(r.text)
    for p in r.pending:
        await message.answer(card_text(p["action"], p["args"], lang) + "\n\n" + t(lang, "ai_card_ask"),
                             reply_markup=keyboard(card_buttons(p["id"], lang)))
    if r.error:
        await message.answer(t(lang, r.error))


def media_block(mime, data):
    """Blok dla Claude: obraz albo PDF (base64). Pliku nie zapisujemy na dysku."""
    b64 = base64.standard_b64encode(data).decode("ascii")
    if mime == "application/pdf":
        return {"type": "document", "source": {"type": "base64", "media_type": mime, "data": b64}}
    return {"type": "image", "source": {"type": "base64", "media_type": mime, "data": b64}}


@router.message(F.chat.type == "private", F.photo | F.document)
async def document(message: Message, is_office: bool, lang: str, ai=None):
    """Biuro przysyła zdjęcie albo plik (dowód rejestracyjny, polisa OC) - asystent czyta i przygotowuje kartę."""
    if not is_office:
        return await message.answer(t(lang, "help_driver"))
    if ai is None:
        return await message.answer(t(lang, "ai_photo_off"))
    if message.photo:
        f, mime = message.photo[-1], "image/jpeg"  # największy rozmiar
    else:
        f, mime = message.document, (message.document.mime_type or "").lower()
        if mime not in IMAGE_TYPES + ("application/pdf",):
            return await message.answer(t(lang, "ai_file_type"))
    if (f.file_size or 0) > MAX_FILE:
        return await message.answer(t(lang, "ai_file_big"))
    try:
        buf = await message.bot.download(f.file_id)
        data = buf.read()
    except Exception:
        log.exception("Asystent: nie udało się pobrać pliku z Telegrama")
        return await message.answer(t(lang, "ai_unavailable"))
    log.info("Dokument od %s: %s, %d bajtów", message.from_user.id, mime, len(data))
    await talk(message, lang, ai, media=[media_block(mime, data)])


@router.callback_query(F.data.startswith("ai:"))
async def decide(cb: CallbackQuery, is_office: bool, lang: str, ai=None):
    if not is_office:
        return await cb.answer()
    try:
        _, what, pid = cb.data.split(":")
        r = await db.call(tools.confirm if what == "ok" else tools.cancel, int(pid), cb.from_user.id)
    except db.DbUnavailable:
        return await cb.answer(t(lang, "db_unavailable"), show_alert=True)
    except ValueError:
        return await cb.answer()
    await cb.answer()
    state = r["state"]
    status = t(lang, "ai_failed", error=r.get("error") or "") if state == "failed" else t(lang, STATE_KEYS.get(state, "ai_expired"))
    card = card_text(r["action"], r["args"], lang) if r.get("action") else ""
    log.info("Asystent: karta %s -> %s (%s)", pid, state, cb.from_user.id)
    if ai is not None and r.get("action") and state in ("done", "cancelled", "failed"):
        ai.note(cb.from_user.id, "biuro: %s -> %s" % (card.replace("\n", ", "), status))
    try:
        await cb.message.edit_text((card + "\n\n" + status).strip())
    except Exception:  # wiadomość za stara do edycji - wyślij nową
        await cb.message.answer((card + "\n\n" + status).strip())
