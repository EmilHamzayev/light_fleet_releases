"""Asystent AI biura: czynności (tools), potwierdzanie zapisu, rozmowa z udawanym Claude (bez internetu i bez klucza)."""
import asyncio
import base64
import io
import json
import unittest
from pathlib import Path
from types import SimpleNamespace

from base import FleetTest, core, day

try:
    from fleetbot import config, db
    from fleetbot.ai import assistant, claude, persona, tools
    from fleetbot.handlers import assistant as cards
    from fleetbot.handlers import office
    from fleetbot.i18n import t
except ImportError:  # biblioteki bota są w .venv
    db = None

OFFICE = 6936017050


def text(s):
    return SimpleNamespace(type="text", text=s)


def use(name, args, uid="tu_1"):
    return SimpleNamespace(type="tool_use", id=uid, name=name, input=args)


def resp(*blocks, stop=None, tin=100, tout=20):
    stop = stop or ("tool_use" if any(b.type == "tool_use" for b in blocks) else "end_turn")
    return SimpleNamespace(content=list(blocks), stop_reason=stop, usage=SimpleNamespace(input_tokens=tin, output_tokens=tout))


class FakeClient:
    """Udaje anthropic.AsyncAnthropic: oddaje przygotowane odpowiedzi i zapamiętuje żądania."""

    def __init__(self, script):
        self.script = list(script)
        self.requests = []
        self.messages = self

    async def create(self, **kw):
        self.requests.append(dict(kw, messages=list(kw["messages"])))
        r = self.script.pop(0) if len(self.script) > 1 else self.script[0]
        if isinstance(r, Exception):
            raise r
        return r


@unittest.skipIf(db is None, "brak bibliotek bota (uruchom testy z .venv)")
class AiTest(FleetTest):
    def setUp(self):
        super().setUp()
        self.main_db = core.DBX
        db.configure({"mode": "local"}, Path(core.DB))
        self.car = core.save_car({"plate": "CT 4812F", "model": "Toyota Corolla", "kind": "fleet", "city": "Toruń", "oc_until": day(10)})
        self.g = core.save_driver({"name": "Gennadii Sabadash", "kind": "fleet", "city": "Toruń", "phone": "500 600 700"})
        self.a = core.save_driver({"name": "Adam Nowak", "kind": "fleet", "city": "Grudziądz"})
        core.fleet_crew_set(self.car, "day", self.g, day(-2))
        core.fleet_cash_store(day(), [(self.g, 432.38, 144), (self.a, 300, 145)])
        self.week = core.cash_view()["week"]

    def tearDown(self):
        bot_db = core.DBX
        if bot_db is not self.main_db and hasattr(bot_db, "conn"):
            db.POOL.submit(bot_db.close).result()
        core.DBX = self.main_db
        super().tearDown()

    def call(self, fn, *a):
        """Po pierwszym wywołaniu bota baza należy do wątku bota - w testach chodzimy do niej tą samą drogą."""
        return asyncio.run(db.call(fn, *a))

    def count(self, table, where="1", args=()):
        return self.call(core.q, "SELECT COUNT(*) AS n FROM %s WHERE %s" % (table, where), args)[0]["n"]

    def bot(self, *script, limit=300000):
        self.client = FakeClient(script)
        return assistant.Assistant(claude.Claude("", "claude-haiku-5-5", client=self.client), persona.load(), limit)


class ToolsTest(AiTest):
    def test_definitions_match_code(self):
        names = [x["name"] for x in tools.TOOLS]
        self.assertEqual(sorted(names), sorted(list(tools.READ) + list(tools.PREPARE)))
        self.assertEqual(set(tools.PREPARE), tools.WRITE)
        for x in tools.TOOLS:
            self.assertIs(x["input_schema"]["additionalProperties"], False)
            self.assertTrue(x["description"])

    def test_cash_status_who_owes(self):
        r = self.call(tools.run, "cash_status", {"only_debtors": True})
        self.assertEqual(r["week_monday"], self.week)
        self.assertEqual([(d["name"], d["balance"]) for d in r["drivers"]], [("Adam Nowak", 300.0), ("Gennadii Sabadash", 432.38)])
        self.assertEqual((r["total"]["still_owed"], r["total"]["drivers_owing"]), (732.38, 2))
        self.call(core.cash_add, {"driver_id": self.a, "week": self.week, "kind": "cash", "amount": 300})
        r = self.call(tools.run, "cash_status", {"only_debtors": True})
        self.assertEqual([d["name"] for d in r["drivers"]], ["Gennadii Sabadash"])
        self.assertEqual([d["name"] for d in self.call(tools.run, "cash_status", {"city": "Grudziądz"})["drivers"]], ["Adam Nowak"])

    def test_find_gives_ids_and_only_needed_fields(self):
        r = self.call(tools.run, "find", {"query": "sabadash"})
        d = r["drivers"][0]
        self.assertEqual((d["driver_id"], d["car"], d["shift"]), (self.g, "CT4812F", "day"))
        self.assertEqual(set(d), {"driver_id", "name", "kind", "city", "car", "shift", "phone", "telegram_linked"})
        c = self.call(tools.run, "find", {"query": "4812"})["cars"][0]
        self.assertEqual((c["car_id"], c["day_driver"], c["night_driver"]), (self.car, "Gennadii Sabadash", None))

    def test_other_reads(self):
        fo = self.call(tools.run, "fleet_overview", {})
        self.assertEqual((fo["free_shifts"], fo["drivers_without_car"]), (1, ["Adam Nowak"]))
        docs = self.call(tools.run, "documents_due", {})["items"]
        self.assertIn(("CT4812F", "oc", 10), [(i["plate"], i["doc"], i["days_left"]) for i in docs])
        self.assertEqual(self.call(tools.run, "office_status", {})["rent_cars"], 4)
        self.assertUserError(lambda: self.call(tools.run, "drop_database", {}), "Nieznana czynność")

    def test_cash_is_written_only_after_confirm(self):
        r = self.call(tools.run, "record_cash", {"driver_id": self.g, "amount": 200, "kind": "cash"}, OFFICE)
        self.assertEqual(r["prepared"], {"driver_id": self.g, "name": "Gennadii Sabadash", "amount": 200.0, "kind": "cash",
                                         "week": self.week, "note": ""})
        self.assertEqual(self.count("cash_entries"), 0)
        done = self.call(tools.confirm, r["pending_id"], OFFICE)
        self.assertEqual(done["state"], "done")
        self.assertEqual(self.count("cash_entries", "driver_id=? AND kind='cash' AND amount=200", (self.g,)), 1)
        self.assertEqual(self.call(tools.confirm, r["pending_id"], OFFICE)["state"], "done")  # drugi klik
        self.assertEqual(self.call(tools.cancel, r["pending_id"], OFFICE)["state"], "done")
        self.assertEqual(self.count("cash_entries"), 1)
        p = self.call(core.q, "SELECT status, done_by FROM ai_pending WHERE id=?", (r["pending_id"],))[0]
        self.assertEqual((p["status"], p["done_by"]), ("done", OFFICE))

    def test_cancel_and_expired_write_nothing(self):
        a = self.call(tools.run, "record_cash", {"driver_id": self.g, "amount": 50, "kind": "invoice"}, OFFICE)["pending_id"]
        self.assertEqual(self.call(tools.cancel, a, OFFICE)["state"], "cancelled")
        self.assertEqual(self.call(tools.confirm, a, OFFICE)["state"], "cancelled")
        b = self.call(tools.run, "record_cash", {"driver_id": self.g, "amount": 50, "kind": "cash"}, OFFICE)["pending_id"]
        self.call(core.ex, "UPDATE ai_pending SET expires_at='2000-01-01 00:00:00' WHERE id=?", (b,))
        self.assertEqual(self.call(tools.confirm, b, OFFICE)["state"], "expired")
        self.assertEqual(self.call(tools.confirm, 999999, OFFICE)["state"], "gone")
        self.assertEqual(self.count("cash_entries"), 0)

    def test_bad_cash_is_refused_before_card(self):
        self.assertUserError(lambda: self.call(tools.run, "record_cash", {"driver_id": 99999, "amount": 10, "kind": "cash"}), "Kierowca nie istnieje")
        self.assertUserError(lambda: self.call(tools.run, "record_cash", {"driver_id": self.g, "amount": 0, "kind": "cash"}), "Podaj kwotę")
        self.assertUserError(lambda: self.call(tools.run, "record_cash", {"driver_id": self.g, "amount": 5, "kind": "gift"}), "rodzaj")
        self.assertUserError(lambda: self.call(tools.run, "record_cash", {"amount": 5, "kind": "cash"}), "parametr")
        self.assertEqual(self.count("ai_pending"), 0)

    def test_document_date(self):
        self.assertUserError(lambda: self.call(tools.run, "set_document_date", {"car_id": self.car, "doc": "oc", "date": day(-1)}), "przyszłości")
        self.assertUserError(lambda: self.call(tools.run, "set_document_date", {"car_id": self.car, "doc": "ac", "date": day(300)}), "Nieznany dokument")
        r = self.call(tools.run, "set_document_date", {"car_id": self.car, "doc": "oc", "date": day(300)}, OFFICE)
        self.assertEqual((r["prepared"]["plate"], r["prepared"]["old"], r["prepared"]["date"]), ("CT4812F", day(10), day(300)))
        self.assertEqual(self.car_row()["oc_until"], day(10))
        self.assertEqual(self.call(tools.confirm, r["pending_id"], OFFICE)["state"], "done")
        self.assertEqual(self.car_row()["oc_until"], day(300))
        self.assertEqual(self.count("doc_reminders", "car_id=? AND done_by=?", (self.car, OFFICE)), 1)

    def car_row(self):
        return self.call(core.q, "SELECT oc_until FROM cars WHERE id=?", (self.car,))[0]

    def test_rent_reads(self):
        self.call(self.assign, self.c1, self.jan, day(-5))
        cars = self.call(tools.run, "rent_cars", {})
        self.assertEqual(cars["count"], 4)  # flota (CT4812F) nie jest wynajmem
        aa = next(c for c in cars["cars"] if c["plate"] == "AA111")
        self.assertEqual((aa["driver"], aa["rent_per_week"], aa["this_week"], aa["owner"]), ("Jan Test", 600, "not paid yet", "Firma A"))
        self.assertEqual([c["plate"] for c in self.call(tools.run, "rent_cars", {"only": "with_driver"})["cars"]], ["AA111"])
        self.assertEqual(self.call(tools.run, "rent_cars", {"only": "free"})["count"], 3)
        w = self.call(tools.run, "rent_week", {})
        self.assertEqual([(c["plate"], c["driver"], c["rent"], c["paid"]) for c in w["cars"]], [("AA111", "Jan Test", 600, False)])
        self.assertEqual((w["total"]["expected"], w["total"]["waiting"]), (600, 600))
        drv = self.call(tools.run, "rent_drivers", {})["drivers"]
        self.assertEqual(next(d["car"] for d in drv if d["name"] == "Jan Test"), "AA111")
        det = self.call(tools.run, "car_details", {"car_id": self.c1})
        self.assertEqual((det["plate"], det["driver"], det["drivers_history"][0]["name"]), ("AA111", "Jan Test", "Jan Test"))
        self.assertUserError(lambda: self.call(tools.run, "car_details", {"car_id": 99999}), "nie istnieje")
        self.assertEqual(self.call(tools.run, "owner_payments", {"unpaid_only": True})["unpaid_count"], 0)

    def test_rent_writes_only_after_confirm(self):
        self.call(self.assign, self.c1, self.jan, day(-5))
        note = self.call(tools.run, "add_car_note", {"car_id": self.c1, "text": "  rysa na   zderzaku "}, OFFICE)
        km = self.call(tools.run, "set_mileage", {"car_id": self.c1, "km": 123456}, OFFICE)
        rep = self.call(tools.run, "add_repair", {"car_id": self.c1, "text": "klocki", "cost": 350}, OFFICE)
        pay = self.call(tools.run, "record_rent_payment", {"car_id": self.c1, "amount": 500, "comment": "reszta w piątek"}, OFFICE)
        self.assertEqual(note["prepared"], {"car_id": self.c1, "plate": "AA111", "text": "rysa na zderzaku"})
        self.assertEqual((pay["prepared"]["driver"], pay["prepared"]["amount"], pay["prepared"]["rent"]), ("Jan Test", 500.0, 600))
        self.assertEqual((self.count("comments", "text='rysa na zderzaku'"), self.count("repairs"), self.count("weekly", "paid=1")), (0, 0, 0))
        for p in (note, km, rep, pay):
            self.assertEqual(self.call(tools.confirm, p["pending_id"], OFFICE)["state"], "done")
        self.assertEqual(self.count("comments", "car_id=? AND text='rysa na zderzaku'", (self.c1,)), 1)
        self.assertEqual(self.call(core.q, "SELECT mileage FROM cars WHERE id=?", (self.c1,))[0]["mileage"], 123456)
        self.assertEqual(self.count("repairs", "car_id=? AND text='klocki' AND cost=350", (self.c1,)), 1)
        w = self.call(tools.run, "rent_week", {})["cars"][0]
        self.assertEqual((w["paid"], w["paid_amount"], w["comment"]), (True, 500.0, "reszta w piątek"))
        self.assertUserError(lambda: self.call(tools.run, "record_rent_payment", {"car_id": self.c1}), "już zapłacony")
        self.assertUserError(lambda: self.call(tools.run, "record_rent_payment", {"car_id": self.c2}), "nie ma kierowcy")
        self.assertUserError(lambda: self.call(tools.run, "add_car_note", {"car_id": self.c1, "text": "  "}), "Wpisz treść")
        self.assertUserError(lambda: self.call(tools.run, "set_mileage", {"car_id": self.c1, "km": "dużo"}), "Wpisz liczbę")

    def test_new_cards(self):
        self.assertEqual(cards.card_text("add_car_note", {"plate": "AA111", "text": "rysa"}, "pl"), "📝 AA111: notatka\nrysa")
        self.assertEqual(cards.card_text("set_mileage", {"plate": "AA111", "km": 123456, "old": 120000}, "ru"), "🛣 AA111: пробег 123 456 км\nБыл: 120 000")
        self.assertEqual(cards.card_text("add_repair", {"plate": "AA111", "text": "klocki", "cost": 350.0}, "pl"), "🔧 AA111: naprawa\nklocki\nKoszt: 350 zł")
        rent = {"plate": "AA111", "driver": "Jan Test", "amount": 500.0, "week": "2026-11-16", "comment": ""}
        self.assertEqual(cards.card_text("record_rent_payment", rent, "pl"), "💳 AA111 (Jan Test): wynajem 500 zł\nTydzień 16.11 – 22.11")

    def test_confirm_reports_failure(self):
        r = self.call(tools.run, "set_document_date", {"car_id": self.car, "doc": "prz", "date": day(200)}, OFFICE)
        self.call(core.ex, "UPDATE cars SET active=0 WHERE id=?", (self.car,))  # samochód trafił do archiwum przed "✅"
        out = self.call(tools.confirm, r["pending_id"], OFFICE)
        self.assertEqual((out["state"], out["error"]), ("failed", "Samochód nie istnieje."))
        self.assertEqual(self.call(core.q, "SELECT status FROM ai_pending WHERE id=?", (r["pending_id"],))[0]["status"], "failed")


class TalkTest(AiTest):
    def ask(self, bot, q):
        return asyncio.run(bot.reply(OFFICE, q))

    def test_question_uses_data_and_is_logged(self):
        bot = self.bot(resp(use("cash_status", {"only_debtors": True})), resp(text("Wiszą dwaj: Sabadash 432,38 zł i Nowak 300 zł.")))
        r = self.ask(bot, "Привет, кто ещё не сдал наличку?")
        self.assertEqual((r.text, r.pending, r.error), ("Wiszą dwaj: Sabadash 432,38 zł i Nowak 300 zł.", [], None))
        first, second = self.client.requests
        self.assertEqual((first["model"], first["output_config"]), ("claude-haiku-5-5", {"effort": "low"}))
        self.assertEqual([x["name"] for x in first["tools"]], [x["name"] for x in tools.TOOLS])
        self.assertIn("третий сотрудник", first["system"][0]["text"])
        self.assertNotIn("temperature", first)
        self.assertTrue(first["messages"][-1]["content"].endswith("Привет, кто ещё не сдал наличку?"))
        result = second["messages"][-1]["content"][0]
        self.assertEqual((result["type"], result["tool_use_id"]), ("tool_result", "tu_1"))
        self.assertEqual(json.loads(result["content"])["total"]["still_owed"], 732.38)
        row = self.call(core.q, "SELECT telegram_id, model, question, answer, tools, tokens_in, tokens_out, error FROM ai_log")[0]
        self.assertEqual((row["telegram_id"], row["tokens_in"], row["tokens_out"], row["error"]), (OFFICE, 200, 40, None))
        self.assertEqual(json.loads(row["tools"]), [{"name": "cash_status", "args": {"only_debtors": True}}])

    def test_markdown_is_removed(self):
        self.assertEqual(assistant.plain("## Lista\nNowak **300 zł**, kod `AB1` * gwiazdka"), "Lista\nNowak 300 zł, kod AB1 * gwiazdka")
        self.assertEqual(self.ask(self.bot(resp(text("Wisi **48,88 zł**."))), "ile?").text, "Wisi 48,88 zł.")

    def test_reply_language_is_told_to_the_model(self):
        for q, lang in (("а Зофья сдала?", "Russian"), ("Kondziela сдал 500", "Russian"), ("а Anosov?", "Russian"), ("a Anosov?", "Polish"), ("хто ще не здав готівку?", "Ukrainian"),
                        ("Kasia, ile brakuje z Grudziądza?", "Polish"), ("BI062YR", "Polish"), ("500", None), ("👍", None)):
            self.assertEqual(assistant.reply_language(q), lang, q)
        bot = self.bot(resp(text("ok")))
        self.ask(bot, "а Зофья сдала?")
        self.ask(bot, "Kasia, ile brakuje?")
        first = self.client.requests[0]["messages"][-1]["content"].split("\n")[0]
        second = self.client.requests[1]["messages"][-1]["content"].split("\n")[0]
        self.assertTrue(first.endswith("; reply in Russian]") and second.endswith("; reply in Polish]"), (first, second))

    def test_remembers_conversation(self):
        bot = self.bot(resp(text("Cześć!")), resp(text("Nadal ja.")))
        self.ask(bot, "hej")
        self.ask(bot, "a kto pyta?")
        msgs = self.client.requests[1]["messages"]
        self.assertEqual([m["role"] for m in msgs], ["user", "assistant", "user"])
        self.assertEqual((msgs[0]["content"], msgs[1]["content"]), ("hej", "Cześć!"))
        bot.note(OFFICE, "biuro: zapisano")
        self.assertEqual(bot._past(OFFICE)[-1], {"role": "user", "content": "[biuro: zapisano]"})

    def test_write_gives_card_and_saves_nothing(self):
        bot = self.bot(resp(use("record_cash", {"driver_id": self.g, "amount": 500, "kind": "cash"})),
                       resp(text("Przygotowałem, sprawdź kartę.")))
        r = self.ask(bot, "Sabadash oddał 500")
        self.assertEqual(r.text, "Przygotowałem, sprawdź kartę.")
        self.assertEqual([(p["action"], p["args"]["name"], p["args"]["amount"]) for p in r.pending], [("record_cash", "Gennadii Sabadash", 500.0)])
        self.assertEqual(self.count("cash_entries"), 0)
        self.assertIn("NIE zapisano", self.client.requests[1]["messages"][-1]["content"][0]["content"])

    def test_tool_error_goes_back_to_model(self):
        bot = self.bot(resp(use("record_cash", {"driver_id": 99999, "amount": 5, "kind": "cash"})), resp(text("Nie ma takiego kierowcy.")))
        r = self.ask(bot, "ktoś oddał 5")
        result = self.client.requests[1]["messages"][-1]["content"][0]
        self.assertEqual((result["is_error"], result["content"]), (True, "Kierowca nie istnieje."))
        self.assertEqual((r.text, r.pending), ("Nie ma takiego kierowcy.", []))

    def test_daily_limit_stops_before_claude(self):
        self.call(core.ai_log_add, OFFICE, "m", "q", "a", None, 900, 200)
        self.assertEqual(self.call(core.ai_tokens_today), 1100)
        bot = self.bot(resp(text("x")), limit=1000)
        self.assertEqual(self.ask(bot, "hej").error, "ai_limit")
        self.assertEqual(self.client.requests, [])
        self.assertIsNone(self.ask(self.bot(resp(text("x")), limit=0), "hej").error)  # 0 = bez limitu

    def test_endless_tool_calls_and_refusal_end_politely(self):
        bot = self.bot(resp(use("documents_due", {})))
        self.assertEqual(self.ask(bot, "pętla").error, "ai_empty")
        self.assertEqual(len(self.client.requests), assistant.MAX_STEPS)
        self.assertEqual(self.ask(self.bot(resp(stop="refusal")), "x").error, "ai_empty")
        self.assertEqual(self.call(core.q, "SELECT error FROM ai_log ORDER BY id DESC LIMIT 1")[0]["error"], "refusal")

    def test_claude_errors_become_office_texts(self):
        import anthropic
        req = SimpleNamespace(method="POST", url="https://api.anthropic.com/v1/messages")
        down = anthropic.APIConnectionError(request=req)
        self.assertEqual(claude.error_key(down), "ai_unavailable")
        self.assertIsNone(claude.error_key(ValueError("x")))
        r = self.ask(self.bot(down), "hej")
        self.assertEqual((r.text, r.error), ("", "ai_unavailable"))
        self.assertIn("APIConnectionError", self.call(core.q, "SELECT error FROM ai_log")[0]["error"])
        for lang in ("pl", "ru", "uk"):
            for key in ("ai_unavailable", "ai_busy", "ai_key_bad", "ai_no_credit", "ai_limit", "ai_empty"):
                self.assertTrue(t(lang, key))


class CardsTest(AiTest):
    def test_card_texts(self):
        cash = {"name": "Gennadii Sabadash", "amount": 500.0, "kind": "cash", "week": "2026-11-02", "note": "bez faktur"}
        self.assertEqual(cards.card_text("record_cash", cash, "pl"), "💵 Gennadii Sabadash: gotówka 500 zł\nTydzień 02.11 – 08.11\n📝 bez faktur")
        self.assertIn("фактуры 1 234,50 zł", cards.card_text("record_cash", dict(cash, kind="invoice", amount=1234.5, note=""), "ru"))
        doc = {"plate": "CT4812F", "label": "OC", "date": "2027-11-15", "old": None}
        self.assertEqual(cards.card_text("set_document_date", doc, "pl"), "📄 CT4812F: OC ważne do 15.11.2027\nByło: —")
        self.assertEqual(cards.card_buttons(7, "pl"), [[["✅ Zapisz", "ai:ok:7"], ["✖ Anuluj", "ai:no:7"]]])

    def message(self, txt):
        sent = []

        async def answer(text_, reply_markup=None):
            sent.append(text_)

        async def action(chat_id, what):
            sent.append("<%s>" % what)
        return SimpleNamespace(text=txt, from_user=SimpleNamespace(id=OFFICE), chat=SimpleNamespace(id=OFFICE, type="private"),
                               answer=answer, bot=SimpleNamespace(send_chat_action=action)), sent

    def test_plate_and_name_stay_instant_other_text_goes_to_ai(self):
        bot = self.bot(resp(text("Cześć, jestem.")))
        m, sent = self.message("sabadash")
        asyncio.run(office.search(m, True, "pl", ai=bot))
        self.assertIn("👤 Gennadii Sabadash", sent[0])
        self.assertEqual(self.client.requests, [])
        m, sent = self.message("hej, jesteś?")
        asyncio.run(office.search(m, True, "pl", ai=bot))
        self.assertEqual(sent, ["<typing>", "Cześć, jestem."])
        m, sent = self.message("hej, jesteś?")
        asyncio.run(office.search(m, True, "pl"))  # bez klucza - jak dotąd
        self.assertEqual(sent, [t("pl", "search_none", q="hej, jesteś?")])
        m, sent = self.message("hej")
        asyncio.run(office.search(m, False, "pl", ai=bot))  # kierowca nie rozmawia z asystentem
        self.assertEqual(sent, [t("pl", "help_driver")])

    def test_card_is_sent_with_question(self):
        bot = self.bot(resp(use("record_cash", {"driver_id": self.g, "amount": 500, "kind": "cash"})), resp(text("Sprawdź kartę.")))
        m, sent = self.message("Sabadash oddał 500 zł gotówki")
        asyncio.run(office.search(m, True, "pl", ai=bot))
        self.assertEqual(sent[1], "Sprawdź kartę.")
        self.assertTrue(sent[2].startswith("💵 Gennadii Sabadash: gotówka 500 zł"))
        self.assertTrue(sent[2].endswith("Zapisać?"))


class CarDocumentTest(AiTest):
    """Zdjęcie dowodu rejestracyjnego / polisy: uzupełnienie samochodu albo nowy samochód, zawsze przez kartę."""

    def doc(self, **a):
        return self.call(tools.run, "save_car_from_document", a, OFFICE)

    def car_row(self, plate):
        return dict(self.call(core.q, "SELECT * FROM cars WHERE plate=?", (plate,))[0])

    def test_existing_car_gets_only_missing_fields_and_newer_dates(self):
        self.call(core.ex, "UPDATE cars SET year=2014, oc_until=?, przeglad_until=? WHERE id=?", (day(200), day(5), self.c1))
        r = self.doc(plate="aa 111", model="TOYOTA PRIUS", year=2015, fuel="Hybryda", przeglad_until=day(370), oc_until=day(100))
        p = r["prepared"]
        self.assertEqual((p["new"], p["car_id"], p["plate"]), (False, self.c1, "AA111"))
        self.assertEqual(p["set"], {"fuel": "Hybryda", "przeglad_until": day(370)})  # puste paliwo + nowszy przegląd
        self.assertEqual(p["old"], {"przeglad_until": day(5)})
        self.assertEqual(set(p["kept"]), {"model", "year", "oc_until"})  # różnice zostają jak w programie
        self.assertIsNone(self.car_row("AA111")["fuel"])
        self.assertEqual(self.call(tools.confirm, r["pending_id"], OFFICE)["state"], "done")
        row = self.car_row("AA111")
        self.assertEqual((row["fuel"], row["przeglad_until"], row["year"], row["model"], row["oc_until"]),
                         ("Hybryda", day(370), 2014, "Toyota Prius 30", day(200)))
        self.assertEqual(self.count("comments", "car_id=? AND text LIKE 'Z dokumentu: paliwo Hybryda, przegląd do %'", (self.c1,)), 1)
        self.assertUserError(lambda: self.doc(plate="AA111", fuel="Hybryda", przeglad_until=day(370)), "nie ma czego uzupełniać")

    def test_new_car_needs_kind_then_is_created(self):
        self.assertUserError(lambda: self.doc(plate="CT 9999X", model="Toyota Corolla"), "nie ma w programie")
        self.assertUserError(lambda: self.doc(plate="CT9999X", model="Toyota Corolla", kind="fleet"), "podaj miasto")
        self.assertUserError(lambda: self.doc(plate="CT9999X", kind="rent"), "markę i model")
        r = self.doc(plate="CT 9999X", model="Toyota Corolla", year=2019, fuel="Hybryda", przeglad_until=day(300), kind="fleet", city="Toruń")
        self.assertEqual((r["prepared"]["new"], r["prepared"]["plate"], r["prepared"]["city"]), (True, "CT9999X", "Toruń"))
        self.assertEqual(self.count("cars", "plate='CT9999X'"), 0)
        self.assertEqual(self.call(tools.confirm, r["pending_id"], OFFICE)["state"], "done")
        row = self.car_row("CT9999X")
        self.assertEqual((row["model"], row["year"], row["fuel"], row["przeglad_until"], row["kind"], row["city"], row["active"]),
                         ("Toyota Corolla", 2019, "Hybryda", day(300), "fleet", "Toruń", 1))
        self.assertEqual(self.count("comments", "car_id=? AND text LIKE 'Dodano z dokumentu%'", (row["id"],)), 1)

    def test_bad_values_are_refused(self):
        self.assertUserError(lambda: self.doc(plate="AA"), "numer rejestracyjny")
        self.assertUserError(lambda: self.doc(plate="AA111", year=1800), "rok")
        self.assertUserError(lambda: self.doc(plate="AA111", fuel="Woda"), "Paliwo")
        self.assertUserError(lambda: self.doc(plate="AA111", przeglad_until="kiedyś"), "Nieprawidłowa data")
        self.call(core.ex, "UPDATE cars SET active=0 WHERE id=?", (self.c2,))
        self.assertUserError(lambda: self.doc(plate="BB222", fuel="Diesel"), "w archiwum")
        self.assertEqual(self.count("ai_pending"), 0)

    def test_cards(self):
        fill = {"new": False, "plate": "AA111", "kind": "rent", "set": {"fuel": "Hybryda", "przeglad_until": "2027-05-14"},
                "old": {"przeglad_until": "2026-05-14"}}
        self.assertEqual(cards.card_text("save_car_from_document", fill, "pl"),
                         "🚗 AA111: uzupełnić dane\nPaliwo: Hybryda\nPrzegląd do: 14.05.2027 (było: 14.05.2026)")
        new = {"new": True, "plate": "CT9999X", "kind": "fleet", "city": "Toruń", "set": {"model": "Toyota Corolla", "year": 2019}, "old": {}}
        self.assertEqual(cards.card_text("save_car_from_document", new, "ru"), "🚗 CT9999X: новая машина · Флот · Toruń\nМодель: Toyota Corolla\nГод: 2019")

    def test_photo_goes_to_vision_model_and_is_not_kept(self):
        bot = self.bot(resp(use("save_car_from_document", {"plate": "AA111", "fuel": "Hybryda"})), resp(text("Sprawdź kartę.")))
        bot.vision_model = "claude-sonnet-5-5"
        block = cards.media_block("image/jpeg", b"\xff\xd8zdjecie")
        r = asyncio.run(bot.reply(OFFICE, "", media=[block], default_lang="Polish"))
        self.assertEqual([p["action"] for p in r.pending], ["save_car_from_document"])
        first = self.client.requests[0]
        self.assertEqual(first["model"], "claude-sonnet-5-5")
        content = first["messages"][-1]["content"]
        self.assertEqual((content[0]["type"], content[0]["source"]["media_type"], content[1]["type"]), ("image", "image/jpeg", "text"))
        self.assertIn("reply in Polish", content[1]["text"])
        self.assertEqual(bot._past(OFFICE)[0], {"role": "user", "content": "[dokument]"})  # w pamięci tylko znacznik, bez pliku
        row = self.call(core.q, "SELECT model, question FROM ai_log")[0]
        self.assertEqual((row["model"], row["question"]), ("claude-sonnet-5-5", "[dokument]"))
        self.ask2(bot, "hej")
        self.assertEqual(self.client.requests[-1]["model"], "claude-haiku-5-5")  # zwykły tekst - zwykły model
        pdf = cards.media_block("application/pdf", b"%PDF")
        self.assertEqual((pdf["type"], pdf["source"]["media_type"]), ("document", "application/pdf"))

    def ask2(self, bot, q):
        return asyncio.run(bot.reply(OFFICE, q))

    def test_telegram_photo_and_wrong_file(self):
        bot = self.bot(resp(text("To nie wygląda na dokument samochodu.")))
        sent = []

        async def answer(text_, reply_markup=None):
            sent.append(text_)

        async def action(chat_id, what):
            sent.append("<%s>" % what)

        async def download(file_id):
            return io.BytesIO(b"\xff\xd8" + file_id.encode())

        def msg(**kw):
            base = dict(text=None, caption=None, photo=None, document=None, from_user=SimpleNamespace(id=OFFICE),
                        chat=SimpleNamespace(id=OFFICE, type="private"), answer=answer,
                        bot=SimpleNamespace(send_chat_action=action, download=download))
            base.update(kw)
            return SimpleNamespace(**base)
        photo = [SimpleNamespace(file_id="small", file_size=1000), SimpleNamespace(file_id="big", file_size=90000)]
        asyncio.run(cards.document(msg(photo=photo, caption="co to?"), True, "pl", ai=bot))
        self.assertEqual(sent, ["<typing>", "To nie wygląda na dokument samochodu."])
        block = self.client.requests[0]["messages"][-1]["content"][0]
        self.assertEqual(base64.standard_b64decode(block["source"]["data"]), b"\xff\xd8big")  # największe zdjęcie
        del sent[:]
        asyncio.run(cards.document(msg(document=SimpleNamespace(file_id="x", file_size=10, mime_type="application/zip")), True, "pl", ai=bot))
        asyncio.run(cards.document(msg(document=SimpleNamespace(file_id="x", file_size=9 * 1024 * 1024, mime_type="application/pdf")), True, "pl", ai=bot))
        asyncio.run(cards.document(msg(photo=photo), True, "pl"))
        asyncio.run(cards.document(msg(photo=photo), False, "pl", ai=bot))
        self.assertEqual(sent, [t("pl", "ai_file_type"), t("pl", "ai_file_big"), t("pl", "ai_photo_off"), t("pl", "help_driver")])
        self.assertEqual(len(self.client.requests), 1)


@unittest.skipIf(db is None, "brak bibliotek bota (uruchom testy z .venv)")
class AiConfigTest(unittest.TestCase):
    def env(self, **kw):
        return lambda k, d="": kw.get(k, d)

    def test_no_key_means_off(self):
        self.assertEqual(config._ai(self.env()), {})
        self.assertIsNone(assistant.build(SimpleNamespace(anthropic_key="")))

    def test_settings(self):
        c = config._ai(self.env(ANTHROPIC_API_KEY="k"))
        self.assertEqual((c["ai_model"], c["ai_effort"], c["ai_daily_tokens"]), ("claude-haiku-5-5", "low", 300000))
        c = config._ai(self.env(ANTHROPIC_API_KEY="k", AI_MODEL="claude-sonnet-5-5", AI_DAILY_TOKENS="0", AI_EFFORT="medium"))
        self.assertEqual((c["ai_model"], c["ai_effort"], c["ai_daily_tokens"]), ("claude-sonnet-5-5", "medium", 0))
        with self.assertRaises(config.ConfigError):
            config._ai(self.env(ANTHROPIC_API_KEY="k", AI_DAILY_TOKENS="dużo"))
        with self.assertRaises(config.ConfigError):
            config._ai(self.env(ANTHROPIC_API_KEY="k", AI_EFFORT="turbo"))

    def test_own_persona_file(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            self.assertIn("третий сотрудник", persona.load(d))
            (Path(d) / "persona.txt").write_text("Jesteś Zosia z biura.", encoding="utf-8")
            p = persona.load(d)
            self.assertTrue(p.startswith("Jesteś Zosia z biura."))
            self.assertIn("только из инструментов", p)  # zasady zostają
            self.assertIn("Natalia Lewandowska", p)  # imię jest w zasadach - własny charakter go nie zmienia


if __name__ == "__main__":
    unittest.main()
