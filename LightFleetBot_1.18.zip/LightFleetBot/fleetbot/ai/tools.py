"""Czynności asystenta = gotowe funkcje fleet_core (asystent sam nie pisze SQL i nie zapisuje do bazy).

Odczyt (READ) - wykonywany od razu, do modelu wracają tylko potrzebne pola (RODO).
Zapis (WRITE) - tylko przygotowanie: sprawdzenie danych i wpis do ai_pending; wykonanie w `confirm` po "✅" biura.
Wszystkie funkcje są synchroniczne - bot wywołuje je przez db.call (wątek bazy).
"""
import datetime as dt

from ..db import core

CITIES = ["Toruń", "Grudziądz"]


def _schema(props, required=()):
    return {"type": "object", "properties": props, "required": list(required), "additionalProperties": False}


TOOLS = [
    {"name": "cash_status",
     "description": "Gotówka kierowców floty za tydzień WEDŁUG PROGRAMU: ile kto ma oddać i co biuro wpisało w programie "
                    "(saldo z poprzednich tygodni wliczone). Biuro zwykle zapisuje wpłaty w arkuszu KASA, a nie w programie, "
                    "więc na pytanie kto oddał / nie oddał użyj cash_reconcile; to narzędzie - gdy pytają o kwoty do oddania "
                    "albo gdy KASA jest niedostępna. Bez week - ostatni tydzień z danymi. balance > 0 = jeszcze do oddania.",
     "input_schema": _schema({"week": {"type": "string", "description": "Dowolny dzień tygodnia, RRRR-MM-DD"},
                              "city": {"type": "string", "enum": CITIES},
                              "only_debtors": {"type": "boolean", "description": "Tylko ci, którzy mają jeszcze coś do oddania"}})},
    {"name": "cash_reconcile",
     "description": "Kto oddał gotówkę, a kto jeszcze wisi. ZASADA BIURA: gotówkę zebraną w tygodniu (pon-nd) kierowcy "
                    "przynoszą w NASTĘPNYM tygodniu; biuro wpisuje wpłatę do arkusza KASA z datą przyniesienia. Wpłata z "
                    "16.11 pomniejsza więc kwotę za tydzień 09.11-15.11. Narzędzie samo to liczy: do oddania za tydzień "
                    "zbierania minus wpłaty z KASA z kolejnych 7 dni. Zwykle wywołuj BEZ parametrów - dostaniesz ostatni "
                    "zakończony tydzień (ten, za który teraz przynoszą). collected_week podawaj tylko, gdy pytają o starszy "
                    "tydzień, i jest to tydzień ZBIERANIA, nie dzień wpłaty. still_owed_from_week_before = zaległości z "
                    "tygodnia wcześniej. Grudziądz biuro wpisuje jedną kwotą (GRDZ) - tam nie wiadomo, kto oddał. "
                    "matched_by='part' = wpis tylko z imieniem albo nazwiskiem, dopasowanie prawdopodobne.",
     "input_schema": _schema({"collected_week": {"type": "string", "description": "Dowolny dzień tygodnia, w którym zbierano gotówkę, RRRR-MM-DD"},
                              "city": {"type": "string", "enum": CITIES}})},
    {"name": "find",
     "description": "Szukaj samochodu po numerze rejestracyjnym (także fragment) albo kierowcy po imieniu / nazwisku. Zwraca "
                    "id potrzebne w innych czynnościach, samochód, zmianę, daty OC i przeglądu, telefon kierowcy.",
     "input_schema": _schema({"query": {"type": "string", "description": "Numer rejestracyjny albo imię / nazwisko, min. 3 znaki"}},
                             ["query"])},
    {"name": "fleet_overview",
     "description": "Samochody floty: kto jeździ na zmianie dziennej i nocnej, wolne zmiany, kierowcy bez samochodu.",
     "input_schema": _schema({"city": {"type": "string", "enum": CITIES}})},
    {"name": "documents_due",
     "description": "OC i przeglądy wszystkich samochodów, którym termin mija w ciągu 30 dni albo już minął.",
     "input_schema": _schema({})},
    {"name": "office_status",
     "description": "Podsumowanie wynajmu na dziś: ile samochodów, ile wolnych, płatności za bieżący tydzień, zaległości wobec "
                    "właścicieli samochodów, ostrzeżenia.",
     "input_schema": _schema({})},
    {"name": "record_cash",
     "description": "Przygotuj wpis: kierowca oddał gotówkę (kind=cash) albo przyniósł faktury (kind=invoice). Niczego nie "
                    "zapisuje - biuro dostaje kartę z przyciskiem ✅. driver_id weź z find albo cash_status.",
     "input_schema": _schema({"driver_id": {"type": "integer"}, "amount": {"type": "number", "description": "Kwota w zł, > 0"},
                              "kind": {"type": "string", "enum": ["cash", "invoice"]},
                              "week": {"type": "string", "description": "Dzień tygodnia, którego dotyczy wpis (RRRR-MM-DD); "
                                                                        "bez tego - ostatni tydzień z danymi"},
                              "note": {"type": "string", "description": "Tylko jeśli biuro samo podało komentarz do wpisu; "
                                                                        "w przeciwnym razie pomiń"}},
                             ["driver_id", "amount", "kind"])},
    {"name": "set_document_date",
     "description": "Przygotuj nową datę ważności OC albo przeglądu samochodu. Niczego nie zapisuje - biuro dostaje kartę z "
                    "przyciskiem ✅. car_id weź z find albo documents_due.",
     "input_schema": _schema({"car_id": {"type": "integer"}, "doc": {"type": "string", "enum": ["oc", "prz"]},
                              "date": {"type": "string", "description": "Nowa data ważności, RRRR-MM-DD"}}, ["car_id", "doc", "date"])},
    {"name": "rent_cars",
     "description": "Samochody na wynajem (nie flota) z programu: numer, model, kierowca, stawka tygodniowa, czy ten tydzień "
                    "zapłacony, przebieg, OC, przegląd, właściciel, otwarte naprawy. Użyj, gdy proszą o listę aut w wynajmie, "
                    "wolnych aut albo kto czym jeździ.",
     "input_schema": _schema({"only": {"type": "string", "enum": ["with_driver", "free"],
                                       "description": "Tylko z kierowcą albo tylko wolne; bez tego - wszystkie"}})},
    {"name": "rent_week",
     "description": "Płatności za wynajem za tydzień: każde auto z kierowcą - stawka, czy zapłacono, kwota, data, komentarz; "
                    "razem wpłynęło i ile czeka. Bez week - bieżący tydzień.",
     "input_schema": _schema({"week": {"type": "string", "description": "Dowolny dzień tygodnia, RRRR-MM-DD"}})},
    {"name": "rent_drivers",
     "description": "Kierowcy wynajmu: imię, telefon, samochód, sposób płatności, ostatnia wpłata, suma wpłat w tym miesiącu.",
     "input_schema": _schema({})},
    {"name": "car_details",
     "description": "Karta jednego samochodu: kierowcy (historia), ostatnie notatki, naprawy, płatności z ostatnich tygodni, "
                    "przebieg i olej. car_id weź z find albo rent_cars.",
     "input_schema": _schema({"car_id": {"type": "integer"}}, ["car_id"])},
    {"name": "owner_payments",
     "description": "Rozliczenia z właścicielami samochodów (kontrahentami): okres, kwota, czy zapłacono.",
     "input_schema": _schema({"unpaid_only": {"type": "boolean"}})},
    {"name": "add_car_note",
     "description": "Przygotuj notatkę do historii samochodu (np. uszkodzenie, ustalenie z kierowcą). Niczego nie zapisuje - "
                    "biuro dostaje kartę z przyciskiem ✅.",
     "input_schema": _schema({"car_id": {"type": "integer"}, "text": {"type": "string"}}, ["car_id", "text"])},
    {"name": "set_mileage",
     "description": "Przygotuj nowy przebieg samochodu (km). Niczego nie zapisuje - biuro dostaje kartę z przyciskiem ✅.",
     "input_schema": _schema({"car_id": {"type": "integer"}, "km": {"type": "integer"}}, ["car_id", "km"])},
    {"name": "add_repair",
     "description": "Przygotuj wpis naprawy do zrobienia przy samochodzie (opis, opcjonalnie koszt). Niczego nie zapisuje - "
                    "biuro dostaje kartę z przyciskiem ✅.",
     "input_schema": _schema({"car_id": {"type": "integer"}, "text": {"type": "string"},
                              "cost": {"type": "number"}}, ["car_id", "text"])},
    {"name": "record_rent_payment",
     "description": "Przygotuj wpis: kierowca zapłacił za wynajem samochodu za tydzień. Bez amount - pełna stawka; bez week - "
                    "bieżący tydzień. Niczego nie zapisuje - biuro dostaje kartę z przyciskiem ✅.",
     "input_schema": _schema({"car_id": {"type": "integer"}, "amount": {"type": "number"},
                              "week": {"type": "string", "description": "Dowolny dzień tygodnia, RRRR-MM-DD"},
                              "comment": {"type": "string", "description": "Tylko jeśli biuro podało komentarz"}}, ["car_id"])},
]
WRITE = {"record_cash", "set_document_date", "add_car_note", "set_mileage", "add_repair", "record_rent_payment"}


# ---- odczyt
def _cash_status(a):
    v = core.cash_view(a.get("week"), a.get("city"))
    rows = [r for r in v["rows"] if r["status"] != "none"]
    if a.get("only_debtors"):
        rows = [r for r in rows if r["balance"] > core.CASH_EPS]
    week = v["week"]
    return {"week_monday": week, "week_sunday": _sunday(week),
            "drivers": [{"driver_id": r["driver_id"], "name": r["name"], "city": r["city"], "car": r["plate"],
                         "to_hand_over": r["due"], "handed_over": r["cash"], "invoices": r["invoice"],
                         "carried_from_earlier_weeks": r["carry"], "balance": r["balance"], "status": r["status"]} for r in rows],
            "total": {"to_hand_over": v["total"]["due"], "handed_over": v["total"]["cash"], "still_owed": v["total"]["debt"],
                      "drivers_owing": v["total"]["unpaid"]}}


KASA_READER = None  # funkcja bez argumentów -> [kasa.Entry]; ustawia assistant.build (w testach - udawana)


def _cash_reconcile(a):
    """Gotówka zebrana w tygodniu W (pon-nd) jest przynoszona do biura w tygodniu W+1. Dlatego:
    do oddania za W (arkusz rozliczeń - faktury) minus wpłaty z arkusza KASA z dni W+7 ... W+13 = zostało za W."""
    if KASA_READER is None:
        raise core.UserError("Arkusz KASA nie jest podłączony.")
    this_monday = core.monday_of(dt.date.today())
    last = this_monday - dt.timedelta(days=7)  # ostatni zakończony tydzień - za niego teraz przynoszą gotówkę
    asked = core.parse_date(a.get("collected_week") or a.get("week")) if (a.get("collected_week") or a.get("week")) else None
    week = core.monday_of(asked) if asked else last
    shifted = week >= this_monday  # tydzień jeszcze trwa - wpłaty z tych dni dotyczą poprzedniego tygodnia
    if shifted:
        week = last
    try:
        entries = KASA_READER()
    except core.UserError:
        raise
    except Exception as e:
        raise core.UserError("Nie udało się odczytać arkusza KASA: %s" % str(e)[:200]) from e
    led = core._cash_ledger()
    rows = core.cash_view(week.isoformat(), a.get("city"))["rows"]
    cur = _recon_week(week, rows, led, entries)
    prev = _recon_week(week - dt.timedelta(days=7), rows, led, entries)
    known = [d for d in cur["drivers"] if d["status"] != "unknown_grdz_lump"]
    g = [d for d in cur["drivers"] if d["status"] == "unknown_grdz_lump"]
    out = {"collected_week": "%s..%s" % (week.isoformat(), (week + dt.timedelta(days=6)).isoformat()),
           "payments_counted_from_kasa": "%s..%s" % (cur["from"], cur["to"]),
           "amounts_to_hand_over_loaded": cur["loaded"],
           "drivers": cur["drivers"],
           "total": {"still_owed_known": round(sum(d["left"] for d in known if d["left"] > 0), 2),
                     "drivers_still_owing": sum(1 for d in known if d["left"] > core.CASH_EPS),
                     "not_paid": sum(1 for d in known if d["status"] == "not_paid"),
                     "partial": sum(1 for d in known if d["status"] == "partial"),
                     "paid": sum(1 for d in known if d["status"] == "paid")},
           "grudziadz": {"drivers_to_hand_over": round(sum(d["to_hand_over"] for d in g), 2), "drivers": len(g),
                         "lump_paid_in_kasa": round(sum(e.amount for e in cur["grdz"]), 2),
                         "lump_entries": [{"date": e.date, "amount": e.amount} for e in cur["grdz"]]},
           "cash_from_people_not_in_fleet_list": [{"date": e.date, "amount": e.amount, "text": e.text} for e in cur["unknown"]],
           "unclear_entries": [{"date": e.date, "amount": e.amount, "text": e.text, "could_be": n} for e, n in cur["unclear"]],
           "still_owed_from_week_before": [{"name": d["name"], "city": d["city"], "left": d["left"]} for d in prev["drivers"]
                                           if d["left"] > core.CASH_EPS and d["status"] != "unknown_grdz_lump"],
           "note": "Zasada: gotówkę zebraną w tygodniu przynoszą w następnym tygodniu, więc wpłata z KASA z danego dnia "
                   "pomniejsza kwotę za POPRZEDNI tydzień. Niczego nie zapisano."}
    if shifted:
        out["note_requested_week"] = ("Pytany tydzień jeszcze trwa - kierowcy dopiero zbierają za niego gotówkę. Wpłaty z tych "
                                      "dni dotyczą tygodnia %s i taki tydzień pokazano." % out["collected_week"])
    if not cur["loaded"]:
        out["note_not_loaded"] = "Kwot do oddania za ten tydzień jeszcze nie ma w programie (arkusz rozliczeń czytany w poniedziałek ok. 11:00)."
    return out


def _recon_week(week, rows, led, entries):
    """Jeden tydzień zbierania: kierowcy z kwotą do oddania, wpłatami z KASA (z następnego tygodnia) i resztą."""
    from .. import kasa
    wk = week.isoformat()
    start = (week + dt.timedelta(days=7)).isoformat()
    end = min(week + dt.timedelta(days=13), dt.date.today()).isoformat()
    window = [e for e in entries if start <= e.date <= end]
    by_driver, grdz, unknown, unclear = kasa.match(window, [{"driver_id": r["driver_id"], "name": r["name"]} for r in rows])
    drivers, loaded = [], False
    for r in rows:
        cell = led.get(r["driver_id"], {}).get(wk) or {"sheet": None, "invoice": 0.0, "entries": []}
        got = by_driver.get(r["driver_id"], [])
        loaded = loaded or cell["sheet"] is not None
        if cell["sheet"] is None and not got:
            continue
        due = round((cell["sheet"] or 0) - cell["invoice"], 2)
        # wpłaty wpisane w programie liczymy tylko wtedy, gdy nie ma ich już w KASA (ta sama kwota = ten sam wpis)
        pool = [e.amount for e, _ in got]
        extra = []
        for x in cell["entries"]:
            if x["kind"] != "cash":
                continue
            hit = next((i for i, v in enumerate(pool) if abs(v - x["amount"]) < 0.01), None)
            if hit is None:
                extra.append(x["amount"])
            else:
                pool.pop(hit)
        paid = round(sum(e.amount for e, _ in got) + sum(extra), 2)
        left = round(due - paid, 2)
        if r["city"] == "Grudziądz" and not got and not extra and due > core.CASH_EPS:
            status = "unknown_grdz_lump"
        else:
            status = "paid" if left <= core.CASH_EPS else ("partial" if paid > 0 else "not_paid")
        if due <= core.CASH_EPS and not paid:
            continue
        drivers.append({"driver_id": r["driver_id"], "name": r["name"], "city": r["city"], "to_hand_over": due,
                        "paid": paid, "left": left, "status": status, "paid_in_program_only": round(sum(extra), 2) or None,
                        "kasa_entries": [{"date": e.date, "amount": e.amount, "text": e.text, "matched_by": how} for e, how in got]})
    drivers.sort(key=lambda d: -d["left"])
    return {"drivers": drivers, "loaded": loaded, "from": start, "to": end, "grdz": grdz, "unknown": unknown, "unclear": unclear}


def _sunday(week):
    return (dt.date.fromisoformat(week) + dt.timedelta(days=6)).isoformat() if week else None


def _find(a):
    r = core.office_search(a.get("query"), limit=8)
    cars = []
    for c in r["cars"]:
        x = {"car_id": c["id"], "plate": c["plate"], "model": c["model"], "kind": c["kind"], "city": c.get("city"),
             "oc_until": c["oc_until"], "przeglad_until": c["przeglad_until"], "mileage": c["mileage"]}
        if c["kind"] == "fleet":
            x["day_driver"] = c["day"]["name"] if c["day"] else None
            x["night_driver"] = c["night"]["name"] if c["night"] else None
        else:
            x["driver"] = c["driver"]
        cars.append(x)
    drivers = [{"driver_id": d["id"], "name": d["name"], "kind": d["kind"], "city": d["city"], "car": d["plate"], "shift": d["shift"],
                "phone": d["phone"], "telegram_linked": d["tg"]} for d in r["drivers"]]
    return {"cars": cars, "drivers": drivers, "more_results": r["more"]}


def _fleet_overview(a):
    fv = core.fleet_view()
    city = a.get("city")
    cars = [c for c in fv["cars"] if not city or c["city"] == city]
    return {"cars": [{"car_id": c["id"], "plate": c["plate"], "model": c["model"], "city": c["city"],
                      "day_driver": c["day"]["name"] if c["day"] else None,
                      "night_driver": c["night"]["name"] if c["night"] else None,
                      "oc_until": c["oc_until"], "przeglad_until": c["przeglad_until"]} for c in cars],
            "free_shifts": sum(1 for c in cars for s in core.SHIFTS if not c[s]),
            "drivers_without_car": [d["name"] for d in fv["drivers"] if not d["plate"] and (not city or d["city"] == city)]}


def _documents_due(a):
    return {"today": core.today(),
            "items": [{"car_id": i["car_id"], "plate": i["plate"], "doc": i["doc"], "valid_until": i["until"], "days_left": i["days"]}
                      for i in core.doc_reminders_due()]}


def _office_status(a):
    d = core.dashboard()
    k = d["kpi"]
    return {"rent_cars": k["cars"], "with_driver": k["busy"], "free": k["free"],
            "week": d["week"], "week_paid": k["week_paid_n"], "week_rows": k["week_n"], "week_received_zl": k["week_got"],
            "week_waiting_zl": k["week_waiting"], "owners_unpaid_count": k["contr_unpaid_n"], "owners_unpaid_zl": k["contr_unpaid"],
            "cars_without_document_dates": k["no_docs"],
            "alerts": [{"plate": a_["plate"], "text": a_["text"]} for a_ in d["alerts"][:15]]}


# ---- zapis: przygotowanie (sprawdzenie + ai_pending) i wykonanie po potwierdzeniu
def _prepare_cash(a, uid):
    rows = core.q("SELECT id, name FROM drivers WHERE id=?", (int(a["driver_id"]),))
    if not rows:
        raise core.UserError("Kierowca nie istnieje.")
    amount = core.flt(a.get("amount"))
    if amount is None or amount <= 0:
        raise core.UserError("Podaj kwotę.")
    if a.get("kind") not in core.CASH_KINDS:
        raise core.UserError("Wybierz rodzaj wpisu.")
    w = core.parse_date(a.get("week")) if a.get("week") else None
    week = core.monday_of(w).isoformat() if w else core.cash_view()["week"]
    if not week:
        raise core.UserError("Brak tygodnia z danymi gotówki.")
    return {"driver_id": rows[0]["id"], "name": rows[0]["name"], "amount": round(amount, 2), "kind": a["kind"], "week": week,
            "note": (a.get("note") or "").strip()[:200]}


def _prepare_doc(a, uid):
    info = core.doc_info(a["car_id"], a.get("doc"))
    d = core.parse_day(a.get("date"))
    if d is None:
        raise core.UserError("Nieprawidłowa data.")
    if d <= dt.date.today():
        raise core.UserError("Data musi być w przyszłości.")
    if d > dt.date.today() + dt.timedelta(days=366 * core.DOC_MAX_YEARS):
        raise core.UserError("Data jest zbyt odległa.")
    return {"car_id": info["car_id"], "plate": info["plate"], "doc": info["doc"], "label": info["label"], "old": info["until"],
            "date": d.isoformat()}


# ---- wynajem: odczyt
def _rent_cars(a):
    cars = core.cars_list(False, "rent")
    if a.get("only") == "free":
        cars = [c for c in cars if not c["driver"]]
    elif a.get("only") == "with_driver":
        cars = [c for c in cars if c["driver"]]
    return {"count": len(cars),
            "cars": [{"car_id": c["id"], "plate": c["plate"], "model": c["model"], "year": c.get("year"), "driver": c["driver"],
                      "driver_since": c["since"], "rent_per_week": c["rent_week"],
                      "this_week": {"free": "no driver", "paid": "paid", "pending": "not paid yet"}.get(c["status"], c["status"]),
                      "mileage": c["mileage"], "oc_until": c["oc_until"], "przeglad_until": c["przeglad_until"],
                      "owner": c["contractor"], "open_repairs": c["repairs_open"]} for c in cars]}


def _rent_week(a):
    w = core.week_view(a.get("week"))
    return {"week_monday": w["monday"], "week_sunday": w["sunday"], "week_number": w["number"],
            "cars": [{"car_id": r["car_id"], "plate": r["plate"], "driver": r["driver"], "rent": r["rent"], "paid": r["paid"],
                      "paid_amount": r["amount"], "paid_at": r["paid_at"], "comment": r["comment"] or None,
                      "pays": {"cash": "cash", "salary": "from salary"}.get(r["pay_type"], r["pay_type"])} for r in w["rows"]],
            "total": {"expected": w["kpi"]["due"], "received": w["kpi"]["got"], "waiting": w["kpi"]["waiting"],
                      "paid_cars": w["kpi"]["paid_n"], "cars": w["kpi"]["n"]}}


def _rent_drivers(a):
    return {"drivers": [{"driver_id": d["id"], "name": d["name"], "phone": d["phone"], "car": d["plate"], "car_id": d["car_id"],
                         "pays": d["pay"], "last_paid": d["last_paid"], "paid_this_month": d["month_sum"]}
                        for d in core.drivers_list("active", "rent")]}


def _car_details(a):
    c = core.car_detail(int(a["car_id"]))
    if not c:
        raise core.UserError("Samochód nie istnieje.")
    return {"car_id": c["id"], "plate": c["plate"], "model": c["model"], "kind": c["kind"], "owner": c.get("contractor"),
            "driver": c.get("driver"), "rent_per_week": c.get("rent_week"), "mileage": c["mileage"], "km_to_oil_change": c.get("oil_left"),
            "oc_until": c["oc_until"], "przeglad_until": c["przeglad_until"],
            "drivers_history": [{"name": x["name"], "from": x["start_date"], "to": x["end_date"]} for x in c["assignments"][:6]],
            "notes": [{"at": m["created_at"], "text": m["text"]} for m in c["comments"][:12]],
            "repairs": [{"at": r["created_at"], "text": r["text"], "done_at": r["done_at"], "cost": r["cost"]} for r in c["repairs"][:10]],
            "weeks": [{"week": w["week_start"], "paid": bool(w["paid"]), "amount": w["amount"], "paid_at": w["paid_at"],
                       "comment": w["comment"] or None} for w in c["weeks"][:8]]}


def _owner_payments(a):
    p = core.payments_list(bool(a.get("unpaid_only")))
    return {"payments": [{"owner": r["contractor"], "period": r["period"], "amount": r["amount"], "paid_date": r["paid_date"],
                          "paid_amount": r["paid_amount"], "note": r["note"]} for r in p["rows"][:40]],
            "unpaid_count": p["unpaid_n"], "unpaid_sum": p["unpaid_sum"]}


# ---- wynajem: przygotowanie zapisu
def _car(car_id):
    rows = core.q("SELECT id, plate, mileage, rent_week FROM cars WHERE id=? AND active=1", (int(car_id),))
    if not rows:
        raise core.UserError("Samochód nie istnieje.")
    return core._d(rows[0])


def _text(a, key="text", limit=500):
    s = " ".join(str(a.get(key) or "").split())[:limit]
    if not s:
        raise core.UserError("Wpisz treść.")
    return s


def _prepare_note(a, uid):
    c = _car(a["car_id"])
    return {"car_id": c["id"], "plate": c["plate"], "text": _text(a)}


def _prepare_mileage(a, uid):
    c = _car(a["car_id"])
    km = core.num(a.get("km"))
    if km is None or km <= 0:
        raise core.UserError("Wpisz liczbę.")
    return {"car_id": c["id"], "plate": c["plate"], "km": km, "old": c["mileage"]}


def _prepare_repair(a, uid):
    c = _car(a["car_id"])
    cost = core.flt(a.get("cost")) if a.get("cost") not in (None, "") else None
    return {"car_id": c["id"], "plate": c["plate"], "text": _text(a), "cost": cost}


def _prepare_rent(a, uid):
    c = _car(a["car_id"])
    w = core.parse_date(a.get("week")) if a.get("week") else dt.date.today()
    if not w:
        raise core.UserError("Wybierz tydzień.")
    monday = core.monday_of(w).isoformat()
    row = next((r for r in core.week_view(monday)["rows"] if r["car_id"] == c["id"]), None)
    if row is None:
        raise core.UserError("W tym tygodniu samochód nie ma kierowcy.")
    if row["paid"]:
        raise core.UserError("Ten tydzień jest już zapłacony (%s)." % row["paid_at"])
    amount = core.flt(a.get("amount")) if a.get("amount") not in (None, "") else (c["rent_week"] or 0)
    if amount is None or amount < 0:
        raise core.UserError("Podaj kwotę.")
    return {"car_id": c["id"], "plate": c["plate"], "driver": row["driver"], "week": monday, "amount": round(amount, 2),
            "rent": c["rent_week"] or 0, "comment": " ".join(str(a.get("comment") or "").split())[:200]}


def _apply_rent(a, done_by):
    d = {"car_id": a["car_id"], "monday": a["week"], "paid": True, "amount": a["amount"]}
    if a.get("comment"):
        d["comment"] = a["comment"]
    core.set_week(d)


READ = {"cash_status": _cash_status, "cash_reconcile": _cash_reconcile, "find": _find, "fleet_overview": _fleet_overview,
        "documents_due": _documents_due, "office_status": _office_status, "rent_cars": _rent_cars, "rent_week": _rent_week,
        "rent_drivers": _rent_drivers, "car_details": _car_details, "owner_payments": _owner_payments}
PREPARE = {"record_cash": _prepare_cash, "set_document_date": _prepare_doc, "add_car_note": _prepare_note,
           "set_mileage": _prepare_mileage, "add_repair": _prepare_repair, "record_rent_payment": _prepare_rent}
APPLY = {
    "record_cash": lambda a, by: core.cash_add({"driver_id": a["driver_id"], "week": a["week"], "kind": a["kind"],
                                                "amount": a["amount"], "note": a.get("note")}),
    "set_document_date": lambda a, by: core.doc_done(a["car_id"], a["doc"], a["date"], by),
    "add_car_note": lambda a, by: core.add_comment(a["car_id"], a["text"]),
    "set_mileage": lambda a, by: core.set_mileage(a["car_id"], a["km"]),
    "add_repair": lambda a, by: core.add_repair(a["car_id"], a["text"], a.get("cost")),
    "record_rent_payment": _apply_rent,
}


def run(name, args, telegram_id=None):
    """Wywołanie czynności przez model. Odczyt -> dane. Zapis -> {'pending_id': ...} (czeka na "✅" biura)."""
    args = args if isinstance(args, dict) else {}
    if name in READ:
        return READ[name](args)
    if name in PREPARE:
        try:
            checked = PREPARE[name](args, telegram_id)
        except (KeyError, TypeError, ValueError) as e:  # model pominął pole albo podał zły typ
            raise core.UserError("Brak albo zły parametr: %s" % e) from e
        pid = core.ai_pending_add(telegram_id, name, checked)
        return {"pending_id": pid, "prepared": checked,
                "note": "NIE zapisano. Biuro dostało kartę z przyciskami - zapis nastąpi dopiero po naciśnięciu ✅."}
    raise core.UserError("Nieznana czynność: %s" % name)


def confirm(pid, done_by=None):
    """Po "✅": wykonuje czynność. Zwraca {'state': done/failed/expired/cancelled/gone, 'action', 'args', 'error'}."""
    p = core.ai_pending_get(pid)
    if not p:
        return {"state": "gone"}
    if p["state"] != "pending":
        return {"state": p["state"], "action": p["action"], "args": p["args"]}
    a = p["args"]
    if not core.ai_pending_close(pid, "done", done_by):  # zamykamy przed zapisem: drugi klik nie doda wpisu drugi raz
        return {"state": "done", "action": p["action"], "args": a}
    try:
        if p["action"] not in APPLY:
            raise core.UserError("Nieznana czynność.")
        APPLY[p["action"]](a, done_by)
    except Exception as e:
        try:
            core.ex("UPDATE ai_pending SET status='failed', error=? WHERE id=?", (str(e)[:500], int(pid)))
        except Exception:
            pass
        if isinstance(e, core.UserError):
            return {"state": "failed", "action": p["action"], "args": a, "error": str(e)}
        raise
    return {"state": "done", "action": p["action"], "args": a}


def cancel(pid, done_by=None):
    p = core.ai_pending_get(pid)
    if not p:
        return {"state": "gone"}
    if p["state"] == "pending":
        core.ai_pending_close(pid, "cancelled", done_by)
        return {"state": "cancelled", "action": p["action"], "args": p["args"]}
    return {"state": p["state"], "action": p["action"], "args": p["args"]}
