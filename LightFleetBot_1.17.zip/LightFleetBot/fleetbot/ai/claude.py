"""Jedyny punkt wywołania Claude (model i poziom wysiłku z .env, klucz tylko w .env)."""
import logging

log = logging.getLogger("fleetbot.ai")
MAX_TOKENS = 16000


class Claude:
    def __init__(self, api_key, model, effort="low", client=None):
        if client is None:
            import anthropic  # biblioteka potrzebna tylko wtedy, gdy asystent jest włączony
            client = anthropic.AsyncAnthropic(api_key=api_key, max_retries=2, timeout=60.0)
        self.client = client
        self.model = model
        self.effort = effort

    async def ask(self, system, tools, messages):
        return await self.client.messages.create(
            model=self.model, max_tokens=MAX_TOKENS,
            system=[{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
            tools=tools, messages=messages, output_config={"effort": self.effort})


def usage(resp):
    """(tokeny wejścia razem z pamięcią podręczną, tokeny wyjścia)."""
    u = getattr(resp, "usage", None)
    if u is None:
        return 0, 0
    tin = sum(getattr(u, k, 0) or 0 for k in ("input_tokens", "cache_read_input_tokens", "cache_creation_input_tokens"))
    return tin, getattr(u, "output_tokens", 0) or 0


def error_key(e):
    """Błąd Claude -> klucz tekstu dla biura (i18n) albo None, jeśli to nie błąd API."""
    try:
        import anthropic
    except ImportError:
        return None
    if isinstance(e, (anthropic.AuthenticationError, anthropic.PermissionDeniedError)):
        return "ai_key_bad"
    if isinstance(e, anthropic.RateLimitError):
        return "ai_busy"
    if isinstance(e, anthropic.APIStatusError):
        # 400 z informacją o środkach na koncie = brak doładowania
        return "ai_no_credit" if e.status_code == 400 and "credit" in str(e).lower() else "ai_unavailable"
    if isinstance(e, anthropic.APIConnectionError):
        return "ai_unavailable"
    return None
