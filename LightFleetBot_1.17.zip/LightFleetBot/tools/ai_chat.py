"""Rozmowa z asystentem AI w konsoli, na KOPII bazy (bez Telegrama; pracujący bot biura nic nie zauważy).

  .venv\\Scripts\\python -X utf8 tools/ai_chat.py                 rozmowa: piszesz pytania, pusta linia kończy
  .venv\\Scripts\\python -X utf8 tools/ai_chat.py "pytanie" ...   kilka pytań po kolei i koniec
  --db PLIK   inna kopia bazy (domyślnie najnowsza kopia chmury z tools/backup_cloud.py)
  --yes       karty "Zapisać?" potwierdzaj od razu (zapis trafia tylko do tymczasowej kopii)

Klucz ANTHROPIC_API_KEY i model - z pliku .env. Każde pytanie kosztuje (ułamek grosza na Haiku).
"""
import asyncio
import glob
import os
import shutil
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)


def newest_copy():
    import fleet_core as core
    base = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), core.APP_DIR_NAME, "backups", "cloud")
    files = sorted(glob.glob(os.path.join(base, "fleet_cloud_*.db")))
    return files[-1] if files else None


async def chat(questions, yes):
    from fleetbot import config, db
    from fleetbot.ai import assistant, tools
    from fleetbot.handlers.assistant import card_text
    cfg = config.load()
    ai = assistant.build(cfg)
    if ai is None:
        print("Brak ANTHROPIC_API_KEY w .env - asystent wyłączony.")
        return 2
    db.configure(cfg.db, cfg.local_db)
    print("Model: %s · baza: kopia · limit dzienny: %s tokenów\n" % (cfg.ai_model, cfg.ai_daily_tokens or "brak"))
    uid = 1
    it = iter(questions) if questions else iter(lambda: input("> ").strip(), "")
    for q in it:
        if questions:
            print("> " + q)
        r = await ai.reply(uid, q)
        if r.text:
            print(r.text)
        for p in r.pending:
            card = card_text(p["action"], p["args"], "pl")
            print("\n[KARTA] " + card.replace("\n", " | "))
            if yes:
                out = await db.call(tools.confirm, p["id"], uid)
                print("[✅] " + out["state"] + (": " + out["error"] if out.get("error") else ""))
                ai.note(uid, "biuro: %s -> %s" % (card.replace("\n", ", "), out["state"]))
        if r.error:
            print("[BŁĄD] " + r.error)
        print()
    rows = await db.call(db.core.q, "SELECT COUNT(*) AS n, COALESCE(SUM(tokens_in),0) AS i, COALESCE(SUM(tokens_out),0) AS o FROM ai_log")
    print("Zapytań: %d · tokeny: %d wejścia, %d wyjścia" % (rows[0]["n"], rows[0]["i"], rows[0]["o"]))
    return 0


def main():
    args = sys.argv[1:]
    yes = "--yes" in args
    src = None
    if "--db" in args:
        src = args[args.index("--db") + 1]
        del args[args.index("--db"):args.index("--db") + 2]
    questions = [a for a in args if a != "--yes"]
    src = src or newest_copy()
    if not src or not os.path.exists(src):
        print("Brak kopii bazy. Najpierw: python tools/backup_cloud.py")
        return 2
    tmp = tempfile.mkdtemp(prefix="fleet_ai_chat_")
    try:
        work = os.path.join(tmp, "fleet.db")
        shutil.copy2(src, work)  # pracujemy na kopii kopii - nic nie zmienia się ani w chmurze, ani w pliku kopii
        os.environ["DB_MODE"] = "local"
        os.environ["LOCAL_DB_PATH"] = work
        return asyncio.run(chat(questions, yes))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
