"""Arkusz KASA biura: odczyt wpisów, dopasowanie do kierowców floty, czynność asystenta cash_reconcile (bez internetu)."""
import asyncio
import datetime as dt
import unittest
from pathlib import Path

from base import FleetTest, core

try:
    from fleetbot import db, kasa
    from fleetbot.ai import tools
except ImportError:  # biblioteki bota są w .venv
    db = None


def E(date, text, amount):
    return kasa.Entry(date, text, amount)


@unittest.skipIf(db is None, "brak bibliotek bota (uruchom testy z .venv)")
class KasaParseTest(unittest.TestCase):
    def test_parse_carries_date_and_skips_empty(self):
        rows = [["2026-11-16", "Hubert Terajewicz Gotówka", "65"], ["2026-11-13", "", "", "wydatek", "5"],
                ["", "Zofia Gotówka", "210"], ["12.11.2026", "Andrii Anosov  Gotówka", "655,12"], ["", "Bez kwoty", ""],
                ["", "", "1934,71"], ["2026-11-10", "GRDZ Gotówka", "1 610,49"], ["5.8", "Lach", "442,5"]]
        got = [(e.date, e.text, e.amount) for e in kasa.parse(rows)]
        self.assertEqual(got, [("2026-11-16", "Hubert Terajewicz Gotówka", 65.0), ("2026-11-13", "Zofia Gotówka", 210.0),
                               ("2026-11-12", "Andrii Anosov Gotówka", 655.12), ("2026-11-10", "GRDZ Gotówka", 1610.49),
                               ("2026-11-10", "Lach", 442.5)])
        self.assertEqual(kasa.parse([["", "Jan Gotówka", "10"]]), [])  # bez daty nie wiemy, kiedy

    def test_words(self):
        self.assertEqual(kasa.words("Joanna Witt Gotówka (2 tyg)"), ["joanna", "witt"])
        self.assertEqual(kasa.words("Artur Porzeziński Gotówka"), ["artur", "porzezinski"])
        self.assertTrue(kasa.is_grdz("Gotówka GRDZ") and kasa.is_grdz("grudziądz gotówka") and not kasa.is_grdz("Grzegorz"))

    def test_match(self):
        drivers = [{"driver_id": 1, "name": "Andrii Anosov"}, {"driver_id": 2, "name": "Zofia Górecka"},
                   {"driver_id": 3, "name": "Jan Kowalski"}, {"driver_id": 4, "name": "Jan Nowak"},
                   {"driver_id": 5, "name": "Ramez Abdelfatah"}]
        entries = [E("2026-11-12", "Andrii Anosov Gotówka", 655.12), E("2026-11-13", "Zofia Gotówka", 210),
                   E("2026-11-13", "Jan Gotówka", 50), E("2026-11-10", "GRDZ Gotówka", 1610.49),
                   E("2026-11-10", "Katsiaryna Tkachenka Gotówka", 159.31), E("2026-11-12", "Bartosz Kufel (wynajem)", 750),
                   E("2026-11-04", "Ramez Abdelfatah", 114), E("2026-11-06", "Anton", 2200), E("2026-11-09", "ANOSOV ANDRII gotowka", 5)]
        by, grdz, unknown, unclear = kasa.match(entries, drivers)
        self.assertEqual([(e.amount, how) for e, how in by[1]], [(655.12, "full"), (5, "full")])
        self.assertEqual([(e.amount, how) for e, how in by[2]], [(210, "part")])  # tylko imię, jedyna Zofia
        self.assertEqual([(e.amount, how) for e, how in by[5]], [(114, "full")])  # pełne nazwisko bez słowa Gotówka
        self.assertNotIn(3, by)
        self.assertEqual([(e.text, names) for e, names in unclear], [("Jan Gotówka", ["Jan Kowalski", "Jan Nowak"])])
        self.assertEqual([e.amount for e in grdz], [1610.49])
        self.assertEqual([e.text for e in unknown], ["Katsiaryna Tkachenka Gotówka"])  # wynajem i "Anton" pominięte


@unittest.skipIf(db is None, "brak bibliotek bota (uruchom testy z .venv)")
class ReconcileTest(FleetTest):
    def setUp(self):
        super().setUp()
        self.main_db = core.DBX
        db.configure({"mode": "local"}, Path(core.DB))
        mon = dt.date.today() - dt.timedelta(days=dt.date.today().weekday())
        self.w2 = (mon - dt.timedelta(days=7)).isoformat()   # ostatni rozliczony tydzień
        self.w1 = (mon - dt.timedelta(days=14)).isoformat()  # tydzień wcześniej
        self.mon = mon.isoformat()
        mk = lambda n, c: core.save_driver({"name": n, "kind": "fleet", "city": c})  # noqa: E731
        self.an, self.zo, self.ra, self.ko = mk("Andrii Anosov", "Toruń"), mk("Zofia Górecka", "Toruń"), mk("Ramez Abdelfatah", "Toruń"), mk("Jerzy Kondziela", "Grudziądz")
        core.fleet_cash_store(self.mon, [(self.an, 1000, 1), (self.zo, 100, 2), (self.ra, 300, 3), (self.ko, 500, 4)])
        self.entries = []
        tools.KASA_READER = lambda: self.entries

    def tearDown(self):
        tools.KASA_READER = None
        bot_db = core.DBX
        if bot_db is not self.main_db and hasattr(bot_db, "conn"):
            db.POOL.submit(bot_db.close).result()
        core.DBX = self.main_db
        super().tearDown()

    def call(self, *a):
        return asyncio.run(db.call(tools.run, "cash_reconcile", *a))

    def by_name(self, r):
        return {d["name"]: (d["to_hand_over"], d["paid_in_kasa"], d["left"], d["status"]) for d in r["drivers"]}

    def test_paid_partial_none_and_grudziadz_lump(self):
        self.entries = [E(self.mon, "Andrii Anosov Gotówka", 600), E(self.mon, "Zofia Gotówka", 100), E(self.mon, "GRDZ Gotówka", 450),
                        E(self.mon, "Obcy Człowiek Gotówka", 77), E(self.w2, "Ramez Abdelfatah Gotówka", 300)]  # za wcześnie - poprzedni tydzień
        r = self.call({})
        self.assertEqual((r["week_monday"], r["kasa_from"]), (self.w2, self.mon))
        self.assertEqual(self.by_name(r), {"Andrii Anosov": (1000.0, 600.0, 400.0, "partial"), "Zofia Górecka": (100.0, 100.0, 0.0, "paid"),
                                           "Ramez Abdelfatah": (300.0, 0, 300.0, "not_paid"),
                                           "Jerzy Kondziela": (500.0, 0, 500.0, "unknown_grdz_lump")})
        self.assertEqual(r["total"], {"still_owed_known": 700.0, "not_paid": 1, "partial": 1, "paid": 1})
        self.assertEqual((r["grudziadz"]["drivers_to_hand_over"], r["grudziadz"]["lump_paid_in_kasa"]), (500.0, 450.0))
        self.assertEqual([x["text"] for x in r["cash_from_people_not_in_fleet_list"]], ["Obcy Człowiek Gotówka"])
        zofia = next(d for d in r["drivers"] if d["name"] == "Zofia Górecka")
        self.assertEqual(zofia["kasa_entries"][0]["matched_by"], "part")
        self.assertEqual([d["name"] for d in self.call({"city": "Grudziądz"})["drivers"]], ["Jerzy Kondziela"])

    def test_old_debt_counts_kasa_from_the_week_it_started(self):
        """Dług z wcześniejszego tygodnia: wpłaty z KASA liczone od poniedziałku po tym tygodniu, nie tylko z ostatnich dni."""
        asyncio.run(db.call(core.fleet_cash_store, self.w2, [(self.an, 200, 1)]))  # tydzień w1: 200 do oddania
        self.entries = [E(self.w2, "Andrii Anosov Gotówka", 200), E(self.mon, "Andrii Anosov Gotówka", 1000)]
        r = self.call({})
        self.assertEqual(self.by_name(r)["Andrii Anosov"], (1200.0, 1200.0, 0.0, "paid"))
        self.assertEqual(r["kasa_from"], self.w2)

    def test_program_entries_and_no_sheet(self):
        asyncio.run(db.call(core.cash_add, {"driver_id": self.ra, "week": self.w2, "kind": "cash", "amount": 300}))
        self.assertNotIn("Ramez Abdelfatah", self.by_name(self.call({})))  # oddał w programie - nic nie wisi

        def broken():
            raise ConnectionError("brak sieci")
        tools.KASA_READER = broken
        self.assertUserError(lambda: self.call({}), "Nie udało się odczytać arkusza KASA")
        tools.KASA_READER = None
        self.assertUserError(lambda: self.call({}), "nie jest podłączony")


if __name__ == "__main__":
    unittest.main()
