"""OC i przeglądy: codzienna lista dla biura (10:00, od 30 dni przed terminem) z przyciskami "✅ Zrobione".

Po naciśnięciu bot pyta o nową datę; zapis w samochodzie i w historii samochodu, przypomnienia o tym terminie znikają.
/dokumenty - ta sama lista na żądanie.
"""
import datetime as dt
import logging

from aiogram import F, Router
from aiogram.dispatcher.event.bases import SkipHandler
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from .. import db
from ..i18n import t
from ..outbox import keyboard

log = logging.getLogger("fleetbot.docs")
router = Router()
ERRORS = {"Nieprawidłowa data.": "doc_date_bad", "Data musi być w przyszłości.": "doc_date_past",
          "Data jest zbyt odległa.": "doc_date_far", "Samochód nie istnieje.": "doc_gone", "Nieznany dokument.": "doc_gone"}


class DocDate(StatesGroup):
    date = State()


def _dmy(s):
    return "%s.%s.%s" % (s[8:10], s[5:7], s[:4])


def _when(lang, it):
    if it["days"] < 0:
        return t(lang, "doc_over", date=_dmy(it["until"]), n=-it["days"])
    if it["days"] == 0:
        return t(lang, "doc_today", date=_dmy(it["until"]))
    return t(lang, "doc_left", date=_dmy(it["until"]), n=it["days"])


def _icon(days):
    return "🔴" if days <= 7 else "🟡"


def docs_text(items, lang, today=None):
    today = today or dt.date.today()
    if not items:
        return t(lang, "docs_none")
    lines = [t(lang, "docs_title", date=today.strftime("%d.%m.%Y"))]
    for it in items:
        lines.append(t(lang, "docs_line", icon=_icon(it["days"]), plate=it["plate"], doc=it["label"], when=_when(lang, it)))
    return "\n".join(lines)


def docs_buttons(items, lang):
    """Po dwa przyciski w wierszu: '✅ BI062YR OC' -> doc:<id>:<oc|prz>."""
    btns = [[t(lang, "doc_btn", plate=it["plate"], doc=it["label"]), "doc:%d:%s" % (it["car_id"], it["doc"])] for it in items]
    return [btns[i:i + 2] for i in range(0, len(btns), 2)] or None


@router.message(Command("dokumenty"))
async def dokumenty(message: Message, is_office: bool, lang: str):
    if not is_office:
        return
    try:
        items = await db.call(db.core.doc_reminders_due)
    except db.DbUnavailable:
        return await message.answer(t(lang, "db_unavailable"))
    await message.answer(docs_text(items, lang), reply_markup=keyboard(docs_buttons(items, lang)))


@router.callback_query(F.data.startswith("doc:"))
async def doc_pick(cb: CallbackQuery, state: FSMContext, is_office: bool, lang: str):
    if not is_office:
        return await cb.answer()
    try:
        _, car_id, doc = cb.data.split(":")
        info = await db.call(db.core.doc_info, int(car_id), doc)
    except db.DbUnavailable:
        return await cb.answer(t(lang, "db_unavailable"), show_alert=True)
    except (ValueError, db.core.UserError):
        return await cb.answer(t(lang, "doc_gone"), show_alert=True)
    await cb.answer()
    await state.set_state(DocDate.date)
    await state.update_data(car_id=info["car_id"], doc=doc)
    when = _when(lang, info) if info["until"] else t(lang, "doc_none")
    log.info("Zrobione %s %s: pytam o datę (%s)", info["plate"], doc, cb.from_user.id)
    await cb.message.answer(t(lang, "doc_ask", plate=info["plate"], doc=info["label"], when=when))


@router.message(StateFilter(DocDate.date), Command("anuluj"))
async def doc_cancel(message: Message, state: FSMContext, lang: str):
    await state.clear()
    await message.answer(t(lang, "doc_cancel"))


@router.message(StateFilter(DocDate.date), F.text.startswith("/"))
async def doc_other_command(message: Message, state: FSMContext):
    """Inna komenda w trakcie - porzucamy pytanie o datę i wykonujemy komendę."""
    await state.clear()
    raise SkipHandler()


@router.message(StateFilter(DocDate.date), F.text)
async def doc_date(message: Message, state: FSMContext, is_office: bool, lang: str):
    if not is_office:
        await state.clear()
        raise SkipHandler()
    data = await state.get_data()
    try:
        r = await db.call(db.core.doc_done, data["car_id"], data["doc"], message.text, message.from_user.id)
    except db.DbUnavailable:
        return await message.answer(t(lang, "db_unavailable"))
    except db.core.UserError as e:
        key = ERRORS.get(str(e))
        if key == "doc_gone":
            await state.clear()
        return await message.answer(t(lang, key) if key else str(e))
    await state.clear()
    log.info("Zrobione %s %s: %s -> %s (%s)", r["plate"], r["doc"], r["old"], r["until"], message.from_user.id)
    await message.answer(t(lang, "doc_saved", plate=r["plate"], doc=r["label"], date=_dmy(r["until"])))
