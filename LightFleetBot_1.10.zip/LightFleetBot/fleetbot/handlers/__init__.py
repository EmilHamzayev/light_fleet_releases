from aiogram import Router

from . import basic, docs, link, office


def router():
    r = Router()
    r.include_router(link.router)  # przed basic: /start z kodem
    r.include_router(basic.router)
    r.include_router(docs.router)  # przed office: odpowiedź z datą nie trafia do wyszukiwania
    r.include_router(office.router)
    return r
