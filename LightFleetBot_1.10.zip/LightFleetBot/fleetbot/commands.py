"""Menu komend w Telegramie (po polsku): wszyscy widzą podstawowe, biuro - także komendy biura."""
import logging

from aiogram.types import BotCommand, BotCommandScopeChat

from . import i18n

log = logging.getLogger("fleetbot.commands")
BASIC = ("start", "lang", "ja", "pomoc", "ping")
OFFICE = BASIC + ("status", "gotowka", "flota", "dokumenty", "kod")
ADMIN = OFFICE + ("kod_biuro",)


def _cmds(names):
    return [BotCommand(command=c, description=i18n.t(i18n.DEFAULT, "cmd_" + c)) for c in names]


async def set_default(bot):
    await bot.set_my_commands(_cmds(BASIC))
    for lang in i18n.LANGS:  # usuwa stare menu w innych językach
        await bot.delete_my_commands(language_code=lang)


async def set_for_chat(bot, chat_id, office, admin=False):
    """Menu biura w prywatnym czacie danej osoby (nie wszyscy widzą komendy biura)."""
    try:
        if office or admin:
            await bot.set_my_commands(_cmds(ADMIN if admin else OFFICE), scope=BotCommandScopeChat(chat_id=chat_id))
        else:
            await bot.delete_my_commands(scope=BotCommandScopeChat(chat_id=chat_id))
    except Exception as e:  # np. ktoś nigdy nie pisał do bota
        log.info("Menu dla %s nieustawione: %s", chat_id, e)
