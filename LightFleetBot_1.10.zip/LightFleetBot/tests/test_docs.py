import asyncio
import datetime as dt
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

from base import FleetTest, core, day

try:
    from fleetbot import db, jobs
    from fleetbot.handlers import docs
except ImportError:  # biblioteki bota są w .venv
    db = None


class DocCoreTest(FleetTest):
    def setUp(self):
        super().setUp()
        core.ex("UPDATE cars SET oc_until=?, przeglad_until=? WHERE id=?", (day(10), day(200), self.c1))
        core.ex("UPDATE cars SET oc_until=?, przeglad_until=? WHERE id=?", (day(-3), day(30), self.c2))
        core.ex("UPDATE cars SET oc_until=? WHERE id=?", (day(31), self.c3))  # za daleko, przegląd pusty
        core.ex("UPDATE cars SET oc_until=?, active=0 WHERE id=?", (day(1), self.c4))  # archiwum

    def test_due_list(self):
        r = [(x["plate"], x["doc"], x["days"]) for x in core.doc_reminders_due()]
        self.assertEqual(r, [("BB222", "oc", -3), ("AA111", "oc", 10), ("BB222", "prz", 30)])

    def test_parse_day(self):
        self.assertEqual(core.parse_day("15.11.2027"), dt.date(2027, 11, 15))
        self.assertEqual(core.parse_day(" 5.1.2027 "), dt.date(2027, 1, 5))
        self.assertEqual(core.parse_day("2027-01-05"), dt.date(2027, 1, 5))
        for bad in ("31.02.2027", "15.11.27", "jutro", "", None):
            self.assertIsNone(core.parse_day(bad))

    def test_done_saves_history_and_stops_reminder(self):
        new = (dt.date.today() + dt.timedelta(days=365)).strftime("%d.%m.%Y")
        r = core.doc_done(self.c2, "oc", new, 1022875169)
        self.assertEqual((r["plate"], r["old"], r["until"]), ("BB222", day(-3), day(365)))
        self.assertEqual(self.car(self.c2)["oc_until"], day(365))
        self.assertNotIn(("BB222", "oc"), [(x["plate"], x["doc"]) for x in core.doc_reminders_due()])
        self.assertEqual(self.count("doc_reminders", "car_id=? AND doc='oc' AND done_by=1022875169", (self.c2,)), 1)
        txt = core.q("SELECT text FROM comments WHERE car_id=?", (self.c2,))[0]["text"]
        self.assertIn("OC ważne do %s" % new, txt)

    def test_done_przeglad_from_empty(self):
        core.doc_done(self.c3, "prz", day(100))
        self.assertEqual(core.q("SELECT przeglad_until FROM cars WHERE id=?", (self.c3,))[0]["przeglad_until"], day(100))
        self.assertIn("było: brak", core.q("SELECT text FROM comments WHERE car_id=?", (self.c3,))[0]["text"])

    def test_done_errors(self):
        self.assertUserError(lambda: core.doc_done(self.c1, "oc", "jutro"), "Nieprawidłowa data")
        self.assertUserError(lambda: core.doc_done(self.c1, "oc", day(0)), "przyszłości")
        self.assertUserError(lambda: core.doc_done(self.c1, "oc", day(-1)), "przyszłości")
        self.assertUserError(lambda: core.doc_done(self.c1, "oc", day(366 * 6)), "odległa")
        self.assertUserError(lambda: core.doc_done(self.c4, "oc", day(100)), "nie istnieje")
        self.assertUserError(lambda: core.doc_done(self.c1, "ac", day(100)), "Nieznany")
        self.assertEqual(self.car(self.c1)["oc_until"], day(10))
        self.assertEqual(self.count("doc_reminders"), 0)


@unittest.skipIf(db is None, "brak bibliotek bota (uruchom testy z .venv)")
class DocBotTest(DocCoreTest):
    def setUp(self):
        super().setUp()
        self.main_db = core.DBX
        db.configure({"mode": "local"}, Path(core.DB))
        self.cfg = SimpleNamespace(office_chat_id=6936017050, group_lang="pl")

    def tearDown(self):
        bot_db = core.DBX
        if bot_db is not self.main_db and hasattr(bot_db, "conn"):
            db.POOL.submit(bot_db.close).result()
        core.DBX = self.main_db
        super().tearDown()

    def test_text_and_buttons(self):
        items = core.doc_reminders_due()
        txt = docs.docs_text(items, "pl", dt.date(2026, 11, 6))
        self.assertTrue(txt.startswith("📄 OC i przeglądy — 06.11.2026"))
        self.assertIn("🔴 BB222 — OC: ", txt)
        self.assertIn("(po terminie 3 dni)", txt)
        self.assertIn("🟡 AA111 — OC: ", txt)
        self.assertIn("🟡 BB222 — Przegląd: ", txt)
        b = docs.docs_buttons(items, "pl")
        self.assertEqual([len(r) for r in b], [2, 1])
        self.assertEqual(b[0][0], ["✅ BB222 OC", "doc:%d:oc" % self.c2])
        self.assertEqual(docs.docs_text([], "ru"), "✅ Все OC и przegląd действуют больше 30 дней.")
        self.assertIsNone(docs.docs_buttons([], "pl"))

    def test_daily_job_once_per_day(self):
        ctx = {"cfg": self.cfg}
        self.assertEqual(asyncio.run(jobs.doc_reminders(ctx, dt.date(2026, 11, 6))), "3 terminów")
        asyncio.run(jobs.doc_reminders(ctx, dt.date(2026, 11, 6)))
        out = asyncio.run(db.call(core.outbox_due))
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0]["chat_id"], 6936017050)
        self.assertEqual(out[0]["buttons"][0][0][1], "doc:%d:oc" % self.c2)
        self.assertIn("doc_reminders", [j.name for j in jobs.all_jobs()])

    def test_job_nothing_due(self):
        asyncio.run(db.call(core.ex, "UPDATE cars SET oc_until=NULL, przeglad_until=NULL", ()))
        self.assertEqual(asyncio.run(jobs.doc_reminders({"cfg": self.cfg})), "brak")
        self.assertEqual(asyncio.run(db.call(core.outbox_due)), [])

    def _msg(self, text):
        m = mock.MagicMock()
        m.text = text
        m.from_user.id = 1022875169
        m.answer = mock.AsyncMock()
        return m

    def test_flow_button_then_date(self):
        from aiogram.fsm.context import FSMContext
        from aiogram.fsm.storage.base import StorageKey
        from aiogram.fsm.storage.memory import MemoryStorage
        state = FSMContext(MemoryStorage(), StorageKey(bot_id=1, chat_id=1, user_id=1))
        cb = mock.MagicMock()
        cb.data = "doc:%d:oc" % self.c2
        cb.from_user.id = 1022875169
        cb.answer = mock.AsyncMock()
        cb.message.answer = mock.AsyncMock()
        asyncio.run(docs.doc_pick(cb, state, True, "pl"))
        self.assertIn("BB222 — OC:", cb.message.answer.call_args[0][0])
        self.assertEqual(asyncio.run(state.get_state()), docs.DocDate.date.state)
        m = self._msg("wczoraj")
        asyncio.run(docs.doc_date(m, state, True, "pl"))
        self.assertIn("Nieprawidłowa data", m.answer.call_args[0][0])
        self.assertIsNotNone(asyncio.run(state.get_state()))  # czeka dalej
        new = (dt.date.today() + dt.timedelta(days=365)).strftime("%d.%m.%Y")
        m = self._msg(new)
        asyncio.run(docs.doc_date(m, state, True, "pl"))
        self.assertEqual(m.answer.call_args[0][0], "✅ BB222 — OC ważne do %s." % new)
        self.assertIsNone(asyncio.run(state.get_state()))
        self.assertEqual(asyncio.run(db.call(core.doc_info, self.c2, "oc"))["until"], day(365))

    def test_not_office_ignored(self):
        cb = mock.MagicMock()
        cb.data = "doc:%d:oc" % self.c2
        cb.answer = mock.AsyncMock()
        cb.message.answer = mock.AsyncMock()
        asyncio.run(docs.doc_pick(cb, mock.AsyncMock(), False, "pl"))
        cb.message.answer.assert_not_called()


if __name__ == "__main__":
    unittest.main()
