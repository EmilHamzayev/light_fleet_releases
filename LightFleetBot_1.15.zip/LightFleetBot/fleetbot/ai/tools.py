"""Czynności asystenta = gotowe funkcje fleet_core (asystent sam nie pisze SQL i nie zapisuje do bazy).

Odczyt (READ) - wykonywany od razu, do modelu wracają tylko potrzebne pola (RODO).
Zapis (WRITE) - tylko przygotowanie: sprawdzenie danych i wpis do ai_pending; wykonanie w `confirm` po "✅" biura.
Wszystkie funkcje są synchroniczne - bot wywołuje je przez db.call (wątek bazy).
"""
import datetime as dt

from ..db import core

CITIES = ["Toruń", "Grudziądz"]


def _schema(props, required=()):
    return {"type": "object", "properties": props, "required": list(required), "additionalProperties": False}


TOOLS = [
    {"name": "cash_status",
     "description": "Gotówka kierowców floty za tydzień: kto ile ma oddać, ile oddał, ile zostało (saldo z poprzednich tygodni "
                    "wliczone). Użyj przy pytaniach kto oddał / nie oddał gotówki, ile kto wisi, ile razem. Bez week - ostatni "
                    "tydzień z danymi. balance > 0 = jeszcze do oddania, balance < 0 = nadpłata.",
     "input_schema": _schema({"week": {"type": "string", "description": "Dowolny dzień tygodnia, RRRR-MM-DD"},
                              "city": {"type": "string", "enum": CITIES},
                              "only_debtors": {"type": "boolean", "description": "Tylko ci, którzy mają jeszcze coś do oddania"}})},
    {"name": "find",
     "description": "Szukaj samochodu po numerze rejestracyjnym (także fragment) albo kierowcy po imieniu / nazwisku. Zwraca "
                    "id potrzebne w innych czynnościach, samochód, zmianę, daty OC i przeglądu, telefon kierowcy.",
     "input_schema": _schema({"query": {"type": "string", "description": "Numer rejestracyjny albo imię / nazwisko, min. 3 znaki"}},
                             ["query"])},
    {"name": "fleet_overview",
     "description": "Samochody floty: kto jeździ na zmianie dziennej i nocnej, wolne zmiany, kierowcy bez samochodu.",
     "input_schema": _schema({"city": {"type": "string", "enum": CITIES}})},
    {"name": "documents_due",
     "description": "OC i przeglądy wszystkich samochodów, którym termin mija w ciągu 30 dni albo już minął.",
     "input_schema": _schema({})},
    {"name": "office_status",
     "description": "Podsumowanie wynajmu na dziś: ile samochodów, ile wolnych, płatności za bieżący tydzień, zaległości wobec "
                    "właścicieli samochodów, ostrzeżenia.",
     "input_schema": _schema({})},
    {"name": "record_cash",
     "description": "Przygotuj wpis: kierowca oddał gotówkę (kind=cash) albo przyniósł faktury (kind=invoice). Niczego nie "
                    "zapisuje - biuro dostaje kartę z przyciskiem ✅. driver_id weź z find albo cash_status.",
     "input_schema": _schema({"driver_id": {"type": "integer"}, "amount": {"type": "number", "description": "Kwota w zł, > 0"},
                              "kind": {"type": "string", "enum": ["cash", "invoice"]},
                              "week": {"type": "string", "description": "Dzień tygodnia, którego dotyczy wpis (RRRR-MM-DD); "
                                                                        "bez tego - ostatni tydzień z danymi"},
                              "note": {"type": "string", "description": "Tylko jeśli biuro samo podało komentarz do wpisu; "
                                                                        "w przeciwnym razie pomiń"}},
                             ["driver_id", "amount", "kind"])},
    {"name": "set_document_date",
     "description": "Przygotuj nową datę ważności OC albo przeglądu samochodu. Niczego nie zapisuje - biuro dostaje kartę z "
                    "przyciskiem ✅. car_id weź z find albo documents_due.",
     "input_schema": _schema({"car_id": {"type": "integer"}, "doc": {"type": "string", "enum": ["oc", "prz"]},
                              "date": {"type": "string", "description": "Nowa data ważności, RRRR-MM-DD"}}, ["car_id", "doc", "date"])},
]
WRITE = {"record_cash", "set_document_date"}


# ---- odczyt
def _cash_status(a):
    v = core.cash_view(a.get("week"), a.get("city"))
    rows = [r for r in v["rows"] if r["status"] != "none"]
    if a.get("only_debtors"):
        rows = [r for r in rows if r["balance"] > core.CASH_EPS]
    week = v["week"]
    return {"week_monday": week, "week_sunday": _sunday(week),
            "drivers": [{"driver_id": r["driver_id"], "name": r["name"], "city": r["city"], "car": r["plate"],
                         "to_hand_over": r["due"], "handed_over": r["cash"], "invoices": r["invoice"],
                         "carried_from_earlier_weeks": r["carry"], "balance": r["balance"], "status": r["status"]} for r in rows],
            "total": {"to_hand_over": v["total"]["due"], "handed_over": v["total"]["cash"], "still_owed": v["total"]["debt"],
                      "drivers_owing": v["total"]["unpaid"]}}


def _sunday(week):
    return (dt.date.fromisoformat(week) + dt.timedelta(days=6)).isoformat() if week else None


def _find(a):
    r = core.office_search(a.get("query"), limit=8)
    cars = []
    for c in r["cars"]:
        x = {"car_id": c["id"], "plate": c["plate"], "model": c["model"], "kind": c["kind"], "city": c.get("city"),
             "oc_until": c["oc_until"], "przeglad_until": c["przeglad_until"], "mileage": c["mileage"]}
        if c["kind"] == "fleet":
            x["day_driver"] = c["day"]["name"] if c["day"] else None
            x["night_driver"] = c["night"]["name"] if c["night"] else None
        else:
            x["driver"] = c["driver"]
        cars.append(x)
    drivers = [{"driver_id": d["id"], "name": d["name"], "kind": d["kind"], "city": d["city"], "car": d["plate"], "shift": d["shift"],
                "phone": d["phone"], "telegram_linked": d["tg"]} for d in r["drivers"]]
    return {"cars": cars, "drivers": drivers, "more_results": r["more"]}


def _fleet_overview(a):
    fv = core.fleet_view()
    city = a.get("city")
    cars = [c for c in fv["cars"] if not city or c["city"] == city]
    return {"cars": [{"car_id": c["id"], "plate": c["plate"], "model": c["model"], "city": c["city"],
                      "day_driver": c["day"]["name"] if c["day"] else None,
                      "night_driver": c["night"]["name"] if c["night"] else None,
                      "oc_until": c["oc_until"], "przeglad_until": c["przeglad_until"]} for c in cars],
            "free_shifts": sum(1 for c in cars for s in core.SHIFTS if not c[s]),
            "drivers_without_car": [d["name"] for d in fv["drivers"] if not d["plate"] and (not city or d["city"] == city)]}


def _documents_due(a):
    return {"today": core.today(),
            "items": [{"car_id": i["car_id"], "plate": i["plate"], "doc": i["doc"], "valid_until": i["until"], "days_left": i["days"]}
                      for i in core.doc_reminders_due()]}


def _office_status(a):
    d = core.dashboard()
    k = d["kpi"]
    return {"rent_cars": k["cars"], "with_driver": k["busy"], "free": k["free"],
            "week": d["week"], "week_paid": k["week_paid_n"], "week_rows": k["week_n"], "week_received_zl": k["week_got"],
            "week_waiting_zl": k["week_waiting"], "owners_unpaid_count": k["contr_unpaid_n"], "owners_unpaid_zl": k["contr_unpaid"],
            "cars_without_document_dates": k["no_docs"],
            "alerts": [{"plate": a_["plate"], "text": a_["text"]} for a_ in d["alerts"][:15]]}


# ---- zapis: przygotowanie (sprawdzenie + ai_pending) i wykonanie po potwierdzeniu
def _prepare_cash(a, uid):
    rows = core.q("SELECT id, name FROM drivers WHERE id=?", (int(a["driver_id"]),))
    if not rows:
        raise core.UserError("Kierowca nie istnieje.")
    amount = core.flt(a.get("amount"))
    if amount is None or amount <= 0:
        raise core.UserError("Podaj kwotę.")
    if a.get("kind") not in core.CASH_KINDS:
        raise core.UserError("Wybierz rodzaj wpisu.")
    w = core.parse_date(a.get("week")) if a.get("week") else None
    week = core.monday_of(w).isoformat() if w else core.cash_view()["week"]
    if not week:
        raise core.UserError("Brak tygodnia z danymi gotówki.")
    return {"driver_id": rows[0]["id"], "name": rows[0]["name"], "amount": round(amount, 2), "kind": a["kind"], "week": week,
            "note": (a.get("note") or "").strip()[:200]}


def _prepare_doc(a, uid):
    info = core.doc_info(a["car_id"], a.get("doc"))
    d = core.parse_day(a.get("date"))
    if d is None:
        raise core.UserError("Nieprawidłowa data.")
    if d <= dt.date.today():
        raise core.UserError("Data musi być w przyszłości.")
    if d > dt.date.today() + dt.timedelta(days=366 * core.DOC_MAX_YEARS):
        raise core.UserError("Data jest zbyt odległa.")
    return {"car_id": info["car_id"], "plate": info["plate"], "doc": info["doc"], "label": info["label"], "old": info["until"],
            "date": d.isoformat()}


READ = {"cash_status": _cash_status, "find": _find, "fleet_overview": _fleet_overview, "documents_due": _documents_due,
        "office_status": _office_status}
PREPARE = {"record_cash": _prepare_cash, "set_document_date": _prepare_doc}


def run(name, args, telegram_id=None):
    """Wywołanie czynności przez model. Odczyt -> dane. Zapis -> {'pending_id': ...} (czeka na "✅" biura)."""
    args = args if isinstance(args, dict) else {}
    if name in READ:
        return READ[name](args)
    if name in PREPARE:
        try:
            checked = PREPARE[name](args, telegram_id)
        except (KeyError, TypeError, ValueError) as e:  # model pominął pole albo podał zły typ
            raise core.UserError("Brak albo zły parametr: %s" % e) from e
        pid = core.ai_pending_add(telegram_id, name, checked)
        return {"pending_id": pid, "prepared": checked,
                "note": "NIE zapisano. Biuro dostało kartę z przyciskami - zapis nastąpi dopiero po naciśnięciu ✅."}
    raise core.UserError("Nieznana czynność: %s" % name)


def confirm(pid, done_by=None):
    """Po "✅": wykonuje czynność. Zwraca {'state': done/failed/expired/cancelled/gone, 'action', 'args', 'error'}."""
    p = core.ai_pending_get(pid)
    if not p:
        return {"state": "gone"}
    if p["state"] != "pending":
        return {"state": p["state"], "action": p["action"], "args": p["args"]}
    a = p["args"]
    if not core.ai_pending_close(pid, "done", done_by):  # zamykamy przed zapisem: drugi klik nie doda wpisu drugi raz
        return {"state": "done", "action": p["action"], "args": a}
    try:
        if p["action"] == "record_cash":
            core.cash_add({"driver_id": a["driver_id"], "week": a["week"], "kind": a["kind"], "amount": a["amount"],
                           "note": a.get("note")})
        elif p["action"] == "set_document_date":
            core.doc_done(a["car_id"], a["doc"], a["date"], done_by)
        else:
            raise core.UserError("Nieznana czynność.")
    except Exception as e:
        try:
            core.ex("UPDATE ai_pending SET status='failed', error=? WHERE id=?", (str(e)[:500], int(pid)))
        except Exception:
            pass
        if isinstance(e, core.UserError):
            return {"state": "failed", "action": p["action"], "args": a, "error": str(e)}
        raise
    return {"state": "done", "action": p["action"], "args": a}


def cancel(pid, done_by=None):
    p = core.ai_pending_get(pid)
    if not p:
        return {"state": "gone"}
    if p["state"] == "pending":
        core.ai_pending_close(pid, "cancelled", done_by)
        return {"state": "cancelled", "action": p["action"], "args": p["args"]}
    return {"state": p["state"], "action": p["action"], "args": p["args"]}
