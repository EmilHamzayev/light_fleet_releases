"""Ustawienia bota z pliku .env (sekrety tylko tam, plik nie trafia do git)."""
import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent


DEFAULT_SHEET_ID = "1K2htWL9yNExzEKKWxKcCfQ9jbpBgHqmKayTIqc1gzxE"  # «ROZLICZENIE NOWE 4.0.1»
DEFAULT_SHEET_GID = 2141353545  # arkusz ZESTAWIENIE


class ConfigError(Exception):
    pass


@dataclass(frozen=True)
class Config:
    bot_token: str
    log_dir: Path
    log_level: str
    db: dict  # konfiguracja dla fleet_core.init_backend
    local_db: Path | None
    admin_ids: frozenset
    group_lang: str = "pl"
    office_chat_id: int | None = None
    google_key: Path | None = None  # klucz konta usługi Google (plik JSON, sekret)
    sheet_id: str = ""  # arkusz rozliczeń (GOTÓWKA)
    sheet_gid: int = 0
    sms_url: str = ""  # telefon biura z SMS Gateway (Local Server), np. http://192.168.1.50:8080
    sms_user: str = ""
    sms_password: str = ""  # sekret
    anthropic_key: str = ""  # klucz Claude API (sekret); pusty = asystent AI wyłączony
    ai_model: str = "claude-haiku-5-5"
    ai_effort: str = "low"
    ai_daily_tokens: int = 300000  # dzienny limit tokenów asystenta (0 = bez limitu)


def _ids(text):
    out = set()
    for part in (text or "").replace(";", ",").split(","):
        part = part.strip()
        if part:
            if not part.lstrip("-").isdigit():
                raise ConfigError("ADMIN_IDS: '%s' nie jest liczbą (Telegram-ID)." % part)
            out.add(int(part))
    return frozenset(out)


def load(env_file=None):
    load_dotenv(env_file or ROOT / ".env", override=False, encoding="utf-8-sig")  # Notatnik/PowerShell dodają BOM
    env = lambda k, d="": (os.environ.get(k) or d).strip()  # noqa: E731
    token = env("TELEGRAM_BOT_TOKEN")
    if not token or ":" not in token:
        raise ConfigError("Brak TELEGRAM_BOT_TOKEN w pliku .env (token od @BotFather, postać 123456:ABC...).")
    mode = env("DB_MODE", "cloud").lower()
    local_db = None
    if mode == "cloud":
        url, db_token = env("TURSO_DATABASE_URL"), env("TURSO_AUTH_TOKEN")
        if not url or not db_token:
            raise ConfigError("Brak TURSO_DATABASE_URL lub TURSO_AUTH_TOKEN w pliku .env (ten sam token co w programie).")
        db = {"mode": "cloud", "server": url, "token": db_token}
    elif mode == "local":
        if not env("LOCAL_DB_PATH"):
            raise ConfigError("DB_MODE=local wymaga LOCAL_DB_PATH (ścieżka do kopii bazy).")
        local_db = Path(env("LOCAL_DB_PATH"))
        db = {"mode": "local"}
    else:
        raise ConfigError("DB_MODE musi być cloud albo local.")
    group_lang = env("GROUP_LANG", "pl").lower()
    if group_lang not in ("pl", "ru", "uk"):
        raise ConfigError("GROUP_LANG musi być pl, ru albo uk.")
    office = _ids(env("OFFICE_CHAT_ID"))
    if len(office) > 1:
        raise ConfigError("OFFICE_CHAT_ID: jeden czat biura.")
    return Config(bot_token=token, log_dir=Path(env("LOG_DIR") or ROOT / "logs"), log_level=env("LOG_LEVEL", "INFO").upper(),
                  db=db, local_db=local_db, admin_ids=_ids(env("ADMIN_IDS")), group_lang=group_lang,
                  office_chat_id=next(iter(office), None),
                  google_key=Path(env("GOOGLE_KEY_FILE") or ROOT / "google_service_account.json"),
                  sheet_id=env("SHEET_ID") or DEFAULT_SHEET_ID, sheet_gid=int(env("SHEET_GID") or DEFAULT_SHEET_GID),
                  **_sms(env), **_ai(env))


def _ai(env):
    key = env("ANTHROPIC_API_KEY")
    if not key:
        return {}
    effort = env("AI_EFFORT", "low").lower()
    if effort not in ("low", "medium", "high"):
        raise ConfigError("AI_EFFORT musi być low, medium albo high.")
    limit = env("AI_DAILY_TOKENS", "300000")
    if not limit.isdigit():
        raise ConfigError("AI_DAILY_TOKENS musi być liczbą (0 = bez limitu).")
    return {"anthropic_key": key, "ai_model": env("AI_MODEL", "claude-haiku-5-5"), "ai_effort": effort, "ai_daily_tokens": int(limit)}


def _sms(env):
    url = env("SMS_URL")
    if not url:
        return {}
    if not url.startswith(("http://", "https://")):
        raise ConfigError("SMS_URL musi zaczynać się od http:// (adres z aplikacji SMS Gateway, np. http://192.168.1.50:8080).")
    if not env("SMS_USER") or not env("SMS_PASSWORD"):
        raise ConfigError("SMS_URL wymaga SMS_USER i SMS_PASSWORD (z aplikacji SMS Gateway, sekcja Local Server).")
    return {"sms_url": url, "sms_user": env("SMS_USER"), "sms_password": env("SMS_PASSWORD")}
