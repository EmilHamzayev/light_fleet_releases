"""Asystent AI w czacie biura: zwykła wiadomość -> odpowiedź; zapis tylko po "✅" na karcie.

Wiadomość trafia tu z office.search, gdy nie jest numerem rejestracyjnym ani imieniem kierowcy (te dają kartę od razu,
bez AI). Bez klucza ANTHROPIC_API_KEY asystenta nie ma i bot działa jak dotąd.
"""
import datetime as dt
import logging

from aiogram import F, Router
from aiogram.types import CallbackQuery, Message

from .. import db
from ..ai import tools
from ..i18n import t
from ..outbox import keyboard

log = logging.getLogger("fleetbot.assistant")
router = Router()
STATE_KEYS = {"done": "ai_done", "cancelled": "ai_cancelled", "expired": "ai_expired", "gone": "ai_expired"}


def _zl(n):
    return ("{:,.2f}".format(n or 0)).replace(",", " ").replace(".", ",").replace(",00", "") + " zł"


def _dmy(s):
    return "%s.%s.%s" % (s[8:10], s[5:7], s[:4]) if s else "—"


def _week(week):
    sun = (dt.date.fromisoformat(week) + dt.timedelta(days=6)).isoformat()
    return "%s – %s" % (_dmy(week)[:5], _dmy(sun)[:5])


def card_text(action, a, lang):
    """Tekst karty z danych sprawdzonych przez tools (nie z tekstu modelu)."""
    if action == "record_cash":
        text = t(lang, "ai_card_cash" if a["kind"] == "cash" else "ai_card_invoice", name=a["name"], sum=_zl(a["amount"]),
                 week=_week(a["week"]))
        return text + ("\n📝 " + a["note"] if a.get("note") else "")
    if action == "set_document_date":
        return t(lang, "ai_card_doc", plate=a["plate"], doc=a["label"], date=_dmy(a["date"]), old=_dmy(a.get("old")))
    return action


def card_buttons(pid, lang):
    return [[[t(lang, "ai_btn_ok"), "ai:ok:%d" % pid], [t(lang, "ai_btn_no"), "ai:no:%d" % pid]]]


async def talk(message: Message, lang: str, ai):
    """Pytanie biura do asystenta."""
    await message.bot.send_chat_action(message.chat.id, "typing")
    try:
        r = await ai.reply(message.from_user.id, message.text.strip())
    except db.DbUnavailable:
        return await message.answer(t(lang, "db_unavailable"))
    except Exception:
        log.exception("Asystent: nieoczekiwany błąd")
        return await message.answer(t(lang, "ai_unavailable"))
    if r.text:
        await message.answer(r.text)
    for p in r.pending:
        await message.answer(card_text(p["action"], p["args"], lang) + "\n\n" + t(lang, "ai_card_ask"),
                             reply_markup=keyboard(card_buttons(p["id"], lang)))
    if r.error:
        await message.answer(t(lang, r.error))


@router.callback_query(F.data.startswith("ai:"))
async def decide(cb: CallbackQuery, is_office: bool, lang: str, ai=None):
    if not is_office:
        return await cb.answer()
    try:
        _, what, pid = cb.data.split(":")
        r = await db.call(tools.confirm if what == "ok" else tools.cancel, int(pid), cb.from_user.id)
    except db.DbUnavailable:
        return await cb.answer(t(lang, "db_unavailable"), show_alert=True)
    except ValueError:
        return await cb.answer()
    await cb.answer()
    state = r["state"]
    status = t(lang, "ai_failed", error=r.get("error") or "") if state == "failed" else t(lang, STATE_KEYS.get(state, "ai_expired"))
    card = card_text(r["action"], r["args"], lang) if r.get("action") else ""
    log.info("Asystent: karta %s -> %s (%s)", pid, state, cb.from_user.id)
    if ai is not None and r.get("action") and state in ("done", "cancelled", "failed"):
        ai.note(cb.from_user.id, "biuro: %s -> %s" % (card.replace("\n", ", "), status))
    try:
        await cb.message.edit_text((card + "\n\n" + status).strip())
    except Exception:  # wiadomość za stara do edycji - wyślij nową
        await cb.message.answer((card + "\n\n" + status).strip())
