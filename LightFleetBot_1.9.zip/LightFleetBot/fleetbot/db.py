"""Baza bota = ta sama baza i logika co program (fleet_core).

fleet_core jest synchroniczny i trzyma jedno połączenie, więc wszystkie wywołania idą przez jeden wątek
(tak samo jak POOL w fleet_app.py). Bot czeka na wynik asynchronicznie i nie blokuje Telegrama.
"""
import asyncio
import concurrent.futures
import logging
import os
import sys

from .config import ROOT

sys.path.insert(0, str(ROOT))
import fleet_core as core  # noqa: E402

log = logging.getLogger("fleetbot.db")
POOL = concurrent.futures.ThreadPoolExecutor(max_workers=1, thread_name_prefix="fleetdb")
_state = {"cfg": None, "local_db": None, "ready": False}


class DbUnavailable(Exception):
    pass


def configure(db_cfg, local_db=None):
    _state.update(cfg=db_cfg, local_db=local_db, ready=False)


def _connect():
    if _state["local_db"]:
        p = str(_state["local_db"])
        core.DATA = os.path.dirname(p)
        core.DB = p
        core.BACKUPS = os.path.join(core.DATA, "backups")
        core.PHOTOS = os.path.join(core.DATA, "photos")
    core.init_backend(_state["cfg"])
    _state["ready"] = True
    log.info("Połączono z bazą (%s)", _state["cfg"]["mode"])


def _run(fn, *args):
    if _state["cfg"] is None:
        raise DbUnavailable("Baza nie jest skonfigurowana.")
    try:
        if not _state["ready"]:
            _connect()
        return fn(*args)
    except core.UserError:
        raise
    except (ConnectionError, OSError, RuntimeError) as e:
        _state["ready"] = False  # następne wywołanie połączy się od nowa
        log.warning("Baza niedostępna: %s", e)
        raise DbUnavailable(str(e)) from e


async def call(fn, *args):
    """Wywołanie funkcji fleet_core w wątku bazy."""
    return await asyncio.get_running_loop().run_in_executor(POOL, _run, fn, *args)
