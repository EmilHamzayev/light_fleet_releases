"""Zadania według harmonogramu z nadrabianiem po awarii.

Każde zadanie ma "okres" (np. dzień albo tydzień). Gdy nadejdzie pora, a w job_runs nie ma wpisu za ten okres -
zadanie się wykona. Jeśli bot był wyłączony o tej porze, wykona się zaraz po uruchomieniu (w tym samym okresie).
"""
import asyncio
import datetime as dt
import logging
import time
from dataclasses import dataclass
from typing import Awaitable, Callable

from . import db

log = logging.getLogger("fleetbot.scheduler")
RETRY_AFTER_ERROR = 600  # s - po błędzie zadania nie próbujemy co 30 s


class NotYet(Exception):
    """Zadanie jeszcze nie może się wykonać (np. arkusz nieuzupełniony) - spróbować za `seconds`, bez błędu w dzienniku."""

    def __init__(self, reason, seconds=1800):
        super().__init__(reason)
        self.seconds = seconds


@dataclass
class Job:
    name: str
    period: Callable[[dt.datetime], str | None]  # klucz okresu albo None (jeszcze nie pora)
    run: Callable[[dict], Awaitable[str | None]]  # zwraca krótki wynik do job_runs


def daily(hour, minute=0):
    def period(now):
        return now.date().isoformat() if now.time() >= dt.time(hour, minute) else None
    return period


def weekly(weekday, hour, minute=0):
    """weekday: 0 = poniedziałek ... 6 = niedziela. Okres = tydzień ISO (np. 2026-W45)."""
    def period(now):
        if (now.weekday(), now.time()) < (weekday, dt.time(hour, minute)):
            return None
        y, w, _ = now.isocalendar()
        return "%d-W%02d" % (y, w)
    return period


_wait_until = {}  # (zadanie, okres) -> czas monotoniczny, przed którym nie próbujemy


async def tick(jobs, ctx, now=None):
    now = now or dt.datetime.now()
    done = []
    for job in jobs:
        p = job.period(now)
        if not p or time.monotonic() < _wait_until.get((job.name, p), 0):
            continue
        if await db.call(db.core.job_done, job.name, p):
            continue
        log.info("Zadanie %s (%s): start", job.name, p)
        try:
            result = await job.run(ctx)
        except db.DbUnavailable:
            raise
        except NotYet as e:
            log.info("Zadanie %s (%s): jeszcze nie - %s; ponowię za %d min", job.name, p, e, e.seconds // 60)
            _wait_until[(job.name, p)] = time.monotonic() + e.seconds
            continue
        except Exception:
            log.exception("Zadanie %s (%s): błąd - ponowię za %d min", job.name, p, RETRY_AFTER_ERROR // 60)
            _wait_until[(job.name, p)] = time.monotonic() + RETRY_AFTER_ERROR
            continue
        await db.call(db.core.job_mark, job.name, p, (result or "")[:500])
        log.info("Zadanie %s (%s): gotowe %s", job.name, p, result or "")
        done.append((job.name, p))
    return done


async def loop(jobs, ctx, interval=30):
    while True:
        try:
            await tick(jobs, ctx)
        except db.DbUnavailable:
            pass
        except Exception:
            log.exception("Błąd harmonogramu")
        await asyncio.sleep(interval)
