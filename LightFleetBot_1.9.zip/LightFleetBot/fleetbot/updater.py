"""Samoaktualizacja bota (co godzinę): nowa wersja z repozytorium aktualizacji -> podmiana plików -> restart przez usługę.

Nie ruszamy: .env, klucza Google, .venv, logs, nssm.exe. Przy nowych bibliotekach - pip install w .venv.
Gdy coś się nie uda, stare pliki wracają. W kopii roboczej (jest .git) bot się nie aktualizuje.
"""
import asyncio
import json
import logging
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

from . import db
from .config import ROOT

sys.path.insert(0, str(ROOT))
import updates  # noqa: E402

log = logging.getLogger("fleetbot.updater")
EVERY = 3600
PROTECTED = {".env", "google_service_account.json", ".venv", "logs", "nssm.exe", "_update_new", "_update_old", ".git"}
MARKER = "updated.json"


def is_dev(root=ROOT):
    return (Path(root) / ".git").exists()


def apply(zip_path, version, root=ROOT, pip=None):
    """Rozpakowuje archiwum bota na miejsce obecnych plików. Zwraca listę podmienionych plików."""
    root = Path(root)
    new, old = root / "_update_new", root / "_update_old"
    for d in (new, old):
        shutil.rmtree(d, ignore_errors=True)
    with zipfile.ZipFile(zip_path) as z:
        z.extractall(new)
    src = new / "LightFleetBot"
    if not (src / "fleet_core.py").exists() or not (src / "fleetbot" / "__main__.py").exists():
        shutil.rmtree(new, ignore_errors=True)
        raise updates.UpdateError("Archiwum bota jest niekompletne.")
    files = [p for p in src.rglob("*") if p.is_file() and not (PROTECTED & set(p.relative_to(src).parts))]
    req_before = (root / "requirements-bot.txt").read_text(encoding="utf-8") if (root / "requirements-bot.txt").exists() else ""
    done = []
    try:
        for p in files:
            rel = p.relative_to(src)
            dest = root / rel
            if dest.exists():
                (old / rel).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dest, old / rel)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dest)
            done.append(rel)
        if (root / "requirements-bot.txt").read_text(encoding="utf-8") != req_before:
            (pip or _pip)(root)
    except Exception:
        for rel in done:  # przywrócenie starych plików
            if (old / rel).exists():
                shutil.copy2(old / rel, root / rel)
            else:
                (root / rel).unlink(missing_ok=True)
        raise
    finally:
        shutil.rmtree(new, ignore_errors=True)
    shutil.rmtree(old, ignore_errors=True)
    (root / "logs").mkdir(exist_ok=True)
    (root / "logs" / MARKER).write_text(json.dumps({"version": version}), encoding="utf-8")
    return [str(r) for r in done]


def _pip(root):
    py = Path(root) / ".venv" / "Scripts" / "python.exe"
    if not py.exists():
        py = Path(sys.executable)
    r = subprocess.run([str(py), "-m", "pip", "install", "-q", "-r", str(Path(root) / "requirements-bot.txt")],
                       capture_output=True, text=True, timeout=900)
    if r.returncode != 0:
        raise updates.UpdateError("pip install nie powiódł się: %s" % (r.stderr or r.stdout)[-500:])


async def check_once(stop, current=None):
    """True = zaktualizowano, bot się zatrzymuje (usługa uruchomi nową wersję)."""
    current = current or db.core.VERSION
    m = await asyncio.to_thread(updates.manifest)
    if not updates.newer(m["version"], current) or not m.get("bot"):
        return False
    log.info("Nowa wersja bota %s (jest %s) - pobieram", m["version"], current)
    zip_path = await asyncio.to_thread(updates.download, m["bot"])
    files = await asyncio.to_thread(apply, zip_path, m["version"])
    log.info("Zaktualizowano %d plików do %s - restart", len(files), m["version"])
    await stop()
    return True


async def announce(cfg, root=ROOT):
    """Po restarcie z nową wersją: wiadomość do biura (raz)."""
    marker = Path(root) / "logs" / MARKER
    if not marker.exists():
        return
    try:
        v = json.loads(marker.read_text(encoding="utf-8"))["version"]
        if cfg.office_chat_id:
            from .i18n import t
            await db.call(db.core.outbox_add, cfg.office_chat_id, t(cfg.group_lang, "bot_updated", version=v), "bot_updated:" + v)
        marker.unlink()
    except db.DbUnavailable:
        pass  # spróbujemy przy następnym starcie
    except Exception:
        log.exception("Nie udało się ogłosić aktualizacji")
        marker.unlink(missing_ok=True)


async def loop(cfg, stop, first_delay=120):
    if is_dev():
        log.info("Kopia robocza (.git) - samoaktualizacja wyłączona")
        return
    await asyncio.sleep(first_delay)
    while True:
        try:
            if await check_once(stop):
                return
        except updates.UpdateError as e:
            log.warning("Aktualizacja: %s", e)
        except Exception:
            log.exception("Błąd aktualizacji")
        await asyncio.sleep(EVERY)
