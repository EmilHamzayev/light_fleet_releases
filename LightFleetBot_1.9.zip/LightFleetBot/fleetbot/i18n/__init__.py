"""Teksty bota w trzech językach (pl, ru, uk). Brak tekstu w języku -> polski."""
import json
from pathlib import Path

LANGS = ("pl", "ru", "uk")
DEFAULT = "pl"
LABELS = {"pl": "🇵🇱 Polski", "ru": "🇷🇺 Русский", "uk": "🇺🇦 Українська"}
_T = {lang: json.loads((Path(__file__).parent / ("%s.json" % lang)).read_text(encoding="utf-8")) for lang in LANGS}


def t(lang, key, **kw):
    text = _T.get(lang if lang in LANGS else DEFAULT, {}).get(key) or _T[DEFAULT][key]
    return text.format(**kw) if kw else text
