"""Bot Telegram LIGHT Fleet Manager: ta sama baza i logika co program (fleet_core.py)."""
