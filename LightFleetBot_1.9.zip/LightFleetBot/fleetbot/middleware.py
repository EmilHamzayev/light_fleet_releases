"""Kim jest użytkownik (dla każdej wiadomości): język, rola (biuro / kierowca), przypięty kierowca.

Dane z bazy (tg_users), w pamięci podręcznej bota; po zmianie (język, kod) handler zapisuje nowe dane w `users`.
ADMIN_IDS z .env to zawsze biuro. W grupie język = GROUP_LANG. Bez wyboru języka - polski.
"""
import logging

from aiogram import BaseMiddleware

from . import db, i18n

log = logging.getLogger("fleetbot.user")
EMPTY = {"lang": None, "role": None, "driver_id": None, "driver": None}


class UserMiddleware(BaseMiddleware):
    def __init__(self, group_lang, admin_ids):
        self.group_lang = group_lang
        self.admin_ids = admin_ids
        self.cache = {}

    async def __call__(self, handler, event, data):
        user = data.get("event_from_user")
        chat = data.get("event_chat")
        data["users"] = self.cache
        me = EMPTY
        if user is not None:
            if user.id not in self.cache:
                try:
                    self.cache[user.id] = await db.call(db.core.tg_user, user.id)
                except db.DbUnavailable:
                    pass  # bez zapamiętania - spróbujemy przy następnej wiadomości
            me = self.cache.get(user.id, EMPTY)
        data["me"] = me
        data["is_admin"] = user is not None and user.id in self.admin_ids
        data["is_office"] = data["is_admin"] or me["role"] == "office"
        group = chat is not None and chat.type in ("group", "supergroup")
        data["lang"] = self.group_lang if group else (me["lang"] or i18n.DEFAULT)
        return await handler(event, data)
