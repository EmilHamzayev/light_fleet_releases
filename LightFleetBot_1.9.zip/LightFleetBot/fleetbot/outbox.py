"""Wysyłka kolejki wiadomości (tabela outbox).

Każda wiadomość bota (przypomnienie, raport) najpierw trafia do bazy, potem jest wysyłana.
Brak internetu -> wiadomość czeka i wychodzi po powrocie sieci. Klucz w outbox chroni przed duplikatami.
"""
import asyncio
import logging

from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramNetworkError, TelegramRetryAfter
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from . import db

log = logging.getLogger("fleetbot.outbox")


def keyboard(buttons):
    """buttons: [[[tekst, callback_data], ...], ...] (wiersze przycisków)."""
    if not buttons:
        return None
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=t, callback_data=d) for t, d in row] for row in buttons])


async def send_due(bot, limit=20):
    """Jedna runda wysyłki. Zwraca (wysłane, odrzucone, czy_sieć_działa)."""
    sent = failed = 0
    for r in await db.call(db.core.outbox_due, limit):
        try:
            m = await bot.send_message(r["chat_id"], r["text"], reply_markup=keyboard(r["buttons"]))
        except TelegramRetryAfter as e:  # limit Telegrama - poczekać i dokończyć później
            log.warning("Telegram każe czekać %s s", e.retry_after)
            await asyncio.sleep(e.retry_after)
            return sent, failed, True
        except TelegramNetworkError as e:  # brak sieci - nie liczymy próby, spróbujemy później
            log.warning("Brak połączenia z Telegramem: %s", e)
            return sent, failed, False
        except (TelegramForbiddenError, TelegramBadRequest) as e:  # czat nie istnieje / bot zablokowany
            log.error("Wiadomość %s do %s odrzucona: %s", r["id"], r["chat_id"], e)
            await db.call(db.core.outbox_failed, r["id"], e, True)
            failed += 1
            continue
        except Exception as e:
            log.exception("Wiadomość %s: błąd wysyłki", r["id"])
            await db.call(db.core.outbox_failed, r["id"], e)
            failed += 1
            continue
        await db.call(db.core.outbox_sent, r["id"], m.message_id)
        log.info("Wysłano wiadomość %s do %s", r["id"], r["chat_id"])
        sent += 1
    return sent, failed, True


async def loop(bot, interval=5):
    while True:
        try:
            await send_due(bot)
        except db.DbUnavailable:
            pass  # baza wróci - kolejka czeka w bazie
        except Exception:
            log.exception("Błąd pętli wysyłki")
        await asyncio.sleep(interval)
