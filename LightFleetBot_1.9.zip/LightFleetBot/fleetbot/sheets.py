"""Arkusz rozliczeń Google (tylko odczyt): kolumna GOTÓWKA dla kierowców floty.

Czytamy wyłącznie: datę rozliczenia (pierwszy wiersz, komórka po "ROZLICZENIE") oraz z wierszy kierowców -
MIASTO, ID, Forma, Imię i nazwisko, GOTÓWKA. Kogo brać, decyduje lista kierowców floty w programie (nie tylko FLT -
biuro może wpisać do floty kierowcę z innej formy). Nagłówek ("Forma") może się powtarzać (bloki).
"""
import re
from dataclasses import dataclass

SCOPES = ["https://www.googleapis.com/auth/spreadsheets.readonly"]
NEED = ("MIASTO", "ID", "Forma", "Imię, Nazwisko", "GOTÓWKA")


@dataclass
class CashRow:
    row: int
    miasto: str
    sheet_key: str
    forma: str
    name: str
    cash: float | None


def parse_amount(text):
    """'1 157,10' / '432,38' / '' -> liczba albo None."""
    t = re.sub(r"[\s zł]", "", text or "").replace(",", ".")
    if not t:
        return None
    try:
        return round(float(t), 2)
    except ValueError:
        return None


def to_iso(text):
    """'02.11.2026' -> '2026-11-02' (inne zapisy bez zmian)."""
    m = re.fullmatch(r"(\d{1,2})\.(\d{1,2})\.(\d{4})", (text or "").strip())
    return "%s-%02d-%02d" % (m.group(3), int(m.group(2)), int(m.group(1))) if m else text


def parse(values):
    """values = wszystkie komórki arkusza (lista wierszy). Zwraca (data_rozliczenia, [CashRow - wiersze kierowców])."""
    period = None
    first = [c.strip() for c in (values[0] if values else [])]
    for i, c in enumerate(first):
        if c.upper().startswith("ROZLICZENIE"):
            period = to_iso(next((x for x in first[i + 1:] if x), None))
            break
    cols, out = None, []
    for i, r in enumerate(values, 1):
        cells = [c.strip() for c in r]
        if "Forma" in cells:
            cols = {n: cells.index(n) for n in NEED if n in cells}
            if set(NEED) - set(cols):
                raise ValueError("Brak kolumn w nagłówku (wiersz %d): %s" % (i, ", ".join(sorted(set(NEED) - set(cols)))))
            continue
        if not cols:
            continue
        get = lambda n: cells[cols[n]] if cols[n] < len(cells) else ""  # noqa: E731
        if not get("Forma") or not get("Imię, Nazwisko"):  # wiersze sum, puste
            continue
        out.append(CashRow(i, get("MIASTO"), get("ID"), get("Forma"), " ".join(get("Imię, Nazwisko").split()),
                           parse_amount(get("GOTÓWKA"))))
    return period, out


def read(key_file, sheet_id, gid):
    import gspread
    from google.oauth2.service_account import Credentials
    creds = Credentials.from_service_account_file(str(key_file), scopes=SCOPES)
    ws = gspread.authorize(creds).open_by_key(sheet_id).get_worksheet_by_id(int(gid))
    return parse(ws.get_all_values())


def match(rows, drivers, norm):
    """Kierowcy floty z programu <-> wiersze arkusza: najpierw po ID z arkusza, potem po imieniu.
    Zwraca (pary [(kierowca, wiersz)], brak_w_arkuszu [kierowca], podwójne [kierowca])."""
    by_key, by_name = {}, {}
    for r in rows:
        by_key.setdefault(r.sheet_key, []).append(r)
        by_name.setdefault(norm(r.name), []).append(r)
    pairs, missing, doubles = [], [], []
    for d in drivers:
        found = (by_key.get(d.get("sheet_key")) if d.get("sheet_key") else None) or by_name.get(norm(d["name"])) or []
        if not found:
            missing.append(d)
        elif len(found) > 1:
            doubles.append(d)
        else:
            pairs.append((d, found[0]))
    return pairs, missing, doubles
