"""Uruchomienie: python -m fleetbot (long polling, bez webhooka i otwierania portów)."""
import asyncio
import logging
import sys

from aiogram import Bot, Dispatcher

from . import commands, config, db, jobs, lock, logs, outbox, scheduler, updater
from .handlers import router
from .middleware import UserMiddleware


async def set_commands(bot, admin_ids):
    await commands.set_default(bot)
    try:
        office = await db.call(db.core.tg_office_ids)
    except db.DbUnavailable:
        office = []
    for uid in set(admin_ids) | set(office):
        await commands.set_for_chat(bot, uid, office=True, admin=uid in admin_ids)


async def run(cfg):
    log = logging.getLogger("fleetbot")
    db.configure(cfg.db, cfg.local_db)
    await lock.acquire()  # przed Telegramem: drugi egzemplarz nie odbiera wiadomości i nic nie wysyła
    bot = Bot(cfg.bot_token)
    me = await bot.get_me()
    dp = Dispatcher(admin_ids=cfg.admin_ids, bot_username=me.username)
    user_mw = UserMiddleware(cfg.group_lang, cfg.admin_ids)
    dp.message.middleware(user_mw)
    dp.callback_query.middleware(user_mw)
    dp.include_router(router())
    await set_commands(bot, cfg.admin_ids)
    if cfg.office_chat_id is None:
        log.warning("Brak OFFICE_CHAT_ID - przypomnienia i raporty nie będą wysyłane do biura")
    tasks = [asyncio.create_task(outbox.loop(bot)),
             asyncio.create_task(scheduler.loop(jobs.all_jobs(), {"cfg": cfg, "bot": bot})),
             asyncio.create_task(lock.keep(dp.stop_polling)),
             asyncio.create_task(updater.loop(cfg, dp.stop_polling))]
    await updater.announce(cfg)
    log.info("Bot @%s uruchomiony (long polling)", me.username)
    try:
        await dp.start_polling(bot, handle_signals=False)
    finally:
        for t in tasks:
            t.cancel()
        await lock.release()
        await bot.session.close()
        log.info("Bot zatrzymany")


async def check(cfg):
    """Sprawdzenie przed instalacją: baza i Telegram odpowiadają (bez zamka i bez odbierania wiadomości)."""
    db.configure(cfg.db, cfg.local_db)
    k = (await db.call(db.core.dashboard))["kpi"]
    print("Baza: OK (%s), samochody: %d" % (cfg.db["mode"], k["cars"]))
    bot = Bot(cfg.bot_token)
    try:
        me = await bot.get_me()
        print("Telegram: OK (@%s)" % me.username)
    finally:
        await bot.session.close()
    h = await db.call(db.core.bot_lock_holder)
    print("Zamek: %s" % ("wolny" if not h["owner"] else "%s, ostatni sygnał %s" % (h["owner"], h["heartbeat_at"])))
    print("Czat biura: %s" % (cfg.office_chat_id or "BRAK OFFICE_CHAT_ID"))


def main():
    try:
        cfg = config.load()
    except config.ConfigError as e:
        print(e, file=sys.stderr)
        return 2
    if "--check" in sys.argv[1:]:
        try:
            asyncio.run(check(cfg))
        except Exception as e:
            print("BŁĄD: %s" % e, file=sys.stderr)
            return 1
        return 0
    log = logs.setup(cfg.log_dir, cfg.log_level)
    try:
        asyncio.run(run(cfg))
    except lock.LockTaken as e:
        log.error("%s - ten egzemplarz kończy pracę", e)
        return lock.EXIT_LOCKED
    except KeyboardInterrupt:
        pass
    except Exception:
        log.exception("Bot zakończył się błędem")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
