"""Komendy biura (administratorzy z .env i pracownicy przypięci kodem biura). Język - wybrany przez użytkownika.

/status, /gotowka [miasto], /flota [miasto], /pomoc oraz zwykła wiadomość: numer rejestracyjny albo imię kierowcy
-> karta samochodu / kierowcy. Bez AI - tylko dane z bazy.
"""
import datetime as dt
import logging

from aiogram import F, Router
from aiogram.filters import Command, CommandObject
from aiogram.types import Message

from .. import db
from ..i18n import t

log = logging.getLogger("fleetbot.office")
router = Router()
CITIES = ("Toruń", "Grudziądz")


def _zl(n):
    """5588.64 -> '5 588,64 zł', 600 -> '600 zł' (jak w programie)."""
    return ("{:,.2f}".format(n or 0)).replace(",", " ").replace(".", ",").replace(",00", "") + " zł"


def _dm(s):
    return "%s.%s" % (s[8:10], s[5:7])


def _dmy(s):
    return "%s.%s.%s" % (s[8:10], s[5:7], s[:4])


def _week(lang, week):
    sun = (dt.date.fromisoformat(week) + dt.timedelta(days=6)).isoformat()
    return t(lang, "week_range", mon=_dm(week), sun=_dm(sun))


def _doc(lang, date, days):
    if not date:
        return t(lang, "doc_none")
    if days < 0:
        return t(lang, "doc_over", date=_dmy(date), n=-days)
    return t(lang, "doc_left", date=_dmy(date), n=days) if days <= 30 else _dmy(date)


def _city(arg):
    """'torun' / 'Toruń' / 'grudz' -> nazwa miasta albo None."""
    a = (arg or "").strip().casefold().replace("ń", "n").replace("ą", "a")
    if not a:
        return None
    return next((c for c in CITIES if c.casefold().replace("ń", "n").replace("ą", "a").startswith(a[:4])), None)


def status_text(d, lang="pl", fleet=None):
    k, w = d["kpi"], d["week"]
    lines = [
        t(lang, "status_title"),
        t(lang, "status_cars", cars=k["cars"], busy=k["busy"], free=k["free"]),
        t(lang, "status_week", number=w["number"], mon=_dm(w["monday"]), sun=_dm(w["sunday"]), paid=k["week_paid_n"],
          n=k["week_n"], got=_zl(k["week_got"]), waiting=_zl(k["week_waiting"])),
        t(lang, "status_owners", n=k["contr_unpaid_n"], sum=_zl(k["contr_unpaid"])),
        t(lang, "status_no_docs", n=k["no_docs"]),
    ]
    if fleet and (fleet["cars"] or fleet["drivers"]):
        fk = fleet["kpi"]
        lines += ["", t(lang, "status_fleet", cars=fk["cars"], drivers=fk["drivers"], free=fk["free"])]
        for c in CITIES:
            nc = sum(1 for x in fleet["cars"] if x["city"] == c)
            nd = sum(1 for x in fleet["drivers"] if x["city"] == c)
            if nc or nd:
                lines.append(t(lang, "status_fleet_city", city=c, cars=nc, drivers=nd))
        if fleet["cash_week"]:
            total = sum(x["cash"] or 0 for x in fleet["drivers"])
            lines.append(t(lang, "status_cash", week=_week(lang, fleet["cash_week"]), sum=_zl(total)))
            for c in CITIES:
                s = [x["cash"] or 0 for x in fleet["drivers"] if x["city"] == c and x["cash"] is not None]
                if s:
                    lines.append(t(lang, "status_cash_city", city=c, sum=_zl(sum(s))))
    if d["alerts"]:
        lines += ["", t(lang, "status_alerts")]
        lines += ["• %s — %s" % (a["plate"], a["text"]) for a in d["alerts"][:10]]
        if len(d["alerts"]) > 10:
            lines.append(t(lang, "status_more", n=len(d["alerts"]) - 10))
    return "\n".join(lines)


def cash_text(fleet, lang, city=None):
    if not fleet["cash_week"]:
        return t(lang, "cash_none")
    rows = [d for d in fleet["drivers"] if d["cash"] is not None and (not city or d["city"] == city)]
    lines = [t(lang, "cash_list_title", week=_week(lang, fleet["cash_week"]), city=" · " + city if city else "")]
    for c in ([city] if city else list(CITIES) + [None]):
        part = sorted((d for d in rows if d["city"] == c), key=lambda d: -(d["cash"] or 0))
        if not part:
            continue
        if not city:
            lines += ["", "📍 %s" % (c or "—")]
        lines += ["%s — %s" % (d["name"], _zl(d["cash"])) for d in part]
    lines += ["", t(lang, "cash_total", sum=_zl(sum(d["cash"] or 0 for d in rows)), n=len(rows))]
    return "\n".join(lines)


def _person(lang, m):
    return m["name"] if m else t(lang, "shift_free")


def fleet_text(fleet, lang, city=None):
    cars = [c for c in fleet["cars"] if not city or c["city"] == city]
    if not cars:
        return t(lang, "flota_none")
    lines = [t(lang, "flota_title", city=" · " + city if city else "", n=len(cars))]
    for c in cars:
        lines += ["", "🚕 %s %s" % (c["plate"], c["model"] or ""),
                  t(lang, "flota_shifts", day=_person(lang, c["day"]), night=_person(lang, c["night"])),
                  t(lang, "car_docs", oc=_doc(lang, c["oc_until"], c["oc_days"]), prz=_doc(lang, c["przeglad_until"], c["prz_days"]))]
    free = [d["name"] for d in fleet["drivers"] if not d["plate"] and (not city or d["city"] == city)]
    if free:
        lines += ["", t(lang, "flota_no_car", names=", ".join(free))]
    return "\n".join(lines)


def car_card(c, lang):
    lines = ["🚗 %s — %s" % (c["plate"], c["model"] or ""),
             t(lang, "kind_fleet") + (" · " + c["city"] if c.get("city") else "") if c["kind"] == "fleet" else t(lang, "kind_rent")]
    if c["kind"] == "fleet":
        lines.append(t(lang, "flota_shifts", day=_person(lang, c["day"]), night=_person(lang, c["night"])))
    else:
        lines.append(t(lang, "car_driver", name=c["driver"] or t(lang, "car_free")))
    lines.append(t(lang, "car_docs", oc=_doc(lang, c["oc_until"], c["oc_days"]), prz=_doc(lang, c["przeglad_until"], c["prz_days"])))
    if c["oil_left"] is not None:
        lines.append(t(lang, "car_oil", n=c["oil_left"]) if c["oil_left"] > 0 else t(lang, "car_oil_over", n=-c["oil_left"]))
    lines.append(t(lang, "car_mileage", n=c["mileage"] or 0))
    return "\n".join(lines)


def driver_card(d, lang, cash_week=None):
    lines = ["👤 " + d["name"], t(lang, "kind_fleet") + (" · " + d["city"] if d["city"] else "") if d["kind"] == "fleet" else t(lang, "kind_rent")]
    shift = " · " + t(lang, "shift_" + d["shift"]) if d.get("shift") else ""
    lines.append(t(lang, "drv_car", car=(d["plate"] + shift) if d["plate"] else "—"))
    if d["phone"]:
        lines.append(t(lang, "drv_phone", phone=d["phone"]))
    if d["kind"] == "fleet" and cash_week:
        lines.append(t(lang, "drv_cash", week=_week(lang, cash_week), sum=_zl(d["cash"]) if d["cash"] is not None else "—"))
    lines.append(t(lang, "drv_tg_yes" if d["tg"] else "drv_tg_no"))
    return "\n".join(lines)


async def _data(message, lang, *calls):
    try:
        return [await db.call(*c) for c in calls]
    except db.DbUnavailable:
        await message.answer(t(lang, "db_unavailable"))
        return None


@router.message(Command("status"))
async def status(message: Message, is_office: bool, lang: str):
    if not is_office:
        return log.warning("/status bez uprawnień od %s", message.from_user.id if message.from_user else None)
    log.info("/status od %s", message.from_user.id)
    r = await _data(message, lang, (db.core.dashboard,), (db.core.fleet_view,))
    if r:
        await message.answer(status_text(r[0], lang, r[1]))


@router.message(Command("gotowka"))
async def gotowka(message: Message, command: CommandObject, is_office: bool, lang: str):
    if not is_office:
        return
    r = await _data(message, lang, (db.core.fleet_view,))
    if r:
        await message.answer(cash_text(r[0], lang, _city(command.args)))


@router.message(Command("flota"))
async def flota(message: Message, command: CommandObject, is_office: bool, lang: str):
    if not is_office:
        return
    r = await _data(message, lang, (db.core.fleet_view,))
    if r:
        await message.answer(fleet_text(r[0], lang, _city(command.args)))


@router.message(Command("pomoc"))
async def pomoc(message: Message, is_office: bool, lang: str):
    await message.answer(t(lang, "help_office" if is_office else "help_driver"))


@router.message(F.chat.type == "private", F.text, ~F.text.startswith("/"))
async def search(message: Message, is_office: bool, lang: str):
    """Biuro pisze numer albo imię -> karta. Kierowca - krótka pomoc."""
    if not is_office:
        return await message.answer(t(lang, "help_driver"))
    q = message.text.strip()
    log.info("Szukaj od %s: %d znaków", message.from_user.id, len(q))
    r = await _data(message, lang, (db.core.office_search, q))
    if not r:
        return
    res = r[0]
    cards = [car_card(c, lang) for c in res["cars"]] + [driver_card(d, lang, res["cash_week"]) for d in res["drivers"]]
    if not cards:
        return await message.answer(t(lang, "search_none", q=q))
    text = "\n\n".join(cards)
    if res["more"]:
        text += "\n\n" + t(lang, "search_more")
    await message.answer(text)
