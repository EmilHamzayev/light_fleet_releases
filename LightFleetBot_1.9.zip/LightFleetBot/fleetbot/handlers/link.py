"""Przypięcie Telegrama: biuro wydaje jednorazowy kod, kierowca/pracownik go wpisuje (albo otwiera link).

/kod <nazwisko lub telefon>  - kod dla kierowcy (biuro)
/kod_biuro                   - kod dla nowego pracownika biura (tylko administratorzy z .env)
/ja                          - kim jestem
"""
import logging
import re
import time

from aiogram import F, Router
from aiogram.dispatcher.event.bases import SkipHandler
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from .. import commands, db
from ..i18n import t
from .basic import ask_lang

log = logging.getLogger("fleetbot.link")
router = Router()

CODE_RE = re.compile(r"^(?=.*\d)[A-Za-z0-9]{4}[ -]?[A-Za-z0-9]{4}$")  # kod zawsze ma cyfrę - zwykłe słowa nie pasują
MAX_FAILS, BLOCK_SECONDS = 5, 3600
ERRORS = {"Nieprawidłowy kod.": "code_bad", "Kierowca nie istnieje.": "code_bad",
          "Kod został już użyty.": "code_used", "Kod wygasł.": "code_expired"}
_fails = {}  # telegram_id -> czasy nieudanych prób (ochrona przed zgadywaniem)


def blocked(uid, now=None):
    now = now or time.time()
    recent = [x for x in _fails.get(uid, []) if now - x < BLOCK_SECONDS]
    _fails[uid] = recent
    return len(recent) >= MAX_FAILS


def _fmt_until(s):
    return "%s.%s.%s %s" % (s[8:10], s[5:7], s[:4], s[11:16])


async def use_code(message: Message, code: str, lang: str, users: dict, me: dict, bot_username: str, admin_ids: frozenset):
    uid = message.from_user.id
    if blocked(uid):
        log.warning("Kod: zablokowany %s", uid)
        return await message.answer(t(lang, "code_blocked"))
    try:
        r = await db.call(db.core.link_code_use, uid, code)
    except db.core.UserError as e:
        _fails.setdefault(uid, []).append(time.time())
        log.warning("Kod odrzucony dla %s: %s", uid, e)
        return await message.answer(t(lang, ERRORS.get(str(e), "code_bad")))
    except db.DbUnavailable:
        return await message.answer(t(lang, "db_unavailable"))
    _fails.pop(uid, None)
    users[uid] = dict(me, role=r["role"], driver_id=r["driver_id"], driver=r["driver"])
    log.info("Przypięto %s jako %s (kierowca %s)", uid, r["role"], r["driver_id"])
    if r["role"] == "office":
        await message.answer(t(lang, "code_ok_office"))
        await commands.set_for_chat(message.bot, uid, office=True, admin=uid in admin_ids)
    else:
        await message.answer(t(lang, "code_ok_driver", name=r["driver"]))
    if not me["lang"]:
        await ask_lang(message)


@router.message(CommandStart(deep_link=True))
async def start_with_code(message: Message, command: CommandObject, lang: str, users: dict, me: dict, bot_username: str,
                          admin_ids: frozenset):
    if command.args and CODE_RE.match(command.args):
        return await use_code(message, command.args, lang, users, me, bot_username, admin_ids)
    await ask_lang(message)


@router.message(F.chat.type == "private", F.text.regexp(CODE_RE))
async def typed_code(message: Message, lang: str, users: dict, me: dict, bot_username: str, admin_ids: frozenset,
                     is_office: bool):
    if me["role"] or is_office:  # już przypięty / biuro - to nie kod, tylko np. numer rejestracyjny (wyszukiwanie)
        raise SkipHandler()
    await use_code(message, message.text.strip(), lang, users, me, bot_username, admin_ids)


def _issued(lang, key, code, bot_username, **kw):
    return t(lang, key, code="%s-%s" % (code["code"][:4], code["code"][4:]), until=_fmt_until(code["expires_at"]),
             link="https://t.me/%s?start=%s" % (bot_username, code["code"]), **kw)


async def _issue_driver(message, lang, bot_username, driver, office_id):
    try:
        code = await db.call(db.core.link_code_create, "driver", office_id, driver["id"])
    except db.DbUnavailable:
        return await message.answer(t(lang, "db_unavailable"))
    log.info("Kod dla kierowcy %s wydał %s", driver["id"], office_id)
    await message.answer(_issued(lang, "kod_issued", code, bot_username, name=driver["name"]))


@router.message(Command("kod"))
async def kod(message: Message, command: CommandObject, lang: str, is_office: bool, bot_username: str):
    if not is_office:
        return log.warning("/kod bez uprawnień od %s", message.from_user.id)
    query = (command.args or "").strip().lower()
    if len(query) < 2:
        return await message.answer(t(lang, "kod_usage"))
    try:
        drivers = await db.call(db.core.drivers_list, "active", None)
    except db.DbUnavailable:
        return await message.answer(t(lang, "db_unavailable"))
    digits = re.sub(r"\D", "", query)
    found = [d for d in drivers if query in d["name"].lower() or (len(digits) >= 3 and digits in re.sub(r"\D", "", d["phone"] or ""))]
    if not found:
        return await message.answer(t(lang, "kod_none", q=command.args.strip()))
    if len(found) == 1:
        return await _issue_driver(message, lang, bot_username, found[0], message.from_user.id)
    if len(found) > 10:
        return await message.answer(t(lang, "kod_too_many", n=len(found)))
    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=d["name"], callback_data="kod:%d" % d["id"])] for d in found])
    await message.answer(t(lang, "kod_many"), reply_markup=kb)


@router.callback_query(F.data.startswith("kod:"))
async def kod_pick(cb: CallbackQuery, lang: str, is_office: bool, bot_username: str):
    if not is_office:
        return await cb.answer()
    did = int(cb.data.split(":", 1)[1])
    try:
        driver = next((d for d in await db.call(db.core.drivers_list, "active", None) if d["id"] == did), None)
    except db.DbUnavailable:
        return await cb.answer(t(lang, "db_unavailable"), show_alert=True)
    await cb.answer()
    if driver:
        await _issue_driver(cb.message, lang, bot_username, driver, cb.from_user.id)


@router.message(Command("kod_biuro"))
async def kod_biuro(message: Message, lang: str, is_admin: bool, bot_username: str):
    if not is_admin:
        return log.warning("/kod_biuro bez uprawnień od %s", message.from_user.id)
    try:
        code = await db.call(db.core.link_code_create, "office", message.from_user.id)
    except db.DbUnavailable:
        return await message.answer(t(lang, "db_unavailable"))
    log.info("Kod biura wydał %s", message.from_user.id)
    await message.answer(_issued(lang, "kod_office_issued", code, bot_username))


@router.message(Command("ja"))
async def whoami(message: Message, lang: str, me: dict, is_admin: bool, is_office: bool):
    if is_admin:
        text = t(lang, "me_admin")
    elif is_office:
        text = t(lang, "me_office")
    elif me["role"] == "driver" and me["driver"]:
        text = t(lang, "me_driver", name=me["driver"])
    else:
        text = t(lang, "me_none")
    await message.answer(text)
