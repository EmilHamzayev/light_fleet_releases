from aiogram import Router

from . import basic, link, office


def router():
    r = Router()
    r.include_router(link.router)  # przed basic: /start z kodem
    r.include_router(basic.router)
    r.include_router(office.router)
    return r
