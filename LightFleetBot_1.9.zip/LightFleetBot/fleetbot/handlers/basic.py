"""Podstawowe komendy: /start i /lang (wybór języka), /ping (sprawdzenie, że bot działa)."""
import datetime as dt
import logging

from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from .. import db, i18n
from ..i18n import t

log = logging.getLogger("fleetbot.basic")
router = Router()


def ping_text(now=None, lang="pl"):
    return t(lang, "pong", time=(now or dt.datetime.now()).strftime("%d.%m.%Y %H:%M:%S"))


def lang_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=i18n.LABELS[x], callback_data="lang:" + x)]
                                                 for x in i18n.LANGS])


async def ask_lang(message: Message):
    await message.answer(t("pl", "choose_lang"), reply_markup=lang_keyboard())


@router.message(CommandStart())
@router.message(Command("lang"))
async def choose_lang(message: Message):
    log.info("%s od %s", (message.text or "").split()[0], message.from_user.id if message.from_user else "?")
    await ask_lang(message)


@router.callback_query(F.data.startswith("lang:"))
async def set_lang(cb: CallbackQuery, users: dict, me: dict):
    lang = cb.data.split(":", 1)[1]
    if lang not in i18n.LANGS:
        return await cb.answer()
    try:
        await db.call(db.core.tg_set_lang, cb.from_user.id, lang)
    except db.DbUnavailable:
        return await cb.answer(t(lang, "db_unavailable"), show_alert=True)
    users[cb.from_user.id] = dict(me, lang=lang)
    log.info("Język %s dla %s", lang, cb.from_user.id)
    await cb.message.edit_text("%s\n\n%s" % (t(lang, "lang_set"), t(lang, "welcome")))
    await cb.answer()


@router.message(Command("ping"))
async def ping(message: Message, lang: str):
    log.info("/ping od %s (chat %s)", message.from_user.id if message.from_user else "?", message.chat.id)
    await message.answer(ping_text(lang=lang))
