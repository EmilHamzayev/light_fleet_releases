"""Tylko jeden bot naraz (zamek w bazie). Drugi egzemplarz kończy się od razu z jasnym wpisem w dzienniku.

Bot odświeża znacznik co REFRESH s. Po awarii (bez zwolnienia zamka) nowy bot wystartuje, gdy znacznik
będzie starszy niż fleet_core.LOCK_STALE (usługa Windows sama ponowi start).
"""
import asyncio
import logging
import os
import socket
import uuid

from . import db

log = logging.getLogger("fleetbot.lock")
REFRESH = 30
OWNER = "%s:%d:%s" % (socket.gethostname(), os.getpid(), uuid.uuid4().hex[:6])
EXIT_LOCKED = 3


class LockTaken(Exception):
    pass


async def acquire(retry_seconds=15):
    """Czeka, aż baza będzie dostępna; potem bierze zamek albo rzuca LockTaken."""
    while True:
        try:
            if await db.call(db.core.bot_lock_acquire, OWNER):
                log.info("Zamek bota: %s", OWNER)
                return
            h = await db.call(db.core.bot_lock_holder)
            raise LockTaken("Działa już inny bot: %s (ostatni sygnał %s)" % (h["owner"], h["heartbeat_at"]))
        except db.DbUnavailable:
            log.warning("Baza niedostępna - nie można sprawdzić zamka, ponowię za %d s", retry_seconds)
            await asyncio.sleep(retry_seconds)


async def keep(on_lost, interval=REFRESH):
    """Odświeża zamek; gdy przejął go inny bot - wywołuje on_lost() (bot się zatrzymuje)."""
    while True:
        await asyncio.sleep(interval)
        try:
            if not await db.call(db.core.bot_lock_refresh, OWNER):
                h = await db.call(db.core.bot_lock_holder)
                log.error("Zamek przejął inny bot (%s) - zatrzymuję się", h["owner"])
                await on_lost()
                return
        except db.DbUnavailable:
            pass  # bez bazy nie wiemy - spróbujemy za chwilę


async def release():
    try:
        await db.call(db.core.bot_lock_release, OWNER)
        log.info("Zamek zwolniony")
    except Exception as e:
        log.warning("Nie zwolniono zamka: %s (wygaśnie sam)", e)
