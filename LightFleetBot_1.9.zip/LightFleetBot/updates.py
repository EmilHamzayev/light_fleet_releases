"""Aktualizacje przez internet (program i bot): publiczne repozytorium z gotowymi plikami.

version.json (wersja, pliki, SHA-256) jest podpisany kluczem ed25519 (version.json.sig). Klucz prywatny jest tylko
na komputerze, na którym wydajemy wersje (~/.lightfleet), publiczny - tutaj. Bez poprawnego podpisu i sumy
plik nie jest instalowany.
"""
import base64
import hashlib
import json
import os
import re
import tempfile
import urllib.request

BASE = "https://raw.githubusercontent.com/EmilHamzayev/light_fleet_releases/main/"
PUBLIC_KEY = "9mQZDlYcMbggUoHyDdCxaf1rLkYFeBHBZZqMPdPmTic="
TIMEOUT = 20


class UpdateError(Exception):
    pass


def vtuple(v):
    """'1.10' -> (1, 10); porównanie numerów wersji."""
    return tuple(int(x) for x in re.findall(r"\d+", str(v or "0")))


def newer(latest, current):
    return vtuple(latest) > vtuple(current)


def verify(data, sig_b64, public_key=PUBLIC_KEY):
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    try:
        Ed25519PublicKey.from_public_bytes(base64.b64decode(public_key)).verify(base64.b64decode(sig_b64.strip()), data)
    except (InvalidSignature, ValueError) as e:
        raise UpdateError("Nieprawidłowy podpis aktualizacji.") from e


def _get(url, timeout=TIMEOUT):
    req = urllib.request.Request(url, headers={"User-Agent": "LightFleetManager-updater", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def manifest(base=BASE, get=_get, public_key=PUBLIC_KEY):
    """Pobiera i sprawdza version.json. Zwraca słownik albo rzuca UpdateError."""
    try:
        data, sig = get(base + "version.json"), get(base + "version.json.sig")
    except OSError as e:
        raise UpdateError("Brak połączenia z serwerem aktualizacji: %s" % e) from e
    verify(data, sig.decode("ascii", "replace"), public_key)
    m = json.loads(data.decode("utf-8"))
    if not m.get("version"):
        raise UpdateError("Brak wersji w version.json.")
    return m


def download(entry, base=BASE, dest_dir=None, get=_get):
    """Pobiera plik z manifestu (entry = {file, sha256}) i sprawdza sumę. Zwraca ścieżkę."""
    name = os.path.basename(entry["file"])
    try:
        data = get(base + entry["file"], timeout=600)
    except OSError as e:
        raise UpdateError("Nie udało się pobrać %s: %s" % (name, e)) from e
    if hashlib.sha256(data).hexdigest() != entry["sha256"]:
        raise UpdateError("Suma kontrolna %s się nie zgadza." % name)
    path = os.path.join(dest_dir or tempfile.mkdtemp(prefix="lightfleet_upd_"), name)
    with open(path, "wb") as fh:
        fh.write(data)
    return path


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()
