"""Kopia zapasowa bazy w chmurze (Turso) do lokalnego pliku SQLite.

Użycie:  python tools/backup_cloud.py [--config ŚCIEŻKA] [--out FOLDER] [--keep N]
Token bazy jest czytany z config.json zainstalowanego programu (nie z repozytorium).
Kopię można otworzyć programem w trybie lokalnym.
"""
import argparse
import datetime as dt
import json
import os
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import fleet_core as core  # noqa: E402

APP_DATA = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), core.APP_DIR_NAME)
CHUNK = 500


def backup(cfg, out_dir, keep):
    db = core.TursoDB(cfg)
    objs = db.query("SELECT type, name, sql FROM sqlite_master WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' "
                    "AND name NOT LIKE '_litestream%' ORDER BY type='table' DESC, name")
    os.makedirs(out_dir, exist_ok=True)
    stamp = dt.datetime.now().strftime("%Y-%m-%d_%H%M%S")
    final = os.path.join(out_dir, "fleet_cloud_%s.db" % stamp)
    tmp = final + ".part"
    dst = sqlite3.connect(tmp)
    counts = {}
    try:
        for o in objs:
            if o["type"] == "table":
                dst.execute(o["sql"])
        for o in objs:
            if o["type"] != "table":
                continue
            t = o["name"]
            n, last = 0, None
            while True:
                rows = db.query("SELECT rowid AS _rid, * FROM \"%s\" WHERE rowid > ? ORDER BY rowid LIMIT %d" % (t, CHUNK),
                                (last if last is not None else -1,))
                if not rows:
                    break
                cols = [c for c in rows[0].keys() if c != "_rid"]
                dst.executemany("INSERT INTO \"%s\"(%s) VALUES(%s)" % (t, ",".join('"%s"' % c for c in cols), ",".join("?" * len(cols))),
                                [[r[c] for c in cols] for r in rows])
                n += len(rows)
                last = rows[-1]["_rid"]
            counts[t] = n
        for o in objs:
            if o["type"] in ("index", "trigger", "view"):
                dst.execute(o["sql"])
        dst.commit()
        for t, n in counts.items():
            if dst.execute("SELECT COUNT(*) FROM \"%s\"" % t).fetchone()[0] != n:
                raise RuntimeError("Liczba wierszy się nie zgadza: %s" % t)
    finally:
        dst.close()
    os.replace(tmp, final)
    old = sorted(f for f in os.listdir(out_dir) if f.startswith("fleet_cloud_") and f.endswith(".db"))
    for f in old[:-keep] if keep > 0 else []:
        os.remove(os.path.join(out_dir, f))
    return final, counts


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(APP_DATA, "data", "config.json"))
    ap.add_argument("--out", default=os.path.join(APP_DATA, "backups", "cloud"))
    ap.add_argument("--keep", type=int, default=30, help="ile ostatnich kopii zostawić (0 = wszystkie)")
    a = ap.parse_args()
    with open(a.config, encoding="utf-8") as fh:
        cfg = json.load(fh)
    if cfg.get("mode") != "cloud":
        sys.exit("Program nie jest ustawiony na chmurę (%s)." % a.config)
    path, counts = backup(cfg, a.out, a.keep)
    print("Kopia: %s" % path)
    for t, n in counts.items():
        print("  %-14s %d" % (t, n))


if __name__ == "__main__":
    main()
