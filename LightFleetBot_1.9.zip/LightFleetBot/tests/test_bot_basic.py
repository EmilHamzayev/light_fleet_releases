import asyncio
import datetime as dt
import os
import tempfile
import unittest
from pathlib import Path

from base import FleetTest, core, day

try:
    from fleetbot import config, db, i18n
    from fleetbot.handlers.basic import ping_text
    from fleetbot.handlers.office import status_text
except ImportError:  # biblioteki bota są w .venv
    config = None

KEYS = ("TELEGRAM_BOT_TOKEN", "LOG_DIR", "LOG_LEVEL", "DB_MODE", "TURSO_DATABASE_URL", "TURSO_AUTH_TOKEN", "LOCAL_DB_PATH", "ADMIN_IDS",
        "GROUP_LANG")


@unittest.skipIf(config is None, "brak bibliotek bota (uruchom testy z .venv)")
class BotConfigTest(unittest.TestCase):
    def setUp(self):
        self.saved = {k: os.environ.pop(k, None) for k in KEYS}
        self.dir = tempfile.mkdtemp()

    def tearDown(self):
        for k, v in self.saved.items():
            os.environ.pop(k, None)
            if v is not None:
                os.environ[k] = v

    def load(self, text):
        p = Path(self.dir) / ".env"
        p.write_text(text, encoding="utf-8")
        for k in KEYS:
            os.environ.pop(k, None)
        return config.load(p)

    def test_missing_token(self):
        with self.assertRaises(config.ConfigError):
            self.load("TELEGRAM_BOT_TOKEN=\n")

    def test_cloud_needs_db_token(self):
        with self.assertRaisesRegex(config.ConfigError, "TURSO"):
            self.load("TELEGRAM_BOT_TOKEN=1:a\nTURSO_DATABASE_URL=libsql://x\n")

    def test_cloud_config(self):
        cfg = self.load("TELEGRAM_BOT_TOKEN=123:abc\nLOG_LEVEL=debug\nTURSO_DATABASE_URL=libsql://x\nTURSO_AUTH_TOKEN=t\n"
                        "ADMIN_IDS=1022875169, 42\n")
        self.assertEqual((cfg.bot_token, cfg.log_level), ("123:abc", "DEBUG"))
        self.assertEqual(cfg.db, {"mode": "cloud", "server": "libsql://x", "token": "t"})
        self.assertEqual(cfg.admin_ids, frozenset({1022875169, 42}))
        self.assertEqual(cfg.log_dir, config.ROOT / "logs")

    def test_local_mode_and_bad_admin(self):
        with self.assertRaisesRegex(config.ConfigError, "LOCAL_DB_PATH"):
            self.load("TELEGRAM_BOT_TOKEN=1:a\nDB_MODE=local\n")
        with self.assertRaisesRegex(config.ConfigError, "ADMIN_IDS"):
            self.load("TELEGRAM_BOT_TOKEN=1:a\nDB_MODE=local\nLOCAL_DB_PATH=x.db\nADMIN_IDS=abc\n")

    def test_ping_text(self):
        self.assertEqual(ping_text(dt.datetime(2026, 11, 5, 10, 0, 1)), "pong · 05.11.2026 10:00:01")


@unittest.skipIf(config is None, "brak bibliotek bota (uruchom testy z .venv)")
class BotDbTest(FleetTest):
    def setUp(self):
        super().setUp()
        self.main_db = core.DBX

    def tearDown(self):
        # połączenie bota powstało w wątku bazy - zamknąć je tam; połączenie testu - tutaj
        bot_db = core.DBX
        if bot_db is not self.main_db and hasattr(bot_db, "conn"):
            db.POOL.submit(bot_db.close).result()
        core.DBX = self.main_db
        super().tearDown()

    def test_call_through_db_thread_and_status(self):
        self.assign(self.c1, self.jan, day(-3))
        expected = core.dashboard()["kpi"]
        db.configure({"mode": "local"}, Path(core.DB))
        d = asyncio.run(db.call(core.dashboard))
        self.assertEqual(d["kpi"], expected)
        text = status_text(d, "ru")
        self.assertIn("Машины: 4 (с водителем 1, свободно 3)", text)
        self.assertIn("ждём 600 zł", text)
        self.assertIn("Без дат OC/przegląd: 4", text)
        pl = status_text(d)
        self.assertIn("Samochody: 4 (z kierowcą 1, wolne 3)", pl)
        self.assertIn("oczekujemy 600 zł", pl)

    def test_user_error_passes_through(self):
        db.configure({"mode": "local"}, Path(core.DB))
        with self.assertRaises(core.UserError):
            asyncio.run(db.call(core.car_detail, 99999))

    def test_unavailable_cloud(self):
        db.configure({"mode": "cloud", "server": "libsql://nie-istnieje.invalid", "token": "x"})
        with self.assertRaises(db.DbUnavailable):
            asyncio.run(db.call(core.dashboard))


@unittest.skipIf(config is None, "brak bibliotek bota (uruchom testy z .venv)")
class I18nTest(unittest.TestCase):
    def test_same_keys_and_placeholders(self):
        import string
        ref = i18n._T["pl"]
        for lang in i18n.LANGS:
            self.assertEqual(set(i18n._T[lang]), set(ref), lang)
            for k, v in i18n._T[lang].items():
                f = {x[1] for x in string.Formatter().parse(v) if x[1]}
                g = {x[1] for x in string.Formatter().parse(ref[k]) if x[1]}
                self.assertEqual(f, g, "%s/%s" % (lang, k))

    def test_polish_is_default(self):
        self.assertEqual(i18n.DEFAULT, "pl")
        self.assertEqual(i18n.t("xx", "lang_set"), i18n.t("pl", "lang_set"))
        self.assertEqual(ping_text(dt.datetime(2026, 1, 2, 3, 4, 5), "uk"), "pong · 02.01.2026 03:04:05")


class TgUsersTest(FleetTest):
    def test_language_saved_and_changed(self):
        self.assertIsNone(core.tg_lang(1022875169))
        core.tg_set_lang(1022875169, "ru")
        core.tg_set_lang(1022875169, "pl")
        self.assertEqual(core.tg_lang(1022875169), "pl")
        self.assertEqual(self.count("tg_users"), 1)
        self.assertUserError(lambda: core.tg_set_lang(1, "de"), "język")


if __name__ == "__main__":
    unittest.main()
