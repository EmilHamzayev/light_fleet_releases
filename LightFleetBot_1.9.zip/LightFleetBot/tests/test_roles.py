import re
import unittest

from base import PASSWORD, FleetTest, core

try:
    from fleetbot.handlers import link
except ImportError:  # biblioteki bota są w .venv
    link = None

OFFICE_ID, DRIVER_TG, OTHER_TG = 1022875169, 555001, 555002


class LinkCodesTest(FleetTest):
    def test_driver_code(self):
        c = core.link_code_create("driver", OFFICE_ID, self.jan)
        self.assertEqual(len(c["code"]), 8)
        self.assertTrue(re.search(r"\d", c["code"]))
        r = core.link_code_use(DRIVER_TG, c["code"].lower()[:4] + "-" + c["code"][4:])  # wielkość liter i myślnik bez znaczenia
        self.assertEqual((r["role"], r["driver"]), ("driver", "Jan Test"))
        u = core.tg_user(DRIVER_TG)
        self.assertEqual((u["role"], u["driver_id"], u["driver"]), ("driver", self.jan, "Jan Test"))

    def test_code_is_one_time_and_not_stored_plain(self):
        c = core.link_code_create("driver", OFFICE_ID, self.jan)
        self.assertFalse(core.q("SELECT 1 FROM link_codes WHERE code_hash=?", (c["code"],)))
        core.link_code_use(DRIVER_TG, c["code"])
        self.assertUserError(lambda: core.link_code_use(OTHER_TG, c["code"]), "użyty")

    def test_bad_and_expired_code(self):
        self.assertUserError(lambda: core.link_code_use(DRIVER_TG, "ABCD2345"), "Nieprawidłowy")
        c = core.link_code_create("driver", OFFICE_ID, self.jan)
        core.ex("UPDATE link_codes SET expires_at='2000-01-01 00:00'")
        self.assertUserError(lambda: core.link_code_use(DRIVER_TG, c["code"]), "wygasł")

    def test_office_code(self):
        c = core.link_code_create("office", OFFICE_ID)
        r = core.link_code_use(OTHER_TG, c["code"])
        self.assertEqual(r["role"], "office")
        self.assertEqual(core.tg_office_ids(), [OTHER_TG])

    def test_driver_has_one_telegram(self):
        core.link_code_use(DRIVER_TG, core.link_code_create("driver", OFFICE_ID, self.jan)["code"])
        core.link_code_use(OTHER_TG, core.link_code_create("driver", OFFICE_ID, self.jan)["code"])
        self.assertIsNone(core.tg_user(DRIVER_TG)["driver_id"])
        self.assertEqual(core.tg_user(OTHER_TG)["driver_id"], self.jan)

    def test_language_kept_after_linking(self):
        core.tg_set_lang(DRIVER_TG, "uk")
        core.link_code_use(DRIVER_TG, core.link_code_create("driver", OFFICE_ID, self.ola)["code"])
        self.assertEqual(core.tg_user(DRIVER_TG)["lang"], "uk")

    def test_archived_driver(self):
        c = core.link_code_create("driver", OFFICE_ID, self.jan)
        core.archive("drivers", self.jan, PASSWORD)
        self.assertUserError(lambda: core.link_code_use(DRIVER_TG, c["code"]), "nie istnieje")
        self.assertUserError(lambda: core.link_code_create("driver", OFFICE_ID, self.jan), "nie istnieje")

    def test_unknown_user(self):
        self.assertEqual(core.tg_user(999)["role"], None)


@unittest.skipIf(link is None, "brak bibliotek bota (uruchom testy z .venv)")
class CodeEntryTest(unittest.TestCase):
    def test_code_pattern(self):
        for ok in ("ABCD2345", "abcd-2345", "K7P4 M2QX"):
            self.assertTrue(link.CODE_RE.match(ok), ok)
        for bad in ("Dziekuje", "dzien dobry", "1234", "ABCD-23456", "/start"):
            self.assertFalse(link.CODE_RE.match(bad), bad)

    def test_block_after_failures(self):
        uid = 777
        link._fails.pop(uid, None)
        for _ in range(link.MAX_FAILS - 1):
            link._fails.setdefault(uid, []).append(1000.0)
        self.assertFalse(link.blocked(uid, now=1001.0))
        link._fails[uid].append(1000.0)
        self.assertTrue(link.blocked(uid, now=1001.0))
        self.assertFalse(link.blocked(uid, now=1000.0 + link.BLOCK_SECONDS + 1))


if __name__ == "__main__":
    unittest.main()
