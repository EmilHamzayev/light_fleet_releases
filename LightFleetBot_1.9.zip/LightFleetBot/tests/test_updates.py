import base64
import hashlib
import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from base import ROOT

import updates

try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
except ImportError:
    Ed25519PrivateKey = None
try:
    from fleetbot import updater
except ImportError:  # biblioteki bota są w .venv
    updater = None


def signed(m, key):
    data = json.dumps(m).encode()
    pub = base64.b64encode(key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)).decode()
    return data, base64.b64encode(key.sign(data)), pub


@unittest.skipIf(Ed25519PrivateKey is None, "brak cryptography")
class UpdatesTest(unittest.TestCase):
    def test_versions(self):
        self.assertTrue(updates.newer("1.10", "1.9"))
        self.assertTrue(updates.newer("1.8", "1.7"))
        self.assertFalse(updates.newer("1.7", "1.7"))
        self.assertFalse(updates.newer(None, "1.7"))

    def test_signed_manifest_ok_and_tampered(self):
        key = Ed25519PrivateKey.generate()
        data, sig, pub = signed({"version": "1.8"}, key)
        files = {"B/version.json": data, "B/version.json.sig": sig}
        self.assertEqual(updates.manifest("B/", files.__getitem__, pub)["version"], "1.8")
        files["B/version.json"] = data.replace(b"1.8", b"9.9")  # ktoś podmienił plik
        with self.assertRaises(updates.UpdateError):
            updates.manifest("B/", files.__getitem__, pub)
        with self.assertRaises(updates.UpdateError):  # inny klucz (np. prawdziwy klucz programu)
            updates.manifest("B/", {"B/version.json": data, "B/version.json.sig": sig}.__getitem__)

    def test_no_network(self):
        def get(url, timeout=None):
            raise OSError("offline")
        with self.assertRaisesRegex(updates.UpdateError, "połączenia"):
            updates.manifest("B/", get)

    def test_download_checks_sum(self):
        blob = b"plik-testowy-123"
        get = lambda url, timeout=None: blob  # noqa: E731
        path = updates.download({"file": "a.bin", "sha256": hashlib.sha256(blob).hexdigest()}, "B/", get=get)
        self.assertEqual(Path(path).read_bytes(), blob)
        with self.assertRaisesRegex(updates.UpdateError, "Suma"):
            updates.download({"file": "a.bin", "sha256": "0" * 64}, "B/", get=get)

    def test_public_key_matches_signing_key(self):
        key_file = Path.home() / ".lightfleet" / "release_ed25519.pem"
        if not key_file.exists():
            self.skipTest("brak klucza wydawania na tym komputerze")
        key = serialization.load_pem_private_key(key_file.read_bytes(), None)
        updates.verify(b"x", base64.b64encode(key.sign(b"x")).decode())


@unittest.skipIf(updater is None, "brak bibliotek bota (uruchom testy z .venv)")
class BotUpdaterTest(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp())
        (self.root / "fleetbot").mkdir()
        (self.root / "fleet_core.py").write_text("VERSION = '1.7'")
        (self.root / "fleetbot" / "__main__.py").write_text("old")
        (self.root / ".env").write_text("TELEGRAM_BOT_TOKEN=secret")
        (self.root / "google_service_account.json").write_text("{key}")
        (self.root / "requirements-bot.txt").write_text("aiogram==1\n")

    def make_zip(self, req="aiogram==1\n"):
        z = self.root.parent / ("bot_%s.zip" % self.root.name)
        with zipfile.ZipFile(z, "w") as f:
            f.writestr("LightFleetBot/fleet_core.py", "VERSION = '1.8'")
            f.writestr("LightFleetBot/fleetbot/__main__.py", "new")
            f.writestr("LightFleetBot/fleetbot/nowy.py", "nowy")
            f.writestr("LightFleetBot/.env", "TELEGRAM_BOT_TOKEN=ZLY")  # nie może nadpisać
            f.writestr("LightFleetBot/requirements-bot.txt", req)
        return z

    def test_apply_keeps_secrets(self):
        updater.apply(self.make_zip(), "1.8", self.root, pip=lambda r: self.fail("pip niepotrzebny"))
        self.assertEqual((self.root / "fleet_core.py").read_text(), "VERSION = '1.8'")
        self.assertEqual((self.root / "fleetbot" / "nowy.py").read_text(), "nowy")
        self.assertEqual((self.root / ".env").read_text(), "TELEGRAM_BOT_TOKEN=secret")
        self.assertEqual((self.root / "google_service_account.json").read_text(), "{key}")
        self.assertEqual(json.loads((self.root / "logs" / updater.MARKER).read_text())["version"], "1.8")
        self.assertFalse((self.root / "_update_new").exists())

    def test_new_requirements_installed(self):
        called = []
        updater.apply(self.make_zip("aiogram==1\ngspread==6\n"), "1.8", self.root, pip=called.append)
        self.assertEqual(called, [self.root])

    def test_rollback_when_pip_fails(self):
        def bad(root):
            raise updates.UpdateError("pip")
        with self.assertRaises(updates.UpdateError):
            updater.apply(self.make_zip("gspread==6\n"), "1.8", self.root, pip=bad)
        self.assertEqual((self.root / "fleet_core.py").read_text(), "VERSION = '1.7'")
        self.assertFalse((self.root / "fleetbot" / "nowy.py").exists())
        self.assertFalse((self.root / "logs" / updater.MARKER).exists())

    def test_incomplete_zip_rejected(self):
        z = self.root.parent / "bad.zip"
        with zipfile.ZipFile(z, "w") as f:
            f.writestr("LightFleetBot/x.txt", "x")
        with self.assertRaisesRegex(updates.UpdateError, "niekompletne"):
            updater.apply(z, "1.8", self.root)
        self.assertEqual((self.root / "fleet_core.py").read_text(), "VERSION = '1.7'")

    def test_dev_checkout_never_updates(self):
        self.assertTrue(updater.is_dev(ROOT))  # ten folder projektu ma .git
        self.assertFalse(updater.is_dev(self.root))


class ReleaseZipTest(unittest.TestCase):
    def test_bot_zip_has_no_secrets(self):
        import importlib.util
        spec = importlib.util.spec_from_file_location("release", Path(ROOT) / "tools" / "release.py")
        rel = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(rel)
        path = rel.bot_zip("0.0-test", tempfile.mkdtemp())
        names = zipfile.ZipFile(path).namelist()
        self.assertIn("LightFleetBot/fleetbot/updater.py", names)
        self.assertIn("LightFleetBot/updates.py", names)
        for n in names:
            self.assertFalse(n.endswith((".env", "google_service_account.json", ".pem", ".db", "nssm.exe")), n)
            self.assertNotIn("__pycache__", n)


if __name__ == "__main__":
    unittest.main()
