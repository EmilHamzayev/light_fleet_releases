import asyncio
import unittest
from pathlib import Path

from base import FleetTest, core

try:
    from fleetbot import db, lock
except ImportError:  # biblioteki bota są w .venv
    db = None


class LockCoreTest(FleetTest):
    def test_second_owner_blocked(self):
        self.assertTrue(core.bot_lock_acquire("A"))
        self.assertTrue(core.bot_lock_acquire("A"))  # ten sam właściciel - ponownie OK
        self.assertFalse(core.bot_lock_acquire("B"))
        self.assertEqual(core.bot_lock_holder()["owner"], "A")

    def test_stale_lock_taken_over(self):
        core.bot_lock_acquire("A")
        core.ex("UPDATE bot_lock SET heartbeat_at=?", (core.now_s(-core.LOCK_STALE - 5),))  # A padł bez zwolnienia
        self.assertTrue(core.bot_lock_acquire("B"))
        self.assertFalse(core.bot_lock_refresh("A"))  # A wrócił - widzi, że zamek przejęto
        self.assertTrue(core.bot_lock_refresh("B"))

    def test_release(self):
        core.bot_lock_acquire("A")
        core.bot_lock_release("B")  # cudzy - bez skutku
        self.assertFalse(core.bot_lock_acquire("B"))
        core.bot_lock_release("A")
        self.assertTrue(core.bot_lock_acquire("B"))


@unittest.skipIf(db is None, "brak bibliotek bota (uruchom testy z .venv)")
class BotLockTest(FleetTest):
    def setUp(self):
        super().setUp()
        self.main_db = core.DBX
        db.configure({"mode": "local"}, Path(core.DB))

    def tearDown(self):
        bot_db = core.DBX
        if bot_db is not self.main_db and hasattr(bot_db, "conn"):
            db.POOL.submit(bot_db.close).result()
        core.DBX = self.main_db
        super().tearDown()

    def test_second_bot_exits(self):
        asyncio.run(db.call(core.bot_lock_acquire, "inny-komputer:1:abc"))
        with self.assertRaises(lock.LockTaken) as cm:
            asyncio.run(lock.acquire())
        self.assertIn("inny-komputer", str(cm.exception))

    def test_lost_lock_stops_bot(self):
        asyncio.run(lock.acquire())
        asyncio.run(db.call(core.ex, "UPDATE bot_lock SET owner='ktoś', heartbeat_at=?", (core.now_s(),)))
        stopped = []

        async def on_lost():
            stopped.append(True)
        asyncio.run(asyncio.wait_for(lock.keep(on_lost, interval=0.01), 5))
        self.assertEqual(stopped, [True])

    def test_release_lets_next_start(self):
        asyncio.run(lock.acquire())
        asyncio.run(lock.release())
        self.assertTrue(asyncio.run(db.call(core.bot_lock_acquire, "następny")))


if __name__ == "__main__":
    unittest.main()
