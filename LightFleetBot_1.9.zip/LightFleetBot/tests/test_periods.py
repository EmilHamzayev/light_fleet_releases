import unittest

from base import FleetTest, PASSWORD, core, day


class PeriodsTest(FleetTest):
    def test_closed_period_leaves_car_free(self):
        self.assign(self.c1, self.jan, day(-5), day(-2))
        self.assertIsNone(self.car(self.c1)["driver"])
        self.assertIsNone(self.drv(self.jan)["plate"])

    def test_open_period_is_current(self):
        self.assign(self.c1, self.jan, day(-5))
        self.assertEqual(self.car(self.c1)["driver"], "Jan Test")
        self.assertEqual(self.drv(self.jan)["plate"], "AA111")

    def test_future_period_not_current(self):
        self.assign(self.c1, self.jan, day(3))
        self.assertIsNone(self.car(self.c1)["driver"])

    def test_touching_periods_allowed(self):
        self.assign(self.c1, self.jan, day(-6), day(-3))
        self.assign(self.c1, self.ola, day(-3))
        self.assertEqual(self.car(self.c1)["driver"], "Ola Test")

    def test_replacement_ends_previous_day_before(self):
        self.assign(self.c1, self.jan, day(-10))
        notes = self.assign(self.c1, self.ola, day())
        end = core.q("SELECT end_date FROM assignments WHERE driver_id=?", (self.jan,))[0]["end_date"]
        self.assertEqual(end, day(-1))
        self.assertEqual(self.car(self.c1)["driver"], "Ola Test")
        self.assertTrue(any("zdjęty" in n for n in notes))

    def test_same_day_replacement_removes_mistake(self):
        self.assign(self.c1, self.jan, day())
        self.assign(self.c1, self.ola, day())
        self.assertEqual(self.count("assignments", "driver_id=?", (self.jan,)), 0)

    def test_overlap_with_later_period_rejected(self):
        self.assign(self.c1, self.jan, day(-2))
        self.assertUserError(lambda: self.assign(self.c1, self.ola, day(-8), day(-1)), "nakłada")
        self.assertEqual(self.count("assignments"), 1)

    def test_end_before_start_rejected(self):
        self.assertUserError(lambda: self.assign(self.c1, self.jan, day(), day(-1)), "wcześniejsza")

    def test_driver_moves_between_cars(self):
        self.assign(self.c1, self.jan, day(-10))
        self.assign(self.c2, self.jan, day())
        self.assertEqual(self.drv(self.jan)["plate"], "BB222")
        self.assertIsNone(self.car(self.c1)["driver"])

    def test_remove_driver_from_car(self):
        self.assign(self.c1, self.jan, day(-10))
        core.assign_apply({"car_id": None, "driver_id": self.jan, "date": day()})
        self.assertIsNone(self.car(self.c1)["driver"])

    def test_same_driver_same_car_updates_pay_only(self):
        self.assign(self.c1, self.jan, day(-10))
        core.assign_apply({"car_id": self.c1, "driver_id": self.jan, "date": day(), "pay_type": "salary"})
        rows = core.q("SELECT pay_type FROM assignments WHERE driver_id=?", (self.jan,))
        self.assertEqual([r["pay_type"] for r in rows], ["salary"])

    def test_new_driver_by_name(self):
        core.assign_apply({"car_id": self.c3, "new_name": "Nowy Kierowca", "date": day(-1)})
        self.assertEqual(self.car(self.c3)["driver"], "Nowy Kierowca")

    def test_edit_period(self):
        self.assign(self.c1, self.jan, day(-10), day(-6))
        self.assign(self.c1, self.ola, day(-5))
        aid = core.q("SELECT id FROM assignments WHERE driver_id=?", (self.jan,))[0]["id"]
        core.save_assignment({"id": aid, "start": day(-12), "end": day(-5)})
        self.assertUserError(lambda: core.save_assignment({"id": aid, "start": day(-12), "end": day(-3)}), "nakłada")
        self.assertUserError(lambda: core.save_assignment({"id": aid, "start": day(-4), "end": day(-6)}), "wcześniejsza")

    def test_week_shows_all_drivers(self):
        mon = core.monday_of(core.parse_date(day())).isoformat()
        prev_mon = core.monday_of(core.parse_date(day(-7))).isoformat()
        self.assign(self.c1, self.jan, prev_mon, core.day_before(core.monday_of(core.parse_date(day())).isoformat()))
        self.assign(self.c1, self.ola, mon)
        rows = core.week_view(prev_mon)["rows"]
        self.assertEqual(next(r for r in rows if r["car_id"] == self.c1)["driver"], "Jan Test")
        week = core.week_view(day())
        self.assertIn("Ola Test", next(r for r in week["rows"] if r["car_id"] == self.c1)["driver"])

    def test_archived_driver_not_current(self):
        self.assign(self.c1, self.jan, day())
        core.archive("drivers", self.jan, PASSWORD)
        self.assertIsNone(self.car(self.c1)["driver"])

    def test_history_lists_periods(self):
        self.assign(self.c1, self.jan, day(-20), day(-11))
        self.assign(self.c2, self.ola, day(-5))
        h = core.history({"from": day(-30), "to": day()})
        self.assertEqual(h["total"], 2)
        self.assertEqual(core.history({"from": day(-30), "to": day(), "q": "Ola"})["total"], 1)


if __name__ == "__main__":
    unittest.main()
