import unittest

from base import FleetTest, core

ROWS = [{"name": "Gennadii Sabadash", "city": "Toruń", "sheet_key": "TRNGS0124"},
        {"name": "Jerzy  Kondziela", "city": "Grudziądz", "sheet_key": "GRDJK120825"}]


class FleetCityTest(FleetTest):
    def test_import_new_drivers(self):
        r = core.fleet_import_drivers(ROWS)
        self.assertEqual(r, {"added": ["Gennadii Sabadash", "Jerzy Kondziela"], "updated": []})
        d = {x["name"]: x for x in core.fleet_view()["drivers"]}
        self.assertEqual((d["Gennadii Sabadash"]["city"], d["Gennadii Sabadash"]["sheet_key"]), ("Toruń", "TRNGS0124"))
        self.assertEqual(d["Jerzy Kondziela"]["city"], "Grudziądz")
        self.assertNotIn("Gennadii Sabadash", [x["name"] for x in core.drivers_list()])  # nie w wynajmie

    def test_import_twice_no_duplicates(self):
        core.fleet_import_drivers(ROWS)
        r = core.fleet_import_drivers(ROWS)
        self.assertEqual((r["added"], len(r["updated"])), ([], 2))
        self.assertEqual(self.count("drivers", "kind='fleet'"), 2)

    def test_import_matches_by_id_then_name(self):
        core.fleet_import_drivers(ROWS)
        r = core.fleet_import_drivers([{"name": "Gienadij Sabadasz", "city": "Toruń", "sheet_key": "TRNGS0124"},  # inna pisownia, to samo ID
                                       {"name": "OLA  test", "city": "Toruń", "sheet_key": None}])  # istniejący kierowca wynajmu
        self.assertEqual(r["added"], [])
        self.assertEqual(self.count("drivers", "kind='fleet'"), 3)
        self.assertEqual(core.q("SELECT kind, city FROM drivers WHERE id=?", (self.ola,))[0]["city"], "Toruń")

    def test_city_on_forms(self):
        cid = core.save_car({"plate": "FL9", "model": "Toyota Corolla", "kind": "fleet", "city": "Grudziądz"})
        did = core.save_driver({"name": "Nowy Flota", "kind": "fleet", "city": "Toruń"})
        core.save_driver({"id": did, "name": "Nowy Flota", "phone": "1"})  # bez pola city - miasto zostaje
        v = core.fleet_view()
        self.assertEqual([c["city"] for c in v["cars"] if c["id"] == cid], ["Grudziądz"])
        self.assertEqual([d["city"] for d in v["drivers"] if d["id"] == did], ["Toruń"])
        core.save_driver({"id": did, "name": "Nowy Flota", "city": "Warszawa"})  # nieznane miasto -> puste
        self.assertEqual([d["city"] for d in core.fleet_view()["drivers"] if d["id"] == did], [None])

    def test_sheet_city_codes(self):
        self.assertEqual(core.SHEET_CITY, {"TRN": "Toruń", "GRDZ": "Grudziądz"})


if __name__ == "__main__":
    unittest.main()
