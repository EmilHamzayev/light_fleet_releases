import asyncio
import datetime as dt
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from base import FleetTest, core

try:
    from fleetbot import db, jobs, scheduler, sheets
except ImportError:  # biblioteki bota są w .venv
    db = None


class CashCoreTest(FleetTest):
    def setUp(self):
        super().setUp()
        self.g = core.save_driver({"name": "Gennadii Sabadash", "kind": "fleet", "city": "Toruń"})
        self.k = core.save_driver({"name": "Jerzy Kondziela", "kind": "fleet", "city": "Grudziądz"})

    def test_week_of_settlement(self):
        self.assertEqual(core.cash_week_of("2026-11-02"), "2026-10-26")  # poniedziałek -> poprzedni tydzień
        self.assertEqual(core.cash_week_of("2026-11-04"), "2026-10-26")
        self.assertUserError(lambda: core.cash_week_of("02.11.2026"), "data")

    def test_store_new_same_changed(self):
        r = core.fleet_cash_store("2026-11-02", [(self.g, 432.38, 144), (self.k, 728.07, 198)])
        self.assertEqual((r["week_start"], r["new"]), ("2026-10-26", 2))
        r = core.fleet_cash_store("2026-11-02", [(self.g, 432.38, 144), (self.k, 700.0, 198)])
        self.assertEqual((r["same"], r["changed"], r["new"]), (1, 1, 0))
        self.assertEqual(self.count("fleet_cash"), 2)
        v = core.fleet_view()
        self.assertEqual(v["cash_week"], "2026-10-26")
        self.assertEqual({d["name"]: d["cash"] for d in v["drivers"]}, {"Gennadii Sabadash": 432.38, "Jerzy Kondziela": 700.0})

    def test_view_shows_latest_week(self):
        core.fleet_cash_store("2026-11-02", [(self.g, 1.0, 1)])
        core.fleet_cash_store("2026-11-09", [(self.g, 2.0, 1)])
        self.assertEqual([d["cash"] for d in core.fleet_view()["drivers"] if d["id"] == self.g], [2.0])


VALUES = [["", "ROZLICZENIE ", "", "02.11.2026"], ["MIASTO", "ID", "Forma", "Imię, Nazwisko", "GOTÓWKA"],
          ["TRN", "TRNGS0124", "FLT", "Gennadii Sabadash", "432,38"], ["GRDZ", "X", "FLT", "Ktoś Obcy", "5"]]


@unittest.skipIf(db is None, "brak bibliotek bota (uruchom testy z .venv)")
class CashJobTest(FleetTest):
    def setUp(self):
        super().setUp()
        self.g = core.save_driver({"name": "Gennadii Sabadash", "kind": "fleet", "city": "Toruń"})
        core.save_driver({"name": "Nieobecny Kierowca", "kind": "fleet", "city": "Toruń"})
        self.main_db = core.DBX
        db.configure({"mode": "local"}, Path(core.DB))
        key = Path(tempfile.mkdtemp()) / "key.json"
        key.write_text("{}")
        self.cfg = SimpleNamespace(google_key=key, sheet_id="x", sheet_gid=1, office_chat_id=6936017050, group_lang="pl")
        scheduler._wait_until.clear()

    def tearDown(self):
        bot_db = core.DBX
        if bot_db is not self.main_db and hasattr(bot_db, "conn"):
            db.POOL.submit(bot_db.close).result()
        core.DBX = self.main_db
        super().tearDown()

    def ctx(self, values):
        return {"cfg": self.cfg, "read_sheet": lambda *a: sheets.parse(values)}

    def run_job(self, values, now):
        return asyncio.run(jobs.sheet_cash(self.ctx(values), now))

    def outbox(self):
        return asyncio.run(db.call(core.outbox_due))

    def test_reads_and_reports(self):
        res = self.run_job(VALUES, dt.datetime(2026, 11, 2, 11, 0))
        self.assertIn("2026-10-26: 1 kierowców", res)
        rows = asyncio.run(db.call(core.fleet_cash_week, "2026-10-26"))
        self.assertEqual([(r["name"], r["cash_sheet"]) for r in rows], [("Gennadii Sabadash", 432.38)])
        msg = self.outbox()[0]["text"]
        self.assertIn("Gotówka za tydzień 26.10–01.11 (rozliczenie 02.11)", msg)
        self.assertIn("Toruń: 432,38 zł (1 kierowców)", msg)
        self.assertIn("Brak w arkuszu: Nieobecny Kierowca", msg)

    def test_old_sheet_waits_then_warns_on_tuesday(self):
        old = [["", "ROZLICZENIE", "", "26.10.2026"]] + VALUES[1:]
        with self.assertRaises(scheduler.NotYet):
            self.run_job(old, dt.datetime(2026, 11, 2, 11, 0))
        self.assertEqual(self.outbox(), [])
        for _ in range(2):  # wtorek po 12 - jedno ostrzeżenie (bez duplikatów)
            with self.assertRaises(scheduler.NotYet):
                self.run_job(old, dt.datetime(2026, 11, 3, 13, 0))
        self.assertEqual(len(self.outbox()), 1)
        self.assertIn("nie jest uzupełniony", self.outbox()[0]["text"])

    def test_missing_key_retries_hourly(self):
        self.cfg.google_key = Path(tempfile.mkdtemp()) / "brak.json"
        with self.assertRaises(scheduler.NotYet) as cm:
            self.run_job(VALUES, dt.datetime(2026, 11, 2, 11, 0))
        self.assertEqual(cm.exception.seconds, 3600)

    def test_scheduler_quiet_retry(self):
        calls = []

        async def job(ctx):
            calls.append(1)
            raise scheduler.NotYet("x", 1800)
        jl = [scheduler.Job("t", scheduler.weekly(0, 11), job)]
        now = dt.datetime(2026, 11, 2, 11, 5)
        asyncio.run(scheduler.tick(jl, {}, now))
        asyncio.run(scheduler.tick(jl, {}, now))  # w ciągu 30 min - nie próbuje
        self.assertEqual(len(calls), 1)
        self.assertFalse(asyncio.run(db.call(core.job_done, "t", "2026-W45")))

    def test_job_registered(self):
        self.assertIn("sheet_cash", [j.name for j in jobs.all_jobs()])


if __name__ == "__main__":
    unittest.main()
