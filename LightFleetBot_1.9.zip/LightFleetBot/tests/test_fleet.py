import unittest

from base import FleetTest, core, day


class FleetTest_(FleetTest):
    def setUp(self):
        super().setUp()
        self.f1 = core.save_car({"plate": "FL001", "model": "Toyota Corolla", "kind": "fleet", "oc_until": day(10)})
        self.f2 = core.save_car({"plate": "FL002", "model": "Skoda Octavia", "kind": "fleet"})
        self.a = core.save_driver({"name": "Andrii Anosov", "kind": "fleet"})
        self.g = core.save_driver({"name": "Gennadii Sabadash", "kind": "fleet", "phone": "500"})
        self.v = core.save_driver({"name": "Volodymyr Matiushenko", "kind": "fleet"})

    def view(self):
        v = core.fleet_view()
        return v, {c["plate"]: c for c in v["cars"]}, {d["name"]: d for d in v["drivers"]}

    def test_rent_and_fleet_lists_separate(self):
        self.assertNotIn("FL001", [c["plate"] for c in core.cars_list()])
        self.assertNotIn("Andrii Anosov", [d["name"] for d in core.drivers_list()])
        self.assertIn("Andrii Anosov", [d["name"] for d in core.drivers_list("active", None)])
        lk = core.lookups()
        self.assertNotIn("FL001", [c["plate"] for c in lk["cars"]])
        self.assertNotIn("Andrii Anosov", [d["name"] for d in lk["drivers"]])
        self.assertEqual(core.dashboard()["kpi"]["cars"], 4)
        self.assertEqual(len(core.week_view(day())["rows"]), 0)

    def test_fleet_alerts_included(self):
        self.assertTrue(any(a["car_id"] == self.f1 and a["kind"] == "doc" for a in core.alerts()))

    def test_day_and_night_crew(self):
        core.fleet_crew_set(self.f1, "day", self.g, day(-5))
        core.fleet_crew_set(self.f1, "night", self.a, day(-5))
        v, cars, drv = self.view()
        self.assertEqual((cars["FL001"]["day"]["name"], cars["FL001"]["night"]["name"]), ("Gennadii Sabadash", "Andrii Anosov"))
        self.assertEqual((drv["Andrii Anosov"]["plate"], drv["Andrii Anosov"]["shift"]), ("FL001", "night"))
        self.assertEqual(v["kpi"]["free"], 2)  # FL002 bez nikogo
        self.assertEqual(v["kpi"]["docs"], 1)
        d = core.car_detail(self.f1)
        self.assertEqual((d["day"]["name"], len(d["crews"])), ("Gennadii Sabadash", 2))

    def test_replace_on_shift_keeps_history(self):
        core.fleet_crew_set(self.f1, "day", self.g, day(-10))
        notes = core.fleet_crew_set(self.f1, "day", self.v, day())
        self.assertTrue(any("Volodymyr" in n for n in notes))
        rows = core.q("SELECT driver_id, end_date FROM fleet_crews ORDER BY id")
        self.assertEqual([(r["driver_id"], r["end_date"]) for r in rows], [(self.g, core.day_before(day())), (self.v, None)])

    def test_driver_moves_to_other_car(self):
        core.fleet_crew_set(self.f1, "day", self.g, day(-10))
        notes = core.fleet_crew_set(self.f2, "night", self.g, day())
        _, cars, drv = self.view()
        self.assertIsNone(cars["FL001"]["day"])
        self.assertEqual(drv["Gennadii Sabadash"]["plate"], "FL002")
        self.assertTrue(any("FL001: zmiana dzienna wolna" in n for n in notes))

    def test_free_shift_and_same_day_mistake(self):
        core.fleet_crew_set(self.f1, "day", self.g, day())
        core.fleet_crew_set(self.f1, "day", None, day())
        self.assertEqual(self.count("fleet_crews"), 0)  # wpis z tego samego dnia = pomyłka

    def test_same_driver_again_no_change(self):
        core.fleet_crew_set(self.f1, "night", self.a, day(-3))
        self.assertEqual(core.fleet_crew_set(self.f1, "night", self.a, day()), [])
        self.assertEqual(self.count("fleet_crews"), 1)

    def test_validation(self):
        self.assertUserError(lambda: core.fleet_crew_set(self.c1, "day", self.g, day()), "floty")  # samochód wynajmu
        self.assertUserError(lambda: core.fleet_crew_set(self.f1, "day", self.jan, day()), "floty")  # kierowca wynajmu
        self.assertUserError(lambda: core.fleet_crew_set(self.f1, "evening", self.g, day()), "zmianę")
        self.assertUserError(lambda: core.fleet_crew_set(self.f1, "day", self.g, "xx"), "datę")

    def test_edit_keeps_kind(self):
        core.save_car({"id": self.f1, "plate": "FL001", "model": "Toyota Corolla", "mileage": 1000})
        core.save_driver({"id": self.a, "name": "Andrii Anosov", "phone": "600"})
        _, cars, drv = self.view()
        self.assertIn("FL001", cars)
        self.assertEqual(drv["Andrii Anosov"]["phone"], "600")

    def test_telegram_code_from_program(self):
        c = core.tg_link_code(self.a)
        self.assertTrue(c["link"].startswith("https://t.me/LightPartnerBiuroBot?start="))
        core.link_code_use(555, c["code"])
        _, _, drv = self.view()
        self.assertTrue(drv["Andrii Anosov"]["tg"])
        self.assertFalse(drv["Gennadii Sabadash"]["tg"])


if __name__ == "__main__":
    unittest.main()
