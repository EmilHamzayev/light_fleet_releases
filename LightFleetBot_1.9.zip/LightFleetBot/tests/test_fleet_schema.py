import sqlite3
import unittest

from base import PASSWORD, FleetTest, core, day


class FleetSchemaTest(FleetTest):
    def test_existing_rows_are_rent(self):
        self.assertEqual({r["kind"] for r in core.q("SELECT kind FROM cars")}, {"rent"})
        self.assertEqual({r["kind"] for r in core.q("SELECT kind FROM drivers")}, {"rent"})
        self.assertIn("ac_until", self.car(self.c1))

    def test_new_rows_default_rent(self):
        cid = core.save_car({"plate": "FL001", "model": "Toyota Corolla"})
        self.assertEqual(self.car(cid)["kind"], "rent")

    def test_migration_on_old_database(self):
        """Stara baza bez nowych kolumn (jak w chmurze) - init dodaje je, dane zostają."""
        core.DBX.close()
        con = sqlite3.connect(core.DB)
        con.execute("CREATE TABLE cars2 AS SELECT id, plate, model, contractor_id, mileage, oil_last_km, oil_interval, "
                    "oil_warn_km, active FROM cars")
        con.execute("DROP TABLE cars")
        con.execute("ALTER TABLE cars2 RENAME TO cars")
        con.commit()
        con.close()
        core.init_backend({"mode": "local"})
        cols = [r[1] for r in core.DBX.conn.execute("PRAGMA table_info(cars)")]
        self.assertTrue({"kind", "ac_until", "rent_week"} <= set(cols))
        self.assertEqual(self.count("cars"), 4)
        self.assertEqual({r["kind"] for r in core.q("SELECT kind FROM cars")}, {"rent"})

    def test_crew_shift_checked(self):
        core.ex("INSERT INTO fleet_crews(car_id,driver_id,shift,start_date) VALUES(?,?,?,?)", (self.c1, self.jan, "day", day()))
        with self.assertRaises(sqlite3.IntegrityError):
            core.ex("INSERT INTO fleet_crews(car_id,driver_id,shift,start_date) VALUES(?,?,?,?)", (self.c1, self.ola, "evening", day()))

    def test_delete_with_crews(self):
        core.ex("INSERT INTO fleet_crews(car_id,driver_id,shift,start_date) VALUES(?,?,?,?)", (self.c1, self.jan, "day", day()))
        core.ex("INSERT INTO fleet_crews(car_id,driver_id,shift,start_date) VALUES(?,?,?,?)", (self.c2, self.ola, "night", day()))
        self.assertIn("Okresy na samochodach: 1", core.delete_info("drivers", self.jan))
        core.delete_record("drivers", self.jan, PASSWORD)
        core.delete_record("cars", self.c2, PASSWORD)
        self.assertEqual(self.count("fleet_crews"), 0)

    def test_old_screens_unchanged(self):
        self.assign(self.c1, self.jan, day(-3))
        k = core.dashboard()["kpi"]
        self.assertEqual((k["cars"], k["busy"], k["week_due"]), (4, 1, 600))
        self.assertEqual(len(core.week_view(day())["rows"]), 1)


if __name__ == "__main__":
    unittest.main()
