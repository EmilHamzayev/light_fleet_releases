import unittest

from base import FleetTest, PASSWORD, core, day


class CarsTest(FleetTest):
    def test_plate_required(self):
        self.assertUserError(lambda: core.save_car({"plate": "  "}), "numer")

    def test_plate_normalized_and_unique(self):
        self.assertEqual(self.car(self.c1)["plate"], "AA111")
        self.assertUserError(lambda: core.save_car({"plate": "aa111"}), "istnieje")

    def test_invalid_document_date(self):
        self.assertUserError(lambda: core.save_car({"plate": "EE555", "oc_until": "2026-13-45"}), "data")

    def test_edit_mileage_writes_log(self):
        core.save_car({"id": self.c2, "plate": "BB222", "model": "Toyota Auris", "mileage": 120000})
        self.assertEqual(self.car(self.c2)["mileage"], 120000)
        self.assertEqual(self.count("mileage_log", "car_id=?", (self.c2,)), 1)

    def test_car_photos_mapping(self):
        self.assertEqual(core.car_image("Toyota Prius 30"), "toyota_prius_30")
        self.assertEqual(core.car_image("TOYOTA  PRIUS+"), "toyota_prius_plus")
        self.assertEqual(core.car_image("Dacia Logan MCV"), "dacia_logan")
        self.assertIsNone(core.car_image("Nieznany Model"))

    def test_status_free_pending_paid(self):
        self.assertEqual(self.car(self.c1)["status"], "free")
        self.assign(self.c1, self.jan, day(-3))
        self.assertEqual(self.car(self.c1)["status"], "pending")
        core.set_week({"car_id": self.c1, "monday": day(), "paid": True})
        self.assertEqual(self.car(self.c1)["status"], "paid")

    def test_oil_alert(self):
        core.save_car({"id": self.c3, "plate": "CC333", "model": "Skoda Octavia", "mileage": 9500, "oil_last_km": 0,
                       "oil_interval": 10000, "oil_warn_km": 1000})
        self.assertTrue(any(a["car_id"] == self.c3 and a["kind"] == "oil" for a in core.alerts()))
        core.oil_done(self.c3, 9600)
        self.assertFalse(any(a["car_id"] == self.c3 and a["kind"] == "oil" for a in core.alerts()))
        self.assertTrue(core.q("SELECT 1 FROM comments WHERE car_id=? AND text LIKE 'Wymiana oleju%'", (self.c3,)))

    def test_document_alerts_within_30_days(self):
        core.save_car({"id": self.c4, "plate": "DD444", "model": "Nieznany Model", "oc_until": day(10), "przeglad_until": day(90)})
        kinds = [(a["car_id"], a["text"][:3]) for a in core.alerts() if a["kind"] == "doc"]
        self.assertIn((self.c4, "OC "), kinds)
        self.assertNotIn((self.c4, "Prz"), kinds)

    def test_mileage_and_repairs(self):
        self.assertUserError(lambda: core.set_mileage(self.c1, "abc"), "liczbę")
        core.set_mileage(self.c1, "15000")
        self.assertEqual(self.car(self.c1)["mileage"], 15000)
        self.assertUserError(lambda: core.add_repair(self.c1, " "), "naprawę")
        rid = core.add_repair(self.c1, "Klocki", "200")
        core.done_repair(rid, day(), None)
        r = core.q("SELECT done_at, cost FROM repairs WHERE id=?", (rid,))[0]
        self.assertEqual((r["done_at"], r["cost"]), (day(), 200))

    def test_archive_and_restore_car(self):
        self.assign(self.c1, self.jan, day(-5))
        self.assertUserError(lambda: core.archive("cars", self.c1, "zle"), "hasło")
        core.archive("cars", self.c1, PASSWORD)
        self.assertNotIn(self.c1, [c["id"] for c in core.cars_list()])
        self.assertIsNone(self.drv(self.jan)["plate"])
        core.archive("cars", self.c1, PASSWORD)
        self.assertIn(self.c1, [c["id"] for c in core.cars_list()])

    def test_first_password_min_length(self):
        core.ex("DELETE FROM app_settings")
        self.assertUserError(lambda: core.archive("cars", self.c4, "123", True), "4 znaki")
        core.archive("cars", self.c4, "abcd", True)
        self.assertTrue(core.has_archive_password())

    def test_car_detail_and_lookups(self):
        self.assign(self.c2, self.ola, day(-1))
        d = core.car_detail(self.c2)
        self.assertEqual(d["driver"], "Ola Test")
        self.assertEqual(len(d["assignments"]), 1)
        self.assertUserError(lambda: core.car_detail(99999), "nie istnieje")
        free = {c["plate"] for c in core.lookups()["cars"] if not c["driver_id"]}
        self.assertNotIn("BB222", free)
        self.assertIn("AA111", free)


if __name__ == "__main__":
    unittest.main()
