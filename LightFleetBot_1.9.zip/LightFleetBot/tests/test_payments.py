import unittest

from base import FleetTest, core, day


class WeekPaymentsTest(FleetTest):
    def setUp(self):
        super().setUp()
        self.assign(self.c1, self.jan, day(-30))
        self.assign(self.c2, self.ola, day(-30))

    def row(self, cid, d=None):
        return next(r for r in core.week_view(d or day())["rows"] if r["car_id"] == cid)

    def test_week_lists_only_cars_with_driver(self):
        ids = {r["car_id"] for r in core.week_view(day())["rows"]}
        self.assertEqual(ids, {self.c1, self.c2})

    def test_full_payment_defaults_to_rent(self):
        core.set_week({"car_id": self.c1, "monday": day(), "paid": True})
        r = self.row(self.c1)
        self.assertTrue(r["paid"])
        self.assertEqual(r["amount"], 600)

    def test_partial_payment_is_kept(self):
        core.set_week({"car_id": self.c1, "monday": day(), "paid": True, "amount": "300", "paid_at": day()})
        self.assertEqual(self.row(self.c1)["amount"], 300)
        k = core.week_view(day())["kpi"]
        self.assertEqual((k["got"], k["due"], k["waiting"], k["paid_n"]), (300, 1150, 550, 1))

    def test_undo_payment(self):
        core.set_week({"car_id": self.c1, "monday": day(), "paid": True})
        core.set_week({"car_id": self.c1, "monday": day(), "paid": False})
        self.assertFalse(self.row(self.c1)["paid"])

    def test_payment_validation(self):
        self.assertUserError(lambda: core.set_week({"car_id": self.c1, "monday": day(), "paid": True, "amount": "-5"}), "kwotę")
        self.assertUserError(lambda: core.set_week({"car_id": self.c1, "monday": day(), "paid": True, "paid_at": "xx"}), "data")

    def test_comment_and_km(self):
        core.set_week({"car_id": self.c1, "monday": day(), "comment": "  serwis  ", "km": "50000"})
        r = self.row(self.c1)
        self.assertEqual((r["comment"], r["km"]), ("serwis", 50000))

    def test_driver_month_sum(self):
        core.set_week({"car_id": self.c1, "monday": day(), "paid": True, "amount": "450", "paid_at": day()})
        self.assertEqual(self.drv(self.jan)["month_sum"], 450)

    def test_week_csv(self):
        core.set_week({"car_id": self.c1, "monday": day(), "paid": True})
        out = core.week_csv(day())
        lines = out["text"].splitlines()
        self.assertTrue(lines[0].startswith("Tydzień;Nr rej."))
        self.assertEqual(len(lines), 3)
        self.assertIn("AA111", out["text"])
        self.assertTrue(out["name"].startswith("tydzien_"))


class ContractorPaymentsTest(FleetTest):
    def test_accrue_only_cars_with_driver_and_rate(self):
        self.assign(self.c1, self.jan, day(-30))
        self.assign(self.c3, self.ola, day(-30))  # Firma B bez stawki
        r = core.accrue_week(day())
        self.assertEqual((r["added"], r["sum"]), (1, 400))
        rows = core.payments_list()["rows"]
        self.assertEqual([(p["contractor"], p["amount"], p["note"]) for p in rows], [("Firma A", 400, "AA111")])

    def test_accrue_sums_per_contractor_and_no_duplicates(self):
        self.assign(self.c1, self.jan, day(-30))
        self.assign(self.c2, self.ola, day(-30))
        self.assertEqual(core.accrue_week(day())["sum"], 750)
        again = core.accrue_week(day())
        self.assertEqual((again["added"], again["skipped"]), (0, 1))

    def test_accrue_without_drivers_fails(self):
        self.assertUserError(lambda: core.accrue_week(day()), "Brak danych")

    def test_save_payment_validation(self):
        self.assertUserError(lambda: core.save_payment({"from": day(-6), "to": day()}), "kontrahenta")
        self.assertUserError(lambda: core.save_payment({"contractor_id": self.k1, "from": "x", "to": day()}), "okres")

    def test_toggle_full_partial_undo(self):
        pid = core.save_payment({"contractor_id": self.k1, "from": day(-6), "to": day(), "amount": "1000"})
        self.assertTrue(core.toggle_payment(pid))
        p = core.payments_list()
        self.assertEqual((p["paid_sum"], p["unpaid_n"]), (1000, 0))
        self.assertFalse(core.toggle_payment(pid))
        core.toggle_payment(pid, "600", day())
        p = core.payments_list()
        self.assertEqual(p["rows"][0]["paid_amount"], 600)
        self.assertUserError(lambda: core.toggle_payment(pid, "-1"), "kwotę")
        self.assertEqual(core.payments_list(unpaid=True)["rows"], [])

    def test_contractor_unique_name(self):
        self.assertUserError(lambda: core.save_contractor({"name": "Firma A"}), "istnieje")
        self.assertUserError(lambda: core.save_contractor({"name": ""}), "nazwę")
        k = {x["name"]: x for x in core.contractors_list()}
        self.assertEqual(k["Firma A"]["cars"], 2)


if __name__ == "__main__":
    unittest.main()
