import unittest

from base import core

try:
    from fleetbot import sheets
except ImportError:  # biblioteki bota są w .venv
    sheets = None

HEAD = ["MIASTO", "ID", "Forma", "Imię, Nazwisko", "Blokada", "GOTÓWKA"]
VALUES = [["", "ROZLICZENIE ", "", "02.11.2026"], [], ["Wypłacić zlecenie:", "FALSE"],
          HEAD,
          ["TRN", "TRNVP070725", "B2B", "Volodymyr Parashchak", "", "100,00"],
          ["TRN", "TRNGS0124", "FLT", "Gennadii  Sabadash", "", "432,38"],
          ["TRN", "TRNXX", "FLT", "", "", "5,00"],  # pusty wiersz bez imienia
          ["Suma", "", "", "", "", "999"],
          HEAD,
          ["GRDZ", "GRDJK120825", "FLT", "Jerzy Kondziela", "", "1 157,10"],
          ["GRDZ", "GRDZKB160226", "FLT", "Krzysztof Bebko", "", ""],
          ["TRN", "TRNDUP1", "FLT", "Jan Podwójny", "", "1"], ["TRN", "TRNDUP2", "FLT", "Jan Podwójny", "", "2"]]


@unittest.skipIf(sheets is None, "brak bibliotek bota (uruchom testy z .venv)")
class SheetsTest(unittest.TestCase):
    def test_amounts(self):
        self.assertEqual([sheets.parse_amount(x) for x in ("432,38", "1 157,10", "1 000,5 zł", "", "abc", "-3,39")],
                         [432.38, 1157.10, 1000.5, None, None, -3.39])

    def test_parse_driver_rows_across_blocks(self):
        period, rows = sheets.parse(VALUES)
        self.assertEqual(period, "2026-11-02")
        self.assertEqual([(r.row, r.sheet_key, r.forma, r.name, r.cash) for r in rows][:4],
                         [(5, "TRNVP070725", "B2B", "Volodymyr Parashchak", 100.0), (6, "TRNGS0124", "FLT", "Gennadii Sabadash", 432.38),
                          (10, "GRDJK120825", "FLT", "Jerzy Kondziela", 1157.10), (11, "GRDZKB160226", "FLT", "Krzysztof Bebko", None)])
        self.assertNotIn("Suma", [r.miasto for r in rows])

    def test_missing_column(self):
        with self.assertRaisesRegex(ValueError, "GOTÓWKA"):
            sheets.parse([["MIASTO", "ID", "Forma", "Imię, Nazwisko"]])

    def test_match(self):
        _, rows = sheets.parse(VALUES)
        drivers = [{"name": "Gienadij Sabadasz", "sheet_key": "TRNGS0124"},  # po ID
                   {"name": "jerzy kondziela", "sheet_key": None},  # po imieniu
                   {"name": "Ktoś Inny", "sheet_key": None},
                   {"name": "Volodymyr Parashchak", "sheet_key": "TRNVP070725"},  # forma B2B, ale jest we flocie
                   {"name": "Jan Podwójny", "sheet_key": None}]
        pairs, missing, doubles = sheets.match(rows, drivers, core.norm_name)
        self.assertEqual([(d["name"], r.cash) for d, r in pairs],
                         [("Gienadij Sabadasz", 432.38), ("jerzy kondziela", 1157.10), ("Volodymyr Parashchak", 100.0)])
        self.assertEqual([d["name"] for d in missing], ["Ktoś Inny"])
        self.assertEqual([d["name"] for d in doubles], ["Jan Podwójny"])


if __name__ == "__main__":
    unittest.main()
