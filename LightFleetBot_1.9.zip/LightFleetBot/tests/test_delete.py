import unittest

from base import FleetTest, PASSWORD, core, day


class DeleteTest(FleetTest):
    def test_wrong_password(self):
        self.assertUserError(lambda: core.delete_record("drivers", self.jan, "zle"), "hasło")
        self.assertEqual(self.count("drivers", "id=?", (self.jan,)), 1)

    def test_delete_period(self):
        self.assign(self.c1, self.jan, day(-5))
        aid = core.q("SELECT id FROM assignments")[0]["id"]
        self.assertIn("Jan Test", core.delete_info("assignments", aid)[0])
        core.delete_record("assignments", aid, PASSWORD)
        self.assertEqual(self.count("assignments"), 0)
        self.assertIsNone(self.car(self.c1)["driver"])

    def test_delete_driver_with_periods(self):
        self.assign(self.c1, self.jan, day(-9), day(-5))
        self.assign(self.c2, self.jan, day(-4))
        self.assertIn("Okresy na samochodach: 2", core.delete_info("drivers", self.jan))
        core.delete_record("drivers", self.jan, PASSWORD)
        self.assertEqual(self.count("assignments", "driver_id=?", (self.jan,)), 0)
        self.assertEqual(self.count("drivers", "id=?", (self.jan,)), 0)

    def test_delete_car_with_history(self):
        self.assign(self.c1, self.jan, day(-5))
        core.set_week({"car_id": self.c1, "monday": day(), "paid": True, "km": "1000"})
        core.add_repair(self.c1, "Opony")
        core.delete_record("cars", self.c1, PASSWORD)
        for t in core.CAR_CHILDREN:
            self.assertEqual(self.count(t, "car_id=?", (self.c1,)), 0, t)
        self.assertEqual(self.count("cars", "id=?", (self.c1,)), 0)
        self.assertEqual(self.count("drivers", "id=?", (self.jan,)), 1)

    def test_contractor_with_cars_blocked(self):
        self.assertUserError(lambda: core.delete_record("contractors", self.k1, PASSWORD), "ma samochody")

    def test_delete_contractor_with_payments(self):
        k = core.save_contractor({"name": "Firma C"})
        core.save_payment({"contractor_id": k, "from": day(-6), "to": day(), "amount": "100"})
        core.delete_record("contractors", k, PASSWORD)
        self.assertEqual(self.count("payments", "contractor_id=?", (k,)), 0)

    def test_delete_payment(self):
        pid = core.save_payment({"contractor_id": self.k1, "from": day(-6), "to": day(), "amount": "100"})
        core.delete_record("payments", pid, PASSWORD)
        self.assertEqual(self.count("payments"), 0)

    def test_missing_and_unknown(self):
        self.assertUserError(lambda: core.delete_record("drivers", 9999, PASSWORD), "nie istnieje")
        self.assertUserError(lambda: core.delete_info("app_settings", 1), "Nieznany")


if __name__ == "__main__":
    unittest.main()
