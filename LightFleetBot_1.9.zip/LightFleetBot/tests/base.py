"""Wspólne przygotowanie testów: osobna tymczasowa baza dla każdego testu, własne dane testowe.

Testy nigdy nie dotykają chmury ani data/ projektu: ścieżki w fleet_core są podmieniane na folder tymczasowy,
a połączenie jest sprawdzane (PRAGMA database_list) przed każdym testem.
"""
import datetime as dt
import hashlib
import os
import shutil
import sqlite3
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import fleet_core as core  # noqa: E402

PASSWORD = "test1234"


def day(n=0):
    """Data ISO przesunięta o n dni od dziś."""
    return (dt.date.today() + dt.timedelta(days=n)).isoformat()


class FleetTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="fleet_test_")
        for name, sub in (("DATA", ""), ("DB", "fleet.db"), ("BACKUPS", "backups"), ("CONFIG", "config.json"), ("PHOTOS", "photos")):
            setattr(core, name, os.path.join(self.tmp, sub) if sub else self.tmp)
        core.init_backend({"mode": "local"})
        db_file = core.DBX.conn.execute("PRAGMA database_list").fetchone()[2]
        if not os.path.abspath(db_file).startswith(os.path.abspath(self.tmp)):
            raise RuntimeError("Test nie działa na bazie tymczasowej: %s" % db_file)
        self.seed()

    def tearDown(self):
        core.DBX.close()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def seed(self):
        core.ex("INSERT INTO app_settings(key,value) VALUES('archive_password_sha256',?)",
                (hashlib.sha256(PASSWORD.encode()).hexdigest(),))
        self.k1 = core.save_contractor({"name": "Firma A", "contact": "100", "nip": "1111111111"})
        self.k2 = core.save_contractor({"name": "Firma B"})
        self.c1 = core.save_car({"plate": "AA 111", "model": "Toyota Prius 30", "contractor_id": self.k1, "rent_week": 600, "owner_rate": 400})
        self.c2 = core.save_car({"plate": "BB222", "model": "Toyota Auris", "contractor_id": self.k1, "rent_week": 550, "owner_rate": 350})
        self.c3 = core.save_car({"plate": "CC333", "model": "Skoda Octavia", "contractor_id": self.k2, "rent_week": 700})
        self.c4 = core.save_car({"plate": "DD444", "model": "Nieznany Model"})
        self.jan = core.save_driver({"name": "Jan Test", "pay_type": "cash"})
        self.ola = core.save_driver({"name": "Ola Test", "pay_type": "salary"})
        self.piotr = core.save_driver({"name": "Piotr Test"})

    # pomocnicze
    def assign(self, car, driver, start, end=None):
        return core.assign_apply({"car_id": car, "driver_id": driver, "date": start, "end": end})

    def car(self, cid):
        return next(c for c in core.cars_list(True) if c["id"] == cid)

    def drv(self, did):
        return next(d for d in core.drivers_list("all") if d["id"] == did)

    def count(self, table, where="1", args=()):
        return core.q("SELECT COUNT(*) AS n FROM %s WHERE %s" % (table, where), args)[0]["n"]

    def assertUserError(self, fn, part=""):
        with self.assertRaises(core.UserError) as cm:
            fn()
        self.assertIn(part, str(cm.exception))
        return str(cm.exception)


def raw_db(path):
    return sqlite3.connect(path)
