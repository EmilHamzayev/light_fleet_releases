import unittest

from base import FleetTest, core, day

try:
    from fleetbot.handlers import office
except ImportError:  # biblioteki bota są w .venv
    office = None


class OfficeSearchTest(FleetTest):
    def setUp(self):
        super().setUp()
        self.assign(self.c1, self.jan, day(-5))
        self.f = core.save_car({"plate": "CT 4812F", "model": "Toyota Corolla", "kind": "fleet", "city": "Toruń", "oc_until": day(10)})
        self.g = core.save_driver({"name": "Gennadii Sabadash", "kind": "fleet", "city": "Toruń", "phone": "500 600 700"})
        core.fleet_crew_set(self.f, "day", self.g, day(-2))
        core.fleet_cash_store(day(), [(self.g, 432.38, 144)])

    def test_plate_and_partial_plate(self):
        r = core.office_search("ct4812f")
        self.assertEqual([(c["plate"], c["kind"], c["day"]["name"]) for c in r["cars"]], [("CT4812F", "fleet", "Gennadii Sabadash")])
        self.assertEqual([c["plate"] for c in core.office_search("AA111")["cars"]], ["AA111"])
        self.assertEqual(core.office_search("4812")["cars"][0]["plate"], "CT4812F")

    def test_driver_name_rent_and_fleet(self):
        r = core.office_search("sabadash")
        self.assertEqual([(d["name"], d["kind"], d["plate"], d["shift"], d["cash"]) for d in r["drivers"]],
                         [("Gennadii Sabadash", "fleet", "CT4812F", "day", 432.38)])
        self.assertEqual([(d["kind"], d["plate"]) for d in core.office_search("Jan Test")["drivers"]], [("rent", "AA111")])

    def test_too_short_and_nothing(self):
        self.assertEqual(core.office_search("ab")["cars"], [])
        r = core.office_search("Nikt Taki")
        self.assertEqual((r["cars"], r["drivers"]), ([], []))


@unittest.skipIf(office is None, "brak bibliotek bota (uruchom testy z .venv)")
class OfficeTextsTest(OfficeSearchTest):
    def test_status_has_fleet_and_cash(self):
        txt = office.status_text(core.dashboard(), "pl", core.fleet_view())
        self.assertIn("🚕 Flota: 1 samochodów, 1 kierowców, wolne zmiany: 1", txt)
        self.assertIn("Toruń: 1 sam., 1 kier.", txt)
        self.assertIn("💵 Gotówka", txt)
        self.assertIn("432,38 zł", txt)
        self.assertNotIn("Flota", office.status_text(core.dashboard(), "pl", None))

    def test_cash_and_fleet_lists(self):
        fv = core.fleet_view()
        self.assertIn("Gennadii Sabadash — 432,38 zł", office.cash_text(fv, "pl"))
        self.assertIn("Razem: 0 zł (0 kierowców)", office.cash_text(fv, "pl", "Grudziądz"))
        ft = office.fleet_text(fv, "ru")
        self.assertIn("🚕 CT4812F Toyota Corolla", ft)
        self.assertIn("☀️ День: Gennadii Sabadash · 🌙 Ночь: свободна", ft)
        self.assertIn("через 10 дн.", ft)

    def test_cards(self):
        r = core.office_search("CT4812F")
        card = office.car_card(r["cars"][0], "pl")
        self.assertIn("Flota · Toruń", card)
        self.assertIn("☀️ Dzień: Gennadii Sabadash", card)
        d = core.office_search("Sabadash")
        card = office.driver_card(d["drivers"][0], "uk", d["cash_week"])
        self.assertIn("Машина: CT4812F · день", card)
        self.assertIn("432,38 zł", card)
        self.assertIn("не підключено", card)
        rent = office.car_card(core.office_search("AA111")["cars"][0], "pl")
        self.assertIn("Wynajem", rent)
        self.assertIn("Kierowca: Jan Test", rent)

    def test_city_words(self):
        self.assertEqual([office._city(x) for x in ("torun", "Toruń", "GRUDZ", "Grudziądz", "", "Warszawa")],
                         ["Toruń", "Toruń", "Grudziądz", "Grudziądz", None, None])


if __name__ == "__main__":
    unittest.main()
