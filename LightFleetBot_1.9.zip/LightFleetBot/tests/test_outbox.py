import asyncio
import datetime as dt
import unittest
from pathlib import Path

from base import FleetTest, core

try:
    from aiogram.exceptions import TelegramForbiddenError, TelegramNetworkError, TelegramRetryAfter
    from fleetbot import db, outbox, scheduler
except ImportError:  # biblioteki bota są w .venv
    db = None

CHAT = 6936017050


class OutboxCoreTest(FleetTest):
    def test_dedupe_key(self):
        self.assertIsNotNone(core.outbox_add(CHAT, "OC AA111", key="doc:1:oc:2026-11-05"))
        self.assertIsNone(core.outbox_add(CHAT, "OC AA111", key="doc:1:oc:2026-11-05"))
        self.assertEqual(self.count("outbox"), 1)
        core.outbox_add(CHAT, "bez klucza")
        core.outbox_add(CHAT, "bez klucza")
        self.assertEqual(self.count("outbox"), 3)

    def test_empty_text(self):
        self.assertUserError(lambda: core.outbox_add(CHAT, "  "), "Pusta")

    def test_due_sent_and_send_after(self):
        a = core.outbox_add(CHAT, "teraz", buttons=[[["✅ Gotowe", "done:1"]]])
        core.outbox_add(CHAT, "jutro", send_after="2999-01-01 00:00:00")
        due = core.outbox_due()
        self.assertEqual([r["id"] for r in due], [a])
        self.assertEqual(due[0]["buttons"], [[["✅ Gotowe", "done:1"]]])
        core.outbox_sent(a, 99)
        self.assertEqual(core.outbox_due(), [])

    def test_failures(self):
        a = core.outbox_add(CHAT, "a")
        b = core.outbox_add(CHAT, "b")
        core.outbox_failed(a, "chat not found", permanent=True)
        core.outbox_failed(b, "timeout")
        self.assertEqual([r["id"] for r in core.outbox_due()], [b])
        for _ in range(core.OUTBOX_MAX_ATTEMPTS):
            core.outbox_failed(b, "timeout")
        self.assertEqual(core.outbox_due(), [])

    def test_job_runs(self):
        self.assertFalse(core.job_done("backup_cloud", "2026-11-05"))
        core.job_mark("backup_cloud", "2026-11-05", "ok")
        core.job_mark("backup_cloud", "2026-11-05", "ok")
        self.assertTrue(core.job_done("backup_cloud", "2026-11-05"))
        self.assertFalse(core.job_done("backup_cloud", "2026-11-06"))


@unittest.skipIf(db is None, "brak bibliotek bota (uruchom testy z .venv)")
class PeriodTest(unittest.TestCase):
    def test_daily(self):
        p = scheduler.daily(9, 30)
        self.assertIsNone(p(dt.datetime(2026, 11, 5, 9, 29)))
        self.assertEqual(p(dt.datetime(2026, 11, 5, 9, 30)), "2026-11-05")
        self.assertEqual(p(dt.datetime(2026, 11, 5, 23, 0)), "2026-11-05")

    def test_weekly_wednesday_evening(self):
        p = scheduler.weekly(2, 18)
        self.assertIsNone(p(dt.datetime(2026, 11, 4, 17, 59)))  # środa przed 18
        self.assertEqual(p(dt.datetime(2026, 11, 4, 18, 0)), "2026-W45")
        self.assertEqual(p(dt.datetime(2026, 11, 6, 10, 0)), "2026-W45")  # piątek: nadrabianie w tym samym tygodniu
        self.assertIsNone(p(dt.datetime(2026, 11, 9, 10, 0)))  # poniedziałek nowego tygodnia


class FakeBot:
    def __init__(self, error=None):
        self.error, self.sent = error, []

    async def send_message(self, chat_id, text, reply_markup=None):
        if self.error:
            raise self.error
        self.sent.append((chat_id, text, reply_markup))
        return type("M", (), {"message_id": len(self.sent)})()


@unittest.skipIf(db is None, "brak bibliotek bota (uruchom testy z .venv)")
class BotQueueTest(FleetTest):
    def setUp(self):
        super().setUp()
        self.main_db = core.DBX
        db.configure({"mode": "local"}, Path(core.DB))
        scheduler._wait_until.clear()

    def tearDown(self):
        bot_db = core.DBX
        if bot_db is not self.main_db and hasattr(bot_db, "conn"):
            db.POOL.submit(bot_db.close).result()
        core.DBX = self.main_db
        super().tearDown()

    def call(self, fn, *a):
        return asyncio.run(db.call(fn, *a))

    def test_send_and_mark(self):
        self.call(core.outbox_add, CHAT, "Raport", None, [[["OK", "ok"]]])
        bot = FakeBot()
        self.assertEqual(asyncio.run(outbox.send_due(bot)), (1, 0, True))
        self.assertEqual(bot.sent[0][1], "Raport")
        self.assertEqual(bot.sent[0][2].inline_keyboard[0][0].callback_data, "ok")
        self.assertEqual(asyncio.run(outbox.send_due(bot)), (0, 0, True))  # drugi raz nie wysyła

    def test_network_down_keeps_message(self):
        self.call(core.outbox_add, CHAT, "Raport")
        self.assertEqual(asyncio.run(outbox.send_due(FakeBot(TelegramNetworkError(None, "no internet")))), (0, 0, False))
        due = self.call(core.outbox_due)
        self.assertEqual((len(due), due[0]["attempts"]), (1, 0))
        bot = FakeBot()
        asyncio.run(outbox.send_due(bot))  # sieć wróciła
        self.assertEqual(len(bot.sent), 1)

    def test_retry_after_keeps_message(self):
        self.call(core.outbox_add, CHAT, "Raport")
        asyncio.run(outbox.send_due(FakeBot(TelegramRetryAfter(None, "flood", 0))))
        self.assertEqual(len(self.call(core.outbox_due)), 1)

    def test_blocked_chat_is_dropped(self):
        self.call(core.outbox_add, CHAT, "Raport")
        self.assertEqual(asyncio.run(outbox.send_due(FakeBot(TelegramForbiddenError(None, "blocked")))), (0, 1, True))
        self.assertEqual(self.call(core.outbox_due), [])

    def test_scheduler_runs_once_per_period_and_catches_up(self):
        runs = []

        async def job(ctx):
            runs.append(ctx["x"])
            return "ok"
        jobs = [scheduler.Job("test", scheduler.daily(3), job)]
        late = dt.datetime(2026, 11, 5, 11, 0)  # bot wstał o 11:00, zadanie było na 3:00
        self.assertEqual(asyncio.run(scheduler.tick(jobs, {"x": 1}, late)), [("test", "2026-11-05")])
        self.assertEqual(asyncio.run(scheduler.tick(jobs, {"x": 1}, late)), [])
        self.assertEqual(runs, [1])
        self.assertEqual(asyncio.run(scheduler.tick(jobs, {"x": 1}, dt.datetime(2026, 11, 6, 2, 0))), [])  # jeszcze nie pora
        asyncio.run(scheduler.tick(jobs, {"x": 2}, dt.datetime(2026, 11, 6, 3, 0)))
        self.assertEqual(runs, [1, 2])

    def test_failed_job_not_marked(self):
        async def bad(ctx):
            raise ValueError("x")
        jobs = [scheduler.Job("bad", scheduler.daily(0), bad)]
        self.assertEqual(asyncio.run(scheduler.tick(jobs, {}, dt.datetime(2026, 11, 5, 1, 0))), [])
        self.assertFalse(self.call(core.job_done, "bad", "2026-11-05"))


if __name__ == "__main__":
    unittest.main()
