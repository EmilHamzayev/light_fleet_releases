﻿# Instalacja bota LIGHT jako usługi Windows (NSSM). Uruchomić w PowerShell "Jako administrator":
#   powershell -ExecutionPolicy Bypass -File service\install_service.ps1
# Usługa: start razem z Windows (opóźniony, po sieci), restart po awarii, dziennik w logs\service.log.
$ErrorActionPreference = "Stop"
$Name = "LightFleetBot"
$Root = Split-Path -Parent $PSScriptRoot
$Nssm = Join-Path $PSScriptRoot "nssm.exe"
$Python = Join-Path $Root ".venv\Scripts\python.exe"
$Logs = Join-Path $Root "logs"

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Uruchom PowerShell jako administrator."
}
foreach ($f in @($Nssm, $Python, (Join-Path $Root ".env"))) { if (-not (Test-Path $f)) { throw "Brak pliku: $f" } }
New-Item -ItemType Directory -Force $Logs | Out-Null

if (Get-Service $Name -ErrorAction SilentlyContinue) {
    & $Nssm stop $Name | Out-Null
    & $Nssm remove $Name confirm | Out-Null
}
& $Nssm install $Name $Python "-X utf8 -m fleetbot"
& $Nssm set $Name AppDirectory $Root
& $Nssm set $Name DisplayName "LIGHT Fleet Manager - bot Telegram"
& $Nssm set $Name Description "LIGHT office Telegram bot (python -m fleetbot), shared cloud database with the program."
& $Nssm set $Name Start SERVICE_DELAYED_AUTO_START
# Ścieżki użytkownika (kopie bazy w %LOCALAPPDATA%\LIGHT Fleet Manager), bo usługa działa jako konto systemowe
& $Nssm set $Name AppEnvironmentExtra "LOCALAPPDATA=$env:LOCALAPPDATA" "PYTHONUNBUFFERED=1"
& $Nssm set $Name AppStdout (Join-Path $Logs "service.log")
& $Nssm set $Name AppStderr (Join-Path $Logs "service.log")
& $Nssm set $Name AppRotateFiles 1
& $Nssm set $Name AppRotateBytes 5242880
# Restart po każdym zakończeniu (awaria, brak sieci, zamek zajęty - kod 3) po 30 s
& $Nssm set $Name AppExit Default Restart
& $Nssm set $Name AppRestartDelay 30000
& $Nssm set $Name AppThrottle 60000
# Zatrzymanie: Ctrl+C -> bot zwalnia zamek i kończy się sam
& $Nssm set $Name AppStopMethodConsole 15000
& $Nssm start $Name
Start-Sleep -Seconds 3
Get-Service $Name | Format-Table -AutoSize Status, Name, DisplayName, StartType
