﻿# Usunięcie usługi bota (PowerShell "Jako administrator"):
#   powershell -ExecutionPolicy Bypass -File service\remove_service.ps1
$ErrorActionPreference = "Stop"
$Name = "LightFleetBot"
$Nssm = Join-Path $PSScriptRoot "nssm.exe"
if (-not (Get-Service $Name -ErrorAction SilentlyContinue)) { "Usługi $Name nie ma."; return }
& $Nssm stop $Name
& $Nssm remove $Name confirm
