﻿# Полная установка бота LIGHT на офисный компьютер (один раз). Запуск — PowerShell «Запуск от имени администратора»:
#   powershell -ExecutionPolicy Bypass -File service\setup_bot_pc.ps1
# Повторный запуск безопасен: уже сделанные шаги пропускаются, служба переустанавливается.
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Venv = Join-Path $Root ".venv\Scripts\python.exe"
$Env = Join-Path $Root ".env"
$Nssm = Join-Path $PSScriptRoot "nssm.exe"

function Step($n, $text) { Write-Host ""; Write-Host "[$n/6] $text" -ForegroundColor Cyan }
function Fail($text) { Write-Host ""; Write-Host "СТОП: $text" -ForegroundColor Red; exit 1 }

$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin) { Fail "Запустите PowerShell от имени администратора (правый клик -> Запуск от имени администратора)." }

Step 1 "Python"
$Py = $null
foreach ($cand in "py -3", "python") {
    $parts = $cand -split " "
    $cmd = $parts[0]
    $extra = @($parts | Select-Object -Skip 1)
    if (Get-Command $cmd -ErrorAction SilentlyContinue) {
        try {
            $exe = & $cmd @extra -c "import sys; print(sys.executable if sys.version_info >= (3, 10) else '')" 2>$null
            if ($exe -and (Test-Path $exe)) { $Py = "$exe".Trim(); break }
        } catch { }
    }
}
if (-not $Py) { Fail "Нужен Python 3.10 или новее. Установите Python 3.12 с https://www.python.org/downloads/ (галочка «Add python.exe to PATH») и запустите скрипт снова." }
Write-Host "Python: $Py"

Step 2 "Окружение бота (.venv) и библиотеки"
if (-not (Test-Path $Venv)) { & $Py -m venv (Join-Path $Root ".venv") }
& $Venv -m pip install -q --upgrade pip
& $Venv -m pip install -q -r (Join-Path $Root "requirements-bot.txt")
if ($LASTEXITCODE -ne 0) { Fail "Не удалось установить библиотеки (нет интернета?)." }
Write-Host "Библиотеки установлены."

Step 3 "Настройки (.env)"
if (-not (Test-Path $Env)) {
    Copy-Item (Join-Path $Root ".env.example") $Env
    Start-Process notepad.exe $Env
    Fail "Создан файл .env и открыт в Блокноте. Вставьте TELEGRAM_BOT_TOKEN, TURSO_AUTH_TOKEN, ADMIN_IDS, OFFICE_CHAT_ID, сохраните и запустите скрипт снова."
}
$text = Get-Content $Env -Raw -Encoding UTF8
foreach ($key in @("TELEGRAM_BOT_TOKEN", "TURSO_AUTH_TOKEN", "OFFICE_CHAT_ID")) {
    if ($text -notmatch "(?m)^$key=\S+") { Start-Process notepad.exe $Env; Fail "В .env не заполнено $key. Заполните, сохраните и запустите скрипт снова." }
}
Write-Host "Настройки на месте (значения не показываются)."

Step 4 "Проверка бота: база и Telegram"
& $Venv -X utf8 -m fleetbot --check
if ($LASTEXITCODE -ne 0) { Fail "Проверка не прошла — см. сообщение выше (токен, интернет)." }

Step 5 "NSSM (программа для службы Windows)"
if (-not (Test-Path $Nssm)) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $zip = Join-Path $PSScriptRoot "nssm-2.24.zip"
    $tmp = Join-Path $env:TEMP "nssm-2.24-unpack"
    try { Invoke-WebRequest "https://nssm.cc/release/nssm-2.24.zip" -OutFile $zip -UseBasicParsing }
    catch { Fail "Не удалось скачать NSSM с nssm.cc. Скачайте nssm-2.24.zip вручную, возьмите win64\nssm.exe и положите в папку service, затем запустите скрипт снова." }
    Expand-Archive $zip $tmp -Force
    Copy-Item (Join-Path $tmp "nssm-2.24\win64\nssm.exe") $Nssm
    Remove-Item $zip, $tmp -Recurse -Force
}
Write-Host "NSSM: $Nssm"

Step 6 "Служба LightFleetBot"
& (Join-Path $PSScriptRoot "install_service.ps1")
Start-Sleep -Seconds 20
$log = Join-Path $Root "logs\bot.log"
if (Test-Path $log) { Write-Host ""; Write-Host "Последние строки журнала:"; Get-Content $log -Tail 6 -Encoding UTF8 }
Write-Host ""
Write-Host "Готово. Бот работает как служба и запускается вместе с Windows." -ForegroundColor Green
Write-Host "Если в журнале «Działa już inny bot» — где-то ещё запущен бот; служба сама повторит запуск через 30 секунд."
