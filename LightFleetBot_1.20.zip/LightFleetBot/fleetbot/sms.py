"""SMS przez telefon biura: aplikacja SMS Gateway for Android (capcom6), tryb "Local Server" w sieci biura.

Wysyłka: kolejka sms_out w bazie -> POST {SMS_URL}/message (Basic auth). Telefon niedostępny -> SMS czeka w kolejce.
Odbiór: co ~30 s GET {SMS_URL}/inbox -> nowe SMS do bazy (sms_in) i do biura w Telegramie (przez outbox).
Przy pierwszym uruchomieniu stare SMS z telefonu nie są przesyłane (punkt startu w app_settings).
"""
import asyncio
import base64
import datetime as dt
import json
import logging
import urllib.error
import urllib.parse
import urllib.request

from . import db
from .i18n import t

log = logging.getLogger("fleetbot.sms")
TIMEOUT = 15
SEND_EVERY, INBOX_EVERY = 10, 30
SINCE_KEY = "sms_inbox_since"


class GatewayDown(Exception):
    """Telefon/aplikacja niedostępne (sieć) - spróbujemy później, bez liczenia próby."""


class GatewayError(Exception):
    def __init__(self, status, body):
        super().__init__("HTTP %s: %s" % (status, (body or "")[:300]))
        self.status = status


class Gateway:
    def __init__(self, url, user, password, opener=None):
        self.url = url.rstrip("/")
        self.auth = "Basic " + base64.b64encode(("%s:%s" % (user, password)).encode()).decode()
        self.open = opener or urllib.request.urlopen

    def _req(self, method, path, body=None):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(self.url + path, data=data, method=method,
                                     headers={"Authorization": self.auth, "Content-Type": "application/json"})
        try:
            with self.open(req, timeout=TIMEOUT) as r:
                raw = r.read().decode("utf-8", "replace")
                return json.loads(raw) if raw.strip() else None
        except urllib.error.HTTPError as e:
            raise GatewayError(e.code, e.read().decode("utf-8", "replace")) from e
        except (urllib.error.URLError, OSError) as e:
            raise GatewayDown(str(e)) from e

    def send(self, sid, phone, text):
        """Zwraca id wiadomości w telefonie. Nasze id (lf-<id>) chroni przed podwójną wysyłką przy powtórce."""
        r = self._req("POST", "/message", {"id": "lf-%d" % sid, "textMessage": {"text": text}, "phoneNumbers": [phone]})
        return (r or {}).get("id") or "lf-%d" % sid

    def inbox(self, since, limit=100):
        qs = urllib.parse.urlencode({"type": "SMS", "limit": limit, "from": since})
        return self._req("GET", "/inbox?" + qs) or []

    def health(self):
        return self._req("GET", "/health")


def from_config(cfg):
    if not cfg.sms_url:
        return None
    return Gateway(cfg.sms_url, cfg.sms_user, cfg.sms_password)


def parse_inbox(rows):
    """Wiersze /inbox -> [{'key', 'phone', 'text', 'received_at'}]. Id z telefonu nie są gwarantowanie unikalne,
    więc klucz = id + nadawca + czas."""
    out = []
    for r in rows or []:
        phone = r.get("sender") or r.get("phoneNumber") or ""
        when = r.get("createdAt") or r.get("receivedAt") or ""
        if not phone:
            continue
        out.append({"key": "%s|%s|%s" % (r.get("id") or "", phone, when), "phone": phone,
                    "text": r.get("contentPreview") or r.get("message") or r.get("text") or "", "received_at": when})
    return out


async def send_due(gw, cfg):
    """Jedna runda wysyłki. Zwraca (wysłane, odrzucone, czy_telefon_działa)."""
    sent = failed = 0
    for r in await db.call(db.core.sms_due):
        try:
            gid = await asyncio.to_thread(gw.send, r["id"], r["phone"], r["text"])
        except GatewayDown as e:
            log.warning("Telefon SMS niedostępny: %s", e)
            return sent, failed, False
        except GatewayError as e:
            if e.status in (401, 403):  # złe SMS_USER/SMS_PASSWORD - SMS czekają, biuro dostaje ostrzeżenie raz dziennie
                log.error("Telefon SMS odrzuca logowanie: %s", e)
                if cfg.office_chat_id:
                    await db.call(db.core.outbox_add, cfg.office_chat_id, t(cfg.group_lang, "sms_auth"),
                                  "smsauth:" + dt.date.today().isoformat())
                return sent, failed, False
            if e.status == 409:  # ta sama wiadomość już jest w telefonie (powtórka po zerwanym połączeniu)
                await db.call(db.core.sms_sent, r["id"], "lf-%d" % r["id"])
                sent += 1
                continue
            permanent = 400 <= e.status < 500 and e.status not in (408, 429)
            log.error("SMS %s do %s odrzucony: %s", r["id"], r["phone"], e)
            await db.call(db.core.sms_failed, r["id"], e, permanent)
            if (permanent or r["attempts"] + 1 >= db.core.SMS_MAX_ATTEMPTS) and cfg.office_chat_id:
                await db.call(db.core.outbox_add, cfg.office_chat_id,
                              t(cfg.group_lang, "sms_fail", phone=r["phone"], error=str(e)[:200]), "smsfail:%d" % r["id"])
            failed += 1
            continue
        await db.call(db.core.sms_sent, r["id"], gid)
        log.info("SMS %s wysłany do %s", r["id"], r["phone"])
        sent += 1
    return sent, failed, True


def _iso(d):
    return d.strftime("%Y-%m-%dT%H:%M:%S")


async def poll_inbox(gw, cfg, now=None):
    """Nowe SMS z telefonu -> baza + wiadomość do biura. Zwraca liczbę nowych."""
    now = now or dt.datetime.now()
    rows = await db.call(db.core.q, "SELECT value FROM app_settings WHERE key=?", (SINCE_KEY,))
    if not rows:  # pierwsze uruchomienie: starych SMS z telefonu nie przesyłamy
        await db.call(db.core.ex, "INSERT INTO app_settings(key,value) VALUES(?,?)", (SINCE_KEY, _iso(now)))
        log.info("SMS: odbiór od %s", _iso(now))
        return 0
    since = rows[0]["value"]
    items = parse_inbox(await asyncio.to_thread(gw.inbox, since))
    new = await db.call(db.core.sms_in_store, items)
    for it in new:
        d = it["driver"]
        text = (t(cfg.group_lang, "sms_in_known", name=d["name"], phone=it["phone"], text=it["text"]) if d
                else t(cfg.group_lang, "sms_in_unknown", phone=it["phone"], text=it["text"]))
        if cfg.office_chat_id:
            await db.call(db.core.outbox_add, cfg.office_chat_id, text, "smsin:" + it["key"][:200])
    if new:
        log.info("SMS: odebrano %d nowych", len(new))
    return len(new)


async def loop(cfg):
    gw = from_config(cfg)
    if gw is None:
        log.info("SMS wyłączone (brak SMS_URL w .env)")
        return
    try:
        await asyncio.to_thread(gw.health)
        log.info("Telefon SMS odpowiada (%s)", cfg.sms_url)
    except Exception as e:
        log.warning("Telefon SMS nie odpowiada (%s): %s", cfg.sms_url, e)
    last_inbox = 0.0
    while True:
        try:
            await send_due(gw, cfg)
            if asyncio.get_running_loop().time() - last_inbox >= INBOX_EVERY:
                last_inbox = asyncio.get_running_loop().time()
                await poll_inbox(gw, cfg)
        except (db.DbUnavailable, GatewayDown):
            pass
        except Exception:
            log.exception("Błąd pętli SMS")
        await asyncio.sleep(SEND_EVERY)
