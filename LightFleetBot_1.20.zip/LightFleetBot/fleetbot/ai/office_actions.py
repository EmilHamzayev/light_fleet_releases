"""Kolejne czynności asystenta (zapis tylko po "✅"): zmiany floty, kierowca wynajmu, nowy kierowca, właściciele,
olej, naprawy, SMS do kierowców, przeniesienie wpłat z arkusza KASA do programu.

Każda czynność: opis dla modelu (TOOLS), przygotowanie (PREPARE: sprawdzenie + linie karty, nic nie zapisuje)
i wykonanie (APPLY). Archiwum i usuwanie zostają w programie - chroni je hasło biura.
"""
import datetime as dt

from ..db import core

CITIES = ["Toruń", "Grudziądz"]
SMS_ON = False  # ustawia assistant.build, gdy jest telefon SMS (SMS_URL)


def _schema(props, required=()):
    return {"type": "object", "properties": props, "required": list(required), "additionalProperties": False}


DATE = {"type": "string", "description": "RRRR-MM-DD; bez tego - dziś"}
CARD = " Niczego nie zapisuje - biuro dostaje kartę z przyciskiem ✅."

TOOLS = [
    {"name": "set_fleet_shift",
     "description": "Kierowca floty na zmianę dzienną albo nocną samochodu floty od daty (bez driver_id - zmiana wolna). "
                    "Poprzedni kierowca tej zmiany schodzi dzień wcześniej, a nowy schodzi ze swojej dotychczasowej zmiany." + CARD,
     "input_schema": _schema({"car_id": {"type": "integer"}, "shift": {"type": "string", "enum": ["day", "night"]},
                              "driver_id": {"type": "integer"}, "date": DATE}, ["car_id", "shift"])},
    {"name": "assign_rent_driver",
     "description": "Kierowca na samochód wynajmu od daty (poprzedni kierowca schodzi). Bez driver_id i bez new_driver_name - "
                    "samochód zostaje wolny. new_driver_name - gdy kierowcy jeszcze nie ma w programie (zostanie dodany). "
                    "end - ostatni dzień, jeśli wynajem na określony czas." + CARD,
     "input_schema": _schema({"car_id": {"type": "integer"}, "driver_id": {"type": "integer"},
                              "new_driver_name": {"type": "string"}, "date": DATE,
                              "end": {"type": "string", "description": "RRRR-MM-DD, opcjonalnie"},
                              "pay_type": {"type": "string", "enum": ["cash", "salary"],
                                           "description": "cash = płaci gotówką, salary = potrącane z wypłaty"}}, ["car_id"])},
    {"name": "add_driver",
     "description": "Nowy kierowca w programie (bez samochodu; samochód - przez assign_rent_driver albo set_fleet_shift). "
                    "Dla floty wymagane miasto." + CARD,
     "input_schema": _schema({"name": {"type": "string", "description": "Imię i nazwisko"},
                              "kind": {"type": "string", "enum": ["rent", "fleet"]},
                              "phone": {"type": "string"}, "city": {"type": "string", "enum": CITIES},
                              "pay_type": {"type": "string", "enum": ["cash", "salary"]}}, ["name", "kind"])},
    {"name": "set_driver_phone",
     "description": "Zapisz albo zmień numer telefonu kierowcy (np. żeby móc wysłać mu SMS)." + CARD,
     "input_schema": _schema({"driver_id": {"type": "integer"}, "phone": {"type": "string"}}, ["driver_id", "phone"])},
    {"name": "pay_owner",
     "description": "Zaznacz, że zapłacono właścicielowi samochodów (kontrahentowi) rozliczenie. payment_id z owner_payments. "
                    "Bez amount - pełna kwota." + CARD,
     "input_schema": _schema({"payment_id": {"type": "integer"}, "amount": {"type": "number"}, "date": DATE}, ["payment_id"])},
    {"name": "accrue_owners_week",
     "description": "Nalicz właścicielom samochodów należność za tydzień (tylko auta, które miały kierowcę; bez duplikatów)." + CARD,
     "input_schema": _schema({"week": {"type": "string", "description": "Dowolny dzień tygodnia, RRRR-MM-DD"}}, ["week"])},
    {"name": "oil_change",
     "description": "Wymiana oleju w samochodzie przy danym przebiegu (km)." + CARD,
     "input_schema": _schema({"car_id": {"type": "integer"}, "km": {"type": "integer"}}, ["car_id", "km"])},
    {"name": "finish_repair",
     "description": "Naprawa wykonana. repair_id z car_details; cost - koszt, jeśli biuro podało." + CARD,
     "input_schema": _schema({"repair_id": {"type": "integer"}, "date": DATE, "cost": {"type": "number"}}, ["repair_id"])},
    {"name": "send_sms",
     "description": "SMS do kierowcy z telefonu biura (po polsku, chyba że biuro poprosi inaczej; krótko i uprzejmie). "
                    "Najpierw pokaż treść w karcie - wysyłka dopiero po ✅. Do kilku kierowców - osobna karta dla każdego." + CARD,
     "input_schema": _schema({"driver_id": {"type": "integer"}, "text": {"type": "string"}}, ["driver_id", "text"])},
    {"name": "import_kasa_payments",
     "description": "Przenieś do programu (ekran Gotówka, raport czwartkowy) wpłaty gotówki zapisane w arkuszu KASA za tydzień "
                    "zbierania (domyślnie ostatni zakończony). Bierze tylko wpisy z pełnym imieniem i nazwiskiem, których "
                    "jeszcze nie ma w programie; niepewne zwraca osobno." + CARD,
     "input_schema": _schema({"collected_week": {"type": "string", "description": "Dowolny dzień tygodnia zbierania, RRRR-MM-DD"}})},
]


def _day(a, key="date"):
    if not a.get(key):
        return core.today()
    d = core.parse_day(str(a[key]))
    if d is None:
        raise core.UserError("Nieprawidłowa data.")
    return d.isoformat()


def _one(sql, args, missing):
    r = core.q(sql, args)
    if not r:
        raise core.UserError(missing)
    return core._d(r[0])


def _dmy(iso):
    return core.dmy(iso) if iso else "—"


# ---- flota: zmiany
def _prep_shift(a, uid):
    car = _one("SELECT id, plate FROM cars WHERE id=? AND kind='fleet' AND active=1", (int(a["car_id"]),), "Samochód floty nie istnieje.")
    shift = a.get("shift")
    if shift not in core.SHIFTS:
        raise core.UserError("Wybierz zmianę.")
    date = _day(a)
    did = a.get("driver_id")
    drv = _one("SELECT id, name FROM drivers WHERE id=? AND kind='fleet' AND active=1", (int(did),), "Kierowca floty nie istnieje.") if did else None
    fv = core.fleet_view()
    c = next(x for x in fv["cars"] if x["id"] == car["id"])
    now = c[shift]
    if drv and now and now["driver_id"] == drv["id"]:
        raise core.UserError("%s już jest na tej zmianie." % drv["name"])
    if not drv and not now:
        raise core.UserError("Ta zmiana i tak jest wolna.")
    lines = ["Zmiana %s: %s → %s od %s" % (core.SHIFT_PL[shift], now["name"] if now else "wolna", drv["name"] if drv else "wolna", _dmy(date))]
    if drv:
        mine = next((x for x in fv["drivers"] if x["id"] == drv["id"]), None)
        if mine and mine["plate"]:
            lines.append("%s schodzi z %s (zmiana %s)" % (drv["name"], mine["plate"], core.SHIFT_PL[mine["shift"]]))
    return {"car_id": car["id"], "plate": car["plate"], "shift": shift, "driver_id": drv["id"] if drv else None, "date": date,
            "card": lines}


def _apply_shift(a, by):
    core.fleet_crew_set(a["car_id"], a["shift"], a["driver_id"], a["date"])


# ---- wynajem: kierowca na samochód
def _prep_assign(a, uid):
    car = _one("SELECT id, plate, kind FROM cars WHERE id=? AND active=1", (int(a["car_id"]),), "Samochód nie istnieje.")
    if car["kind"] == "fleet":
        raise core.UserError("To samochód floty - kierowców floty zmienia się przez set_fleet_shift.")
    d = {"car_id": car["id"], "date": _day(a), "end": _day(a, "end") if a.get("end") else None, "pay_type": a.get("pay_type")}
    if a.get("driver_id"):
        _one("SELECT id FROM drivers WHERE id=? AND kind='rent'", (int(a["driver_id"]),), "Kierowca wynajmu nie istnieje.")
        d["driver_id"] = int(a["driver_id"])
    elif (a.get("new_driver_name") or "").strip():
        d["new_name"] = " ".join(a["new_driver_name"].split())
    notes = core.assign_preview(d)
    if not notes:
        raise core.UserError("Bez zmian - ten kierowca już jest na tym samochodzie.")
    return dict(d, plate=car["plate"], card=notes)


def _apply_assign(a, by):
    core.assign_apply({k: a.get(k) for k in ("car_id", "driver_id", "new_name", "date", "end", "pay_type")})


# ---- nowy kierowca
def _prep_driver(a, uid):
    name = " ".join(str(a.get("name") or "").split())
    if len(name.split()) < 2:
        raise core.UserError("Podaj imię i nazwisko.")
    if any(core.norm_name(r["name"]) == core.norm_name(name) for r in core.q("SELECT name FROM drivers")):
        raise core.UserError("Kierowca %s już jest w programie." % name)
    kind = a.get("kind")
    if kind not in core.KINDS:
        raise core.UserError("Wynajem czy flota?")
    city = a.get("city") if kind == "fleet" else None
    if kind == "fleet" and city not in core.CITIES:
        raise core.UserError("Dla floty podaj miasto: Toruń albo Grudziądz.")
    phone = (a.get("phone") or "").strip()
    if phone and not core.e164(phone):
        raise core.UserError("Nieprawidłowy numer telefonu.")
    pay = a.get("pay_type") if a.get("pay_type") in core.PAY_TYPES else None
    lines = [name, "Flota · %s" % city if kind == "fleet" else "Wynajem"]
    if phone:
        lines.append("Tel. %s" % core.e164(phone))
    if pay:
        lines.append(core.PAY_TYPES[pay])
    return {"name": name, "kind": kind, "city": city, "phone": core.e164(phone) if phone else "", "pay_type": pay, "card": lines}


def _apply_driver(a, by):
    d = {"name": a["name"], "kind": a["kind"], "phone": a["phone"], "pay_type": a["pay_type"]}
    if a["kind"] == "fleet":
        d["city"] = a["city"]
    core.save_driver(d)


def _prep_phone(a, uid):
    d = _one("SELECT id, name, phone FROM drivers WHERE id=?", (int(a["driver_id"]),), "Kierowca nie istnieje.")
    phone = core.e164(a.get("phone"))
    if not phone:
        raise core.UserError("Nieprawidłowy numer telefonu.")
    if core.e164(d["phone"]) == phone:
        raise core.UserError("Ten numer już jest zapisany.")
    return {"driver_id": d["id"], "phone": phone, "card": [d["name"], "Tel. %s (było: %s)" % (phone, d["phone"] or "—")]}


def _apply_phone(a, by):
    if not core.q("SELECT 1 FROM drivers WHERE id=?", (a["driver_id"],)):
        raise core.UserError("Kierowca nie istnieje.")
    core.ex("UPDATE drivers SET phone=? WHERE id=?", (a["phone"], a["driver_id"]))


# ---- właściciele samochodów
def _prep_pay_owner(a, uid):
    p = _one("SELECT p.id, p.period, p.amount, p.paid_date, k.name FROM payments p JOIN contractors k ON k.id=p.contractor_id WHERE p.id=?",
             (int(a["payment_id"]),), "Płatność nie istnieje.")
    if p["paid_date"]:
        raise core.UserError("To rozliczenie jest już zapłacone (%s)." % _dmy(p["paid_date"]))
    amount = core.flt(a["amount"]) if a.get("amount") not in (None, "") else p["amount"]
    if amount is None or amount < 0:
        raise core.UserError("Podaj kwotę.")
    date = _day(a)
    return {"payment_id": p["id"], "amount": round(amount, 2), "date": date,
            "card": ["%s · %s" % (p["name"], p["period"]), "Zapłacono %s zł z %s zł · %s" % (_zl(amount), _zl(p["amount"]), _dmy(date))]}


def _zl(n):
    return ("{:,.2f}".format(n or 0)).replace(",", " ").replace(".", ",").replace(",00", "")


def _prep_accrue(a, uid):
    d = core.parse_date(a.get("week"))
    if not d:
        raise core.UserError("Podaj tydzień.")
    mon = core.monday_of(d)
    if mon > core.monday_of(dt.date.today()):
        raise core.UserError("Ten tydzień jeszcze się nie zaczął.")
    period = core.week_period(mon)
    return {"week": mon.isoformat(), "card": ["Naliczenie właścicielom za %s" % period, "Bez duplikatów: już naliczeni zostaną pominięci"]}


def _apply_accrue(a, by):
    return core.accrue_week(a["week"])


# ---- olej i naprawy
def _prep_oil(a, uid):
    car = _one("SELECT id, plate, mileage, oil_last_km FROM cars WHERE id=? AND active=1", (int(a["car_id"]),), "Samochód nie istnieje.")
    km = core.num(a.get("km"))
    if km is None or km <= 0:
        raise core.UserError("Wpisz liczbę.")
    if car["oil_last_km"] and km < car["oil_last_km"]:
        raise core.UserError("Poprzednia wymiana była przy %d km - podaj większy przebieg." % car["oil_last_km"])
    return {"car_id": car["id"], "plate": car["plate"], "km": km,
            "card": ["Wymiana oleju przy %s km" % _km(km), "Poprzednia: %s km" % _km(car["oil_last_km"]) if car["oil_last_km"] else "Poprzednia: —"]}


def _km(n):
    return "{:,}".format(int(n or 0)).replace(",", " ")


def _prep_repair_done(a, uid):
    r = _one("SELECT r.id, r.text, r.done_at, r.cost, c.plate FROM repairs r JOIN cars c ON c.id=r.car_id WHERE r.id=?",
             (int(a["repair_id"]),), "Naprawa nie istnieje.")
    if r["done_at"]:
        raise core.UserError("Ta naprawa jest już zamknięta (%s)." % _dmy(r["done_at"]))
    cost = core.flt(a["cost"]) if a.get("cost") not in (None, "") else None
    date = _day(a)
    lines = ["%s: %s" % (r["plate"], r["text"]), "Wykonana %s" % _dmy(date)]
    if cost is not None:
        lines.append("Koszt: %s zł" % _zl(cost))
    return {"repair_id": r["id"], "plate": r["plate"], "date": date, "cost": cost, "card": lines}


def _apply_repair_done(a, by):
    core.done_repair(a["repair_id"], a["date"], a.get("cost"))


# ---- SMS do kierowcy
def _prep_sms(a, uid):
    if not SMS_ON:
        raise core.UserError("SMS są wyłączone: w .env bota nie ma SMS_URL (telefon biura z aplikacją SMS Gateway).")
    d = _one("SELECT id, name, phone FROM drivers WHERE id=?", (int(a["driver_id"]),), "Kierowca nie istnieje.")
    phone = core.e164(d["phone"])
    if not phone:
        raise core.UserError("Kierowca %s nie ma w programie poprawnego numeru telefonu." % d["name"])
    text = (a.get("text") or "").strip()
    if not text:
        raise core.UserError("Pusta wiadomość.")
    if len(text) > core.SMS_MAX_LEN:
        raise core.UserError("Wiadomość jest za długa.")
    return {"driver_id": d["id"], "name": d["name"], "phone": phone, "text": text, "card": ["%s · %s" % (d["name"], phone), text]}


def _apply_sms(a, by):
    core.sms_add(a["phone"], a["text"], None, a["driver_id"], by)


# ---- wpłaty z arkusza KASA -> program
def _prep_kasa_import(a, uid):
    from . import tools
    r = tools.run("cash_reconcile", {"collected_week": a.get("collected_week")} if a.get("collected_week") else {})
    week = r["collected_week"].split("..")[0]
    have = {}
    for x in core.q("SELECT driver_id, amount FROM cash_entries WHERE week_start=? AND kind='cash'", (week,)):
        have.setdefault(x["driver_id"], []).append(x["amount"])
    items, unsure = [], []
    for d in r["drivers"]:
        pool = list(have.get(d["driver_id"], []))
        for e in d["kasa_entries"]:
            hit = next((i for i, v in enumerate(pool) if abs(v - e["amount"]) < 0.01), None)
            if hit is not None:
                pool.pop(hit)  # już w programie
                continue
            (items if e["matched_by"] == "full" else unsure).append(
                {"driver_id": d["driver_id"], "name": d["name"], "amount": e["amount"], "date": e["date"], "text": e["text"]})
    if not items:
        raise core.UserError("Nie ma nowych wpłat z KASA do przeniesienia za tydzień %s.%s" % (
            r["collected_week"], " Niepewne (tylko imię albo nazwisko): %s" % unsure if unsure else ""))
    lines = ["Tydzień zbierania %s – %s" % (_dmy(week), _dmy(r["collected_week"].split("..")[1]))]
    lines += ["%s — %s zł (%s)" % (i["name"], _zl(i["amount"]), _dmy(i["date"])[:5]) for i in items]
    lines.append("Razem: %s zł" % _zl(sum(i["amount"] for i in items)))
    return {"week": week, "items": items, "unsure": unsure, "card": lines}


def _apply_kasa_import(a, by):
    stmts = []
    for i in a["items"]:
        dup = core.q("SELECT 1 FROM cash_entries WHERE driver_id=? AND week_start=? AND kind='cash' AND ABS(amount-?)<0.01 AND entry_date=?",
                     (i["driver_id"], a["week"], i["amount"], i["date"]))
        if not dup:
            stmts.append(("INSERT INTO cash_entries(driver_id,week_start,kind,amount,entry_date,note,created_at) VALUES(?,?,?,?,?,?,?)",
                          (i["driver_id"], a["week"], "cash", i["amount"], i["date"], "KASA", core.now())))
    core.tx(stmts)


PREPARE = {"set_fleet_shift": _prep_shift, "assign_rent_driver": _prep_assign, "add_driver": _prep_driver,
           "set_driver_phone": _prep_phone, "pay_owner": _prep_pay_owner, "accrue_owners_week": _prep_accrue, "oil_change": _prep_oil,
           "finish_repair": _prep_repair_done, "send_sms": _prep_sms, "import_kasa_payments": _prep_kasa_import}
APPLY = {"set_fleet_shift": _apply_shift, "assign_rent_driver": _apply_assign, "add_driver": _apply_driver,
         "set_driver_phone": _apply_phone,
         "pay_owner": lambda a, by: core.toggle_payment(a["payment_id"], a["amount"], a["date"]),
         "accrue_owners_week": _apply_accrue, "oil_change": lambda a, by: core.oil_done(a["car_id"], a["km"]),
         "finish_repair": _apply_repair_done, "send_sms": _apply_sms, "import_kasa_payments": _apply_kasa_import}
