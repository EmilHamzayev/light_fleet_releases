"""Asystent AI biura: rozmowa zwykłym językiem, dane tylko z fleet_core, zapis dopiero po "✅" biura."""
