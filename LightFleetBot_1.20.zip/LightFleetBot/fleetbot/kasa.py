"""Arkusz Google "KASA BIURO NOWA" (tylko odczyt): przychody kasy biura w Toruniu - kto oddał gotówkę.

Czytamy wyłącznie kolumny A-C arkusza KASA od wiersza 9: Data, opis przychodu, kwota (najnowsze na górze; pusta data =
ta sama co wyżej). Wydatków, serwisu i pozostałych kas nie czytamy (RODO). Biuro wpisuje kierowcę z Torunia jako
"Imię Nazwisko Gotówka"; Grudziądz przychodzi jedną kwotą "GRDZ Gotówka" - bez podziału na kierowców.
"""
import re
import time
from dataclasses import dataclass

from .sheets import SCOPES, parse_amount, to_iso

SHEET_NAME = "KASA"
RANGE = "A9:C700"
CACHE_S = 60
SKIP_WORDS = {"gotówka", "gotowka", "got", "tyg", "wynajem", "zł", "zl"}
FOLD = str.maketrans("ąćęłńóśźż", "acelnoszz")


@dataclass
class Entry:
    date: str  # RRRR-MM-DD
    text: str
    amount: float


def parse(values):
    """Wiersze A:C -> wpisy przychodu (z opisem i kwotą > 0); data przenoszona z wiersza wyżej."""
    out, last = [], ""
    for r in values:
        r = (list(r) + ["", "", ""])[:3]
        d = to_iso((r[0] or "").strip())
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", d or ""):
            last = d
        text, amount = " ".join((r[1] or "").split()), parse_amount(r[2])
        if text and amount and amount > 0 and last:
            out.append(Entry(last, text, amount))
    return out


def words(text):
    """Słowa do porównania imion: bez nawiasów, cyfr, 'Gotówka' i polskich ogonków."""
    text = re.sub(r"\(.*?\)", " ", text or "").casefold()
    return [w.translate(FOLD) for w in re.findall(r"[^\W\d_]+", text) if w not in SKIP_WORDS and len(w) > 1]


def is_cash(text):
    return "gotówk" in text.casefold() or "gotowk" in text.casefold()


def is_grdz(text):
    return any(w == "grdz" or w.startswith("grudzi") for w in words(text))


def match(entries, drivers):
    """Przypisanie wpisów do kierowców floty.

    drivers: [{'driver_id', 'name'}]. Zwraca (by_driver, grdz, unknown, unclear):
    by_driver {driver_id: [(Entry, pewność)]} - 'full' = całe imię i nazwisko, 'part' = tylko imię albo nazwisko
    (jedyny taki kierowca); grdz - wpisy zbiorcze Grudziądza; unknown - "Gotówka" od osób spoza floty;
    unclear - [(Entry, [imiona])] gdy pasuje kilku kierowców. Pozostałe przychody (wynajem, zasilenie kasy) pomijamy.
    """
    names = [(d["driver_id"], d["name"], set(words(d["name"]))) for d in drivers]
    by_driver, grdz, unknown, unclear = {}, [], [], []
    for e in entries:
        if is_grdz(e.text):
            grdz.append(e)
            continue
        ew = set(words(e.text))
        if not ew:
            continue
        full = [(i, n) for i, n, w in names if w and w <= ew]
        part = [(i, n) for i, n, w in names if ew <= w] if is_cash(e.text) else []
        if len(full) == 1:
            by_driver.setdefault(full[0][0], []).append((e, "full"))
        elif not full and len(part) == 1:
            by_driver.setdefault(part[0][0], []).append((e, "part"))
        elif len(full) > 1 or len(part) > 1:
            unclear.append((e, sorted(n for _, n in (full or part))))
        elif is_cash(e.text):
            unknown.append(e)
    return by_driver, grdz, unknown, unclear


class Reader:
    """Odczyt arkusza z krótką pamięcią (kilka pytań pod rząd = jedno pobranie)."""

    def __init__(self, key_file, sheet_id, sheet_name=SHEET_NAME):
        self.key_file, self.sheet_id, self.sheet_name = str(key_file), sheet_id, sheet_name
        self._at, self._entries = 0.0, None

    def __call__(self):
        if self._entries is None or time.monotonic() - self._at > CACHE_S:
            import gspread
            gc = gspread.service_account(filename=self.key_file, scopes=SCOPES)
            ws = gc.open_by_key(self.sheet_id).worksheet(self.sheet_name)
            self._entries, self._at = parse(ws.get(RANGE)), time.monotonic()
        return self._entries
