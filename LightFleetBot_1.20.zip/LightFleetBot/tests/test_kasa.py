"""Arkusz KASA biura: odczyt wpisów, dopasowanie do kierowców floty, czynność asystenta cash_reconcile (bez internetu)."""
import asyncio
import datetime as dt
import unittest
from pathlib import Path

from base import FleetTest, core

try:
    from fleetbot import db, kasa
    from fleetbot.ai import tools
except ImportError:  # biblioteki bota są w .venv
    db = None


def E(date, text, amount):
    return kasa.Entry(date, text, amount)


@unittest.skipIf(db is None, "brak bibliotek bota (uruchom testy z .venv)")
class KasaParseTest(unittest.TestCase):
    def test_parse_carries_date_and_skips_empty(self):
        rows = [["2026-11-16", "Hubert Terajewicz Gotówka", "65"], ["2026-11-13", "", "", "wydatek", "5"],
                ["", "Zofia Gotówka", "210"], ["12.11.2026", "Andrii Anosov  Gotówka", "655,12"], ["", "Bez kwoty", ""],
                ["", "", "1934,71"], ["2026-11-10", "GRDZ Gotówka", "1 610,49"], ["5.8", "Lach", "442,5"]]
        got = [(e.date, e.text, e.amount) for e in kasa.parse(rows)]
        self.assertEqual(got, [("2026-11-16", "Hubert Terajewicz Gotówka", 65.0), ("2026-11-13", "Zofia Gotówka", 210.0),
                               ("2026-11-12", "Andrii Anosov Gotówka", 655.12), ("2026-11-10", "GRDZ Gotówka", 1610.49),
                               ("2026-11-10", "Lach", 442.5)])
        self.assertEqual(kasa.parse([["", "Jan Gotówka", "10"]]), [])  # bez daty nie wiemy, kiedy

    def test_words(self):
        self.assertEqual(kasa.words("Joanna Witt Gotówka (2 tyg)"), ["joanna", "witt"])
        self.assertEqual(kasa.words("Artur Porzeziński Gotówka"), ["artur", "porzezinski"])
        self.assertTrue(kasa.is_grdz("Gotówka GRDZ") and kasa.is_grdz("grudziądz gotówka") and not kasa.is_grdz("Grzegorz"))

    def test_match(self):
        drivers = [{"driver_id": 1, "name": "Andrii Anosov"}, {"driver_id": 2, "name": "Zofia Górecka"},
                   {"driver_id": 3, "name": "Jan Kowalski"}, {"driver_id": 4, "name": "Jan Nowak"},
                   {"driver_id": 5, "name": "Ramez Abdelfatah"}]
        entries = [E("2026-11-12", "Andrii Anosov Gotówka", 655.12), E("2026-11-13", "Zofia Gotówka", 210),
                   E("2026-11-13", "Jan Gotówka", 50), E("2026-11-10", "GRDZ Gotówka", 1610.49),
                   E("2026-11-10", "Katsiaryna Tkachenka Gotówka", 159.31), E("2026-11-12", "Bartosz Kufel (wynajem)", 750),
                   E("2026-11-04", "Ramez Abdelfatah", 114), E("2026-11-06", "Anton", 2200), E("2026-11-09", "ANOSOV ANDRII gotowka", 5)]
        by, grdz, unknown, unclear = kasa.match(entries, drivers)
        self.assertEqual([(e.amount, how) for e, how in by[1]], [(655.12, "full"), (5, "full")])
        self.assertEqual([(e.amount, how) for e, how in by[2]], [(210, "part")])  # tylko imię, jedyna Zofia
        self.assertEqual([(e.amount, how) for e, how in by[5]], [(114, "full")])  # pełne nazwisko bez słowa Gotówka
        self.assertNotIn(3, by)
        self.assertEqual([(e.text, names) for e, names in unclear], [("Jan Gotówka", ["Jan Kowalski", "Jan Nowak"])])
        self.assertEqual([e.amount for e in grdz], [1610.49])
        self.assertEqual([e.text for e in unknown], ["Katsiaryna Tkachenka Gotówka"])  # wynajem i "Anton" pominięte


@unittest.skipIf(db is None, "brak bibliotek bota (uruchom testy z .venv)")
class ReconcileTest(FleetTest):
    def setUp(self):
        super().setUp()
        self.main_db = core.DBX
        db.configure({"mode": "local"}, Path(core.DB))
        mon = dt.date.today() - dt.timedelta(days=dt.date.today().weekday())
        self.w2 = (mon - dt.timedelta(days=7)).isoformat()   # ostatni rozliczony tydzień
        self.w1 = (mon - dt.timedelta(days=14)).isoformat()  # tydzień wcześniej
        self.mon = mon.isoformat()
        mk = lambda n, c: core.save_driver({"name": n, "kind": "fleet", "city": c})  # noqa: E731
        self.an, self.zo, self.ra, self.ko = mk("Andrii Anosov", "Toruń"), mk("Zofia Górecka", "Toruń"), mk("Ramez Abdelfatah", "Toruń"), mk("Jerzy Kondziela", "Grudziądz")
        core.fleet_cash_store(self.mon, [(self.an, 1000, 1), (self.zo, 100, 2), (self.ra, 300, 3), (self.ko, 500, 4)])
        self.entries = []
        tools.KASA_READER = lambda: self.entries

    def tearDown(self):
        tools.KASA_READER = None
        bot_db = core.DBX
        if bot_db is not self.main_db and hasattr(bot_db, "conn"):
            db.POOL.submit(bot_db.close).result()
        core.DBX = self.main_db
        super().tearDown()

    def call(self, *a):
        return asyncio.run(db.call(tools.run, "cash_reconcile", *a))

    def by_name(self, r):
        return {d["name"]: (d["to_hand_over"], d["paid"], d["left"], d["status"]) for d in r["drivers"]}

    def add(self, driver, kind, amount, week=None):
        asyncio.run(db.call(core.cash_add, {"driver_id": driver, "week": week or self.w2, "kind": kind, "amount": amount}))

    def test_payment_brought_this_week_counts_for_last_week(self):
        """Zasada biura: gotówka zebrana w tygodniu W jest przynoszona w tygodniu W+1 (wpis w KASA z datą przyniesienia)."""
        self.entries = [E(self.mon, "Andrii Anosov Gotówka", 600), E(self.mon, "Zofia Gotówka", 100), E(self.mon, "GRDZ Gotówka", 450),
                        E(self.mon, "Obcy Człowiek Gotówka", 77), E(self.w2, "Ramez Abdelfatah Gotówka", 300)]  # to było za tydzień w1
        r = self.call({})
        sunday = (dt.date.fromisoformat(self.w2) + dt.timedelta(days=6)).isoformat()
        self.assertEqual(r["collected_week"], "%s..%s" % (self.w2, sunday))
        self.assertTrue(r["payments_counted_from_kasa"].startswith(self.mon + ".."))
        self.assertTrue(r["amounts_to_hand_over_loaded"])
        self.assertEqual(self.by_name(r), {"Andrii Anosov": (1000.0, 600.0, 400.0, "partial"), "Zofia Górecka": (100.0, 100.0, 0.0, "paid"),
                                           "Ramez Abdelfatah": (300.0, 0, 300.0, "not_paid"),
                                           "Jerzy Kondziela": (500.0, 0, 500.0, "unknown_grdz_lump")})
        self.assertEqual(r["total"], {"still_owed_known": 700.0, "drivers_still_owing": 2, "not_paid": 1, "partial": 1, "paid": 1})
        self.assertEqual((r["grudziadz"]["drivers_to_hand_over"], r["grudziadz"]["lump_paid_in_kasa"]), (500.0, 450.0))
        self.assertEqual([x["text"] for x in r["cash_from_people_not_in_fleet_list"]], ["Obcy Człowiek Gotówka"])
        zofia = next(d for d in r["drivers"] if d["name"] == "Zofia Górecka")
        self.assertEqual(zofia["kasa_entries"][0]["matched_by"], "part")
        self.assertEqual([d["name"] for d in self.call({"city": "Grudziądz"})["drivers"]], ["Jerzy Kondziela"])

    def test_day_of_payment_given_as_week_still_means_last_week(self):
        """Model (albo człowiek) podaje dzisiejszą datę / dzień wpłaty - tydzień jeszcze trwa, więc liczymy poprzedni."""
        self.entries = [E(self.mon, "Andrii Anosov Gotówka", 600)]
        today = dt.date.today().isoformat()
        for args in ({"collected_week": today}, {"week": today}, {"collected_week": self.mon}):
            r = self.call(args)
            self.assertTrue(r["collected_week"].startswith(self.w2), args)
            self.assertEqual(self.by_name(r)["Andrii Anosov"], (1000.0, 600.0, 400.0, "partial"))
            self.assertIn("jeszcze trwa", r["note_requested_week"])
        self.assertNotIn("note_requested_week", self.call({}))

    def test_week_before_is_counted_separately(self):
        asyncio.run(db.call(core.fleet_cash_store, self.w2, [(self.an, 200, 1)]))  # tydzień w1: 200 do oddania
        self.entries = [E(self.w2, "Andrii Anosov Gotówka", 150), E(self.mon, "Andrii Anosov Gotówka", 1000)]
        r = self.call({})
        self.assertEqual(self.by_name(r)["Andrii Anosov"], (1000.0, 1000.0, 0.0, "paid"))
        self.assertEqual(r["still_owed_from_week_before"], [{"name": "Andrii Anosov", "city": "Toruń", "left": 50.0}])
        old = self.call({"collected_week": self.w1})
        self.assertEqual(self.by_name(old), {"Andrii Anosov": (200.0, 150.0, 50.0, "partial")})
        self.assertTrue(old["payments_counted_from_kasa"].startswith(self.w2 + ".."))

    def test_invoices_and_program_entries_without_double_counting(self):
        self.add(self.zo, "invoice", 40)   # faktury zmniejszają kwotę do oddania
        self.add(self.an, "cash", 600)     # ta sama wpłata wpisana i w programie, i w KASA - liczymy raz
        self.add(self.ra, "cash", 300)     # wpłata tylko w programie (np. z karty asystenta)
        self.entries = [E(self.mon, "Andrii Anosov Gotówka", 600), E(self.mon, "Zofia Górecka Gotówka", 60)]
        r = self.call({})
        self.assertEqual(self.by_name(r), {"Andrii Anosov": (1000.0, 600.0, 400.0, "partial"), "Zofia Górecka": (60.0, 60.0, 0.0, "paid"),
                                           "Ramez Abdelfatah": (300.0, 300.0, 0.0, "paid"),
                                           "Jerzy Kondziela": (500.0, 0, 500.0, "unknown_grdz_lump")})
        ramez = next(d for d in r["drivers"] if d["name"] == "Ramez Abdelfatah")
        self.assertEqual(ramez["paid_in_program_only"], 300.0)

    def test_amounts_not_loaded_and_no_sheet(self):
        far = (dt.date.fromisoformat(self.w1) - dt.timedelta(days=21)).isoformat()
        r = self.call({"collected_week": far})
        self.assertFalse(r["amounts_to_hand_over_loaded"])
        self.assertIn("jeszcze nie ma", r["note_not_loaded"])
        self.assertEqual(r["drivers"], [])

        def broken():
            raise ConnectionError("brak sieci")
        tools.KASA_READER = broken
        self.assertUserError(lambda: self.call({}), "Nie udało się odczytać arkusza KASA")
        tools.KASA_READER = None
        self.assertUserError(lambda: self.call({}), "nie jest podłączony")

if __name__ == "__main__":
    unittest.main()
