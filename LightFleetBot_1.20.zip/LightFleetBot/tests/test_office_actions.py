"""Kolejne czynności asystenta (office_actions): zawsze najpierw karta, zapis dopiero po "✅"."""
import datetime as dt
import unittest

from base import core, day

try:
    from fleetbot import kasa
    from fleetbot.ai import office_actions, tools
    from fleetbot.handlers import assistant as cards
    from test_assistant import OFFICE, AiTest
except ImportError:  # biblioteki bota są w .venv
    tools = None
    AiTest = unittest.TestCase


@unittest.skipIf(tools is None, "brak bibliotek bota (uruchom testy z .venv)")
class OfficeActionsTest(AiTest):
    def prep(self, action, **a):
        return self.call(tools.run, action, a, OFFICE)

    def ok(self, r):
        self.assertEqual(self.call(tools.confirm, r["pending_id"], OFFICE)["state"], "done")

    def test_all_new_actions_are_registered(self):
        names = {x["name"] for x in tools.TOOLS}
        for n in office_actions.PREPARE:
            self.assertIn(n, names)
            self.assertIn(n, tools.WRITE)
            self.assertIn(n, tools.APPLY)
            for lang in ("pl", "ru", "uk"):
                self.assertTrue(cards.t(lang, "ai_card_" + n))
        self.assertEqual(len(names), len(tools.TOOLS))  # bez duplikatów nazw

    def test_fleet_shift(self):
        b = self.call(core.save_driver, {"name": "Borys Nocny", "kind": "fleet", "city": "Toruń"})
        r = self.prep("set_fleet_shift", car_id=self.car, shift="night", driver_id=b)
        self.assertEqual(r["prepared"]["card"], ["Zmiana nocna: wolna → Borys Nocny od %s" % core.dmy(day())])
        self.assertEqual(self.count("fleet_crews", "driver_id=?", (b,)), 0)
        self.ok(r)
        fv = self.call(core.fleet_view)
        self.assertEqual(fv["cars"][0]["night"]["name"], "Borys Nocny")
        # Sabadash (zmiana dzienna) na nocną: zejdzie z dziennej
        r = self.prep("set_fleet_shift", car_id=self.car, shift="night", driver_id=self.g, date=day(1))
        self.assertIn("Gennadii Sabadash schodzi z CT4812F (zmiana dzienna)", r["prepared"]["card"])
        self.assertUserError(lambda: self.prep("set_fleet_shift", car_id=self.car, shift="day", driver_id=self.g), "już jest na tej zmianie")
        self.assertUserError(lambda: self.prep("set_fleet_shift", car_id=self.c1, shift="day", driver_id=self.g), "floty nie istnieje")
        self.assertUserError(lambda: self.prep("set_fleet_shift", car_id=self.car, shift="day", driver_id=self.jan), "Kierowca floty")

    def test_rent_driver_change_and_new_driver_by_name(self):
        self.call(self.assign, self.c1, self.jan, day(-10))
        r = self.prep("assign_rent_driver", car_id=self.c1, driver_id=self.ola)
        self.assertIn("Jan Test zdjęty z AA111 (%s)" % core.dmy(day()), r["prepared"]["card"])
        self.ok(r)
        self.assertEqual(next(c for c in self.call(core.cars_list) if c["id"] == self.c1)["driver"], "Ola Test")
        r = self.prep("assign_rent_driver", car_id=self.c2, new_driver_name="Nowy  Kierowca", pay_type="cash")
        self.ok(r)
        self.assertEqual(next(c for c in self.call(core.cars_list) if c["id"] == self.c2)["driver"], "Nowy Kierowca")
        r = self.prep("assign_rent_driver", car_id=self.c2)  # bez kierowcy = auto wolne
        self.assertIn("BB222 zostaje bez kierowcy", r["prepared"]["card"])
        self.assertUserError(lambda: self.prep("assign_rent_driver", car_id=self.car, driver_id=self.jan), "set_fleet_shift")
        self.assertUserError(lambda: self.prep("assign_rent_driver", car_id=self.c1, driver_id=self.ola), "Bez zmian")

    def test_add_driver(self):
        r = self.prep("add_driver", name="Marek  Nowicki", kind="fleet", city="Grudziądz", phone="500 600 700")
        self.assertEqual(r["prepared"]["card"], ["Marek Nowicki", "Flota · Grudziądz", "Tel. +48500600700"])
        self.ok(r)
        d = self.call(core.q, "SELECT kind, city, phone FROM drivers WHERE name='Marek Nowicki'")[0]
        self.assertEqual((d["kind"], d["city"], d["phone"]), ("fleet", "Grudziądz", "+48500600700"))
        self.assertUserError(lambda: self.prep("add_driver", name="marek nowicki", kind="rent"), "już jest")
        self.assertUserError(lambda: self.prep("add_driver", name="Ktoś Nowy", kind="fleet"), "miasto")
        self.assertUserError(lambda: self.prep("add_driver", name="Jedno", kind="rent"), "imię i nazwisko")
        self.assertUserError(lambda: self.prep("add_driver", name="Ktoś Nowy", kind="rent", phone="123"), "telefonu")

    def test_owner_payments(self):
        self.call(self.assign, self.c1, self.jan, day(-10))
        r = self.prep("accrue_owners_week", week=day(-7))
        self.ok(r)
        pays = self.call(tools.run, "owner_payments", {"unpaid_only": True})
        self.assertEqual(pays["unpaid_count"], 1)
        pid = pays["payments"][0]["payment_id"]
        r = self.prep("pay_owner", payment_id=pid, amount=300)
        self.assertIn("Zapłacono 300 zł z 400 zł", r["prepared"]["card"][1])
        self.ok(r)
        self.assertEqual(self.call(tools.run, "owner_payments", {"unpaid_only": True})["unpaid_count"], 0)
        self.assertUserError(lambda: self.prep("pay_owner", payment_id=pid), "już zapłacone")
        self.assertUserError(lambda: self.prep("accrue_owners_week", week=day(30)), "jeszcze się nie zaczął")

    def test_oil_and_repair(self):
        r = self.prep("oil_change", car_id=self.c1, km=150000)
        self.ok(r)
        self.assertEqual(self.call(core.q, "SELECT oil_last_km FROM cars WHERE id=?", (self.c1,))[0]["oil_last_km"], 150000)
        self.assertUserError(lambda: self.prep("oil_change", car_id=self.c1, km=100), "większy przebieg")
        rid = self.call(core.add_repair, self.c1, "klocki", 200)
        det = self.call(tools.run, "car_details", {"car_id": self.c1})
        self.assertEqual(det["repairs"][0]["repair_id"], rid)
        r = self.prep("finish_repair", repair_id=rid, cost=250)
        self.assertEqual(r["prepared"]["card"], ["AA111: klocki", "Wykonana %s" % core.dmy(day()), "Koszt: 250 zł"])
        self.ok(r)
        row = self.call(core.q, "SELECT done_at, cost FROM repairs WHERE id=?", (rid,))[0]
        self.assertEqual((row["done_at"], row["cost"]), (day(), 250))
        self.assertUserError(lambda: self.prep("finish_repair", repair_id=rid), "już zamknięta")

    def test_driver_phone(self):
        r = self.prep("set_driver_phone", driver_id=self.jan, phone="0048 501-222-333")
        self.assertEqual(r["prepared"]["card"], ["Jan Test", "Tel. +48501222333 (było: —)"])
        self.ok(r)
        self.assertEqual(self.call(core.q, "SELECT phone FROM drivers WHERE id=?", (self.jan,))[0]["phone"], "+48501222333")
        self.assertUserError(lambda: self.prep("set_driver_phone", driver_id=self.jan, phone="501222333"), "już jest zapisany")
        self.assertUserError(lambda: self.prep("set_driver_phone", driver_id=self.jan, phone="12"), "Nieprawidłowy")

    def test_sms(self):
        office_actions.SMS_ON = False
        self.assertUserError(lambda: self.prep("send_sms", driver_id=self.g, text="Cześć"), "SMS są wyłączone")
        office_actions.SMS_ON = True
        try:
            self.assertUserError(lambda: self.prep("send_sms", driver_id=self.jan, text="Cześć"), "numeru telefonu")
            r = self.prep("send_sms", driver_id=self.g, text="Przypominamy o rozliczeniu gotówki.")
            self.assertEqual(r["prepared"]["card"], ["Gennadii Sabadash · +48500600700", "Przypominamy o rozliczeniu gotówki."])
            self.assertEqual(self.count("sms_out"), 0)
            self.ok(r)
            row = self.call(core.q, "SELECT phone, text, driver_id, created_by FROM sms_out")[0]
            self.assertEqual(tuple(row), ("+48500600700", "Przypominamy o rozliczeniu gotówki.", self.g, OFFICE))
        finally:
            office_actions.SMS_ON = False

    def test_kasa_import(self):
        mon = dt.date.today() - dt.timedelta(days=dt.date.today().weekday())
        last = (mon - dt.timedelta(days=7)).isoformat()
        self.call(core.fleet_cash_store, mon.isoformat(), [(self.g, 400, 1), (self.a, 300, 2)])
        entries = [kasa.Entry(mon.isoformat(), "Gennadii Sabadash Gotówka", 150), kasa.Entry(mon.isoformat(), "Adam Gotówka", 100)]
        tools.KASA_READER = lambda: entries
        try:
            r = self.prep("import_kasa_payments")
            p = r["prepared"]
            self.assertEqual([(i["name"], i["amount"]) for i in p["items"]], [("Gennadii Sabadash", 150)])
            self.assertEqual([i["name"] for i in p["unsure"]], ["Adam Nowak"])  # tylko imię - nie przenosimy
            self.assertEqual(p["week"], last)
            self.ok(r)
            row = self.call(core.q, "SELECT week_start, kind, amount, entry_date, note FROM cash_entries WHERE driver_id=?", (self.g,))
            self.assertEqual([tuple(x) for x in row], [(last, "cash", 150.0, mon.isoformat(), "KASA")])
            self.assertUserError(lambda: self.prep("import_kasa_payments"), "Nie ma nowych wpłat")  # drugi raz - nic
            rec = self.call(tools.run, "cash_reconcile", {})
            sab = next(d for d in rec["drivers"] if d["name"] == "Gennadii Sabadash")
            self.assertEqual((sab["paid"], sab["left"]), (150.0, 250.0))  # liczone raz, nie dwa razy
        finally:
            tools.KASA_READER = None

    def test_generic_card(self):
        a = {"plate": "AA111", "card": ["Wymiana oleju przy 150 000 km", "Poprzednia: —"]}
        self.assertEqual(cards.card_text("oil_change", a, "ru"), "🛢 Замена масла · AA111\nWymiana oleju przy 150 000 km\nPoprzednia: —")


if __name__ == "__main__":
    unittest.main()
