"""SMS przez telefon biura: kolejka w bazie, wysyłka do aplikacji SMS Gateway (udawany serwer HTTP), odbiór /inbox."""
import asyncio
import base64
import datetime as dt
import json
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from types import SimpleNamespace

from base import FleetTest, core

try:
    from fleetbot import db, sms
except ImportError:  # biblioteki bota są w .venv
    db = None

OFFICE = 6936017050


class SmsCoreTest(FleetTest):
    def test_e164(self):
        self.assertEqual(core.e164("500 600 700"), "+48500600700")
        self.assertEqual(core.e164("+48 500-600-700"), "+48500600700")
        self.assertEqual(core.e164("0048500600700"), "+48500600700")
        self.assertEqual(core.e164("+380 67 123 45 67"), "+380671234567")
        for bad in ("", "12345", "abc", None):
            self.assertEqual(core.e164(bad), "")

    def test_add_dedupe_and_validation(self):
        a = core.sms_add("500600700", "Hej", key="t:1")
        self.assertIsNotNone(a)
        self.assertIsNone(core.sms_add("500600700", "Hej", key="t:1"))
        self.assertEqual(core.sms_due()[0]["phone"], "+48500600700")
        self.assertUserError(lambda: core.sms_add("123", "x"), "numer")
        self.assertUserError(lambda: core.sms_add("500600700", "  "), "Pusta")
        self.assertUserError(lambda: core.sms_add("500600700", "x" * 1001), "długa")

    def test_sent_and_failed(self):
        a = core.sms_add("500600700", "a")
        b = core.sms_add("500600701", "b")
        core.sms_sent(a, "gw1")
        core.sms_failed(b, "HTTP 500")
        self.assertEqual([r["id"] for r in core.sms_due()], [b])
        core.sms_failed(b, "HTTP 400", permanent=True)
        self.assertEqual(core.sms_due(), [])

    def test_driver_by_phone_and_inbox_store(self):
        core.ex("UPDATE drivers SET phone='+48 500 600 700' WHERE id=?", (self.jan,))
        core.ex("UPDATE drivers SET phone='511222333' WHERE id IN (?,?)", (self.ola, self.piotr))  # ten sam numer u dwóch
        self.assertEqual(core.driver_by_phone("500600700")["name"], "Jan Test")
        self.assertIsNone(core.driver_by_phone("+48511222333"))
        items = [{"key": "1|+48500600700|t1", "phone": "+48500600700", "text": "Jutro nie mogę", "received_at": "t1"},
                 {"key": "2|+48999888777|t2", "phone": "+48999888777", "text": "?", "received_at": "t2"}]
        new = core.sms_in_store(items)
        self.assertEqual([(n["driver"] or {}).get("name") for n in new], ["Jan Test", None])
        self.assertEqual(core.sms_in_store(items), [])
        self.assertEqual(self.count("sms_in"), 2)


class FakePhone(BaseHTTPRequestHandler):
    """Udaje aplikację SMS Gateway (Local Server): /health, POST /message, GET /inbox; Basic auth."""
    state = None

    def log_message(self, *a):
        pass

    def _reply(self, code, body):
        raw = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _auth(self):
        ok = self.headers.get("Authorization") == "Basic " + base64.b64encode(b"sms:haslo").decode()
        if not ok:
            self._reply(401, {"message": "Unauthorized"})
        return ok

    def do_GET(self):
        if not self._auth():
            return
        if self.path.startswith("/inbox"):
            self.state["inbox_q"].append(self.path)
            return self._reply(200, self.state["inbox"])
        self._reply(200, {"status": "pass"})

    def do_POST(self):
        if not self._auth():
            return
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        code = self.state["codes"].pop(0) if self.state["codes"] else 202
        if code == 202:
            self.state["sent"].append(body)
            return self._reply(202, {"id": body["id"], "state": "Pending"})
        self._reply(code, {"message": "błąd %d" % code})


@unittest.skipIf(db is None, "brak bibliotek bota (uruchom testy z .venv)")
class SmsBotTest(FleetTest):
    def setUp(self):
        super().setUp()
        self.main_db = core.DBX
        db.configure({"mode": "local"}, Path(core.DB))
        FakePhone.state = {"sent": [], "codes": [], "inbox": [], "inbox_q": []}
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), FakePhone)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        url = "http://127.0.0.1:%d" % self.srv.server_address[1]
        self.cfg = SimpleNamespace(office_chat_id=OFFICE, group_lang="pl", sms_url=url, sms_user="sms", sms_password="haslo")
        self.gw = sms.from_config(self.cfg)

    def tearDown(self):
        self.srv.shutdown()
        self.srv.server_close()
        bot_db = core.DBX
        if bot_db is not self.main_db and hasattr(bot_db, "conn"):
            db.POOL.submit(bot_db.close).result()
        core.DBX = self.main_db
        super().tearDown()

    def call(self, fn, *a):
        return asyncio.run(db.call(fn, *a))

    def test_send_ok_with_our_id(self):
        sid = self.call(core.sms_add, "500600700", "Zaległość 50 zł", "k1")
        self.assertEqual(asyncio.run(sms.send_due(self.gw, self.cfg)), (1, 0, True))
        self.assertEqual(FakePhone.state["sent"], [{"id": "lf-%d" % sid, "textMessage": {"text": "Zaległość 50 zł"},
                                                    "phoneNumbers": ["+48500600700"]}])
        self.assertEqual(self.call(core.sms_due), [])
        self.assertEqual(asyncio.run(sms.send_due(self.gw, self.cfg)), (0, 0, True))  # drugi raz nic

    def test_duplicate_409_counts_as_sent(self):
        self.call(core.sms_add, "500600700", "a")
        FakePhone.state["codes"] = [409]
        self.assertEqual(asyncio.run(sms.send_due(self.gw, self.cfg)), (1, 0, True))
        self.assertEqual(self.call(core.sms_due), [])

    def test_bad_request_is_final_and_office_told(self):
        sid = self.call(core.sms_add, "500600700", "a")
        FakePhone.state["codes"] = [400]
        self.assertEqual(asyncio.run(sms.send_due(self.gw, self.cfg)), (0, 1, True))
        self.assertEqual(self.call(core.sms_due), [])
        out = self.call(core.outbox_due)
        self.assertEqual(out[0]["chat_id"], OFFICE)
        self.assertIn("+48500600700", out[0]["text"])
        self.assertEqual(self.call(core.q, "SELECT failed FROM sms_out WHERE id=?", (sid,))[0]["failed"], 1)

    def test_server_error_retries(self):
        self.call(core.sms_add, "500600700", "a")
        FakePhone.state["codes"] = [500]
        asyncio.run(sms.send_due(self.gw, self.cfg))
        self.assertEqual(len(self.call(core.sms_due)), 1)  # zostaje w kolejce
        asyncio.run(sms.send_due(self.gw, self.cfg))
        self.assertEqual(self.call(core.sms_due), [])

    def test_phone_down_keeps_queue_without_counting(self):
        self.call(core.sms_add, "500600700", "a")
        down = sms.Gateway("http://127.0.0.1:1", "sms", "haslo")
        self.assertEqual(asyncio.run(sms.send_due(down, self.cfg)), (0, 0, False))
        self.assertEqual(self.call(core.sms_due)[0]["attempts"], 0)

    def test_wrong_password(self):
        self.call(core.sms_add, "500600700", "a")
        bad = sms.Gateway(self.cfg.sms_url, "sms", "zle")
        self.assertEqual(asyncio.run(sms.send_due(bad, self.cfg)), (0, 0, False))
        asyncio.run(sms.send_due(bad, self.cfg))
        self.assertEqual(len(self.call(core.sms_due)), 1)  # SMS czeka na poprawne hasło
        self.assertEqual([o["text"] for o in self.call(core.outbox_due)], ["⚠️ Telefon SMS odrzuca logowanie — sprawdź SMS_USER i SMS_PASSWORD w .env."])

    def test_inbox_first_run_then_forward(self):
        core.ex("UPDATE drivers SET phone='500600700' WHERE id=?", (self.jan,))
        FakePhone.state["inbox"] = [{"id": "a1", "type": "SMS", "sender": "+48500600700", "contentPreview": "Jutro nie mogę",
                                     "createdAt": "2026-11-11T09:00:00Z"}]
        now = dt.datetime(2026, 11, 11, 8, 0)
        self.assertEqual(asyncio.run(sms.poll_inbox(self.gw, self.cfg, now)), 0)  # punkt startu, nic nie przesyłamy
        self.assertEqual(FakePhone.state["inbox_q"], [])
        self.assertEqual(asyncio.run(sms.poll_inbox(self.gw, self.cfg)), 1)
        self.assertIn("from=2026-11-11T08%3A00%3A00", FakePhone.state["inbox_q"][0])
        self.assertEqual(asyncio.run(sms.poll_inbox(self.gw, self.cfg)), 0)  # bez duplikatów
        out = self.call(core.outbox_due)
        self.assertEqual([o["text"] for o in out], ["📩 SMS — Jan Test (+48500600700):\nJutro nie mogę"])

    def test_parse_inbox_variants(self):
        rows = sms.parse_inbox([{"id": "1", "phoneNumber": "+48500600700", "message": "x", "receivedAt": "t"},
                                {"id": "2", "sender": "", "contentPreview": "bez nadawcy"}])
        self.assertEqual([(r["phone"], r["text"]) for r in rows], [("+48500600700", "x")])

    def test_config(self):
        from fleetbot import config
        env = {"SMS_URL": "192.168.1.50:8080", "SMS_USER": "u", "SMS_PASSWORD": "p"}
        with self.assertRaises(config.ConfigError):
            config._sms(lambda k, d="": env.get(k, d))
        env["SMS_URL"] = "http://192.168.1.50:8080"
        self.assertEqual(config._sms(lambda k, d="": env.get(k, d))["sms_url"], "http://192.168.1.50:8080")
        env["SMS_PASSWORD"] = ""
        with self.assertRaises(config.ConfigError):
            config._sms(lambda k, d="": env.get(k, d))
        self.assertEqual(config._sms(lambda k, d="": ""), {})


if __name__ == "__main__":
    unittest.main()
