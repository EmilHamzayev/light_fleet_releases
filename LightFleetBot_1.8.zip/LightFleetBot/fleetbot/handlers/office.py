"""Komendy biura (administratorzy z .env i pracownicy przypięci kodem biura). Język - wybrany przez użytkownika."""
import logging

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from .. import db
from ..i18n import t

log = logging.getLogger("fleetbot.office")
router = Router()


def _zl(n):
    return ("%.2f" % (n or 0)).rstrip("0").rstrip(".").replace(".", ",") + " zł"


def _dm(s):
    return "%s.%s" % (s[8:10], s[5:7])


def status_text(d, lang="pl"):
    k, w = d["kpi"], d["week"]
    lines = [
        t(lang, "status_title"),
        t(lang, "status_cars", cars=k["cars"], busy=k["busy"], free=k["free"]),
        t(lang, "status_week", number=w["number"], mon=_dm(w["monday"]), sun=_dm(w["sunday"]), paid=k["week_paid_n"],
          n=k["week_n"], got=_zl(k["week_got"]), waiting=_zl(k["week_waiting"])),
        t(lang, "status_owners", n=k["contr_unpaid_n"], sum=_zl(k["contr_unpaid"])),
        t(lang, "status_no_docs", n=k["no_docs"]),
    ]
    if d["alerts"]:
        lines.append(t(lang, "status_alerts"))
        lines += ["• %s — %s" % (a["plate"], a["text"]) for a in d["alerts"][:10]]
        if len(d["alerts"]) > 10:
            lines.append(t(lang, "status_more", n=len(d["alerts"]) - 10))
    return "\n".join(lines)


@router.message(Command("status"))
async def status(message: Message, is_office: bool, lang: str):
    uid = message.from_user.id if message.from_user else None
    if not is_office:
        log.warning("/status bez uprawnień od %s", uid)
        return
    log.info("/status od %s", uid)
    try:
        d = await db.call(db.core.dashboard)
    except db.DbUnavailable:
        await message.answer(t(lang, "db_unavailable"))
        return
    await message.answer(status_text(d, lang))
