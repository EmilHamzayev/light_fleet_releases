"""Lista zadań bota według harmonogramu (kolejne punkty planu dopisują tu swoje zadania)."""
import asyncio
import datetime as dt
import logging
import os
from pathlib import Path

from . import db, scheduler, sheets
from .handlers import docs
from .i18n import t

log = logging.getLogger("fleetbot.jobs")


async def backup_cloud(ctx):
    """Codzienna kopia bazy z chmury do pliku (tools/backup_cloud.py), ostatnie 30 kopii."""
    cfg = ctx["cfg"]
    if cfg.db["mode"] != "cloud":
        return "pominięto (baza lokalna)"
    from tools import backup_cloud
    out = os.path.join(backup_cloud.APP_DATA, "backups", "cloud")
    path, counts = await asyncio.to_thread(backup_cloud.backup, cfg.db, out, 30)
    return "%s (%d wierszy)" % (os.path.basename(path), sum(counts.values()))


def _zl(n):
    return ("{:,.2f}".format(n or 0)).replace(",", " ").replace(".", ",") + " zł"


def _dm(iso):
    return "%s.%s" % (iso[8:10], iso[5:7])


def cash_report(lang, week, settlement, pairs, missing, doubles):
    """Tekst dla biura: suma gotówki z arkusza po miastach + kogo nie znaleziono."""
    sun = (dt.date.fromisoformat(week) + dt.timedelta(days=6)).isoformat()
    lines = [t(lang, "cash_title", mon=_dm(week), sun=_dm(sun), date=_dm(settlement))]
    by_city = {}
    for d, r in pairs:
        c = by_city.setdefault(d.get("city") or "—", [0.0, 0])
        c[0] += r.cash or 0
        c[1] += 1
    for city, (s, n) in sorted(by_city.items()):
        lines.append(t(lang, "cash_city", city=city, sum=_zl(s), n=n))
    if missing:
        lines.append(t(lang, "cash_missing", names=", ".join(d["name"] for d in missing)))
    if doubles:
        lines.append(t(lang, "cash_double", names=", ".join(d["name"] for d in doubles)))
    return "\n".join(lines)


async def sheet_cash(ctx, now=None):
    """Poniedziałek od 11:00: gotówka kierowców floty z arkusza rozliczeń (ZESTAWIENIE, kolumna GOTÓWKA).
    Arkusz uzupełnia inna osoba ok. 8-10; dopóki data rozliczenia jest stara - ponawiamy co 30 min."""
    cfg = ctx["cfg"]
    now = now or dt.datetime.now()
    if not cfg.google_key or not Path(cfg.google_key).exists():
        raise scheduler.NotYet("brak pliku klucza Google %s" % cfg.google_key, 3600)
    settlement, rows = await asyncio.to_thread(ctx.get("read_sheet", sheets.read), cfg.google_key, cfg.sheet_id, cfg.sheet_gid)
    this_monday = (now.date() - dt.timedelta(days=now.weekday())).isoformat()
    if not settlement or settlement < this_monday:
        if (now.weekday(), now.hour) >= (1, 12) and cfg.office_chat_id:  # wtorek 12:00 - uprzedzić biuro raz
            await db.call(db.core.outbox_add, cfg.office_chat_id, t(cfg.group_lang, "sheet_late", date=settlement or "?"),
                          "sheet_late:" + this_monday)
        raise scheduler.NotYet("arkusz jeszcze nie uzupełniony (rozliczenie %s)" % settlement)
    drivers = (await db.call(db.core.fleet_view))["drivers"]
    pairs, missing, doubles = sheets.match(rows, drivers, db.core.norm_name)
    res = await db.call(db.core.fleet_cash_store, settlement, [(d["id"], r.cash, r.row) for d, r in pairs])
    if cfg.office_chat_id:
        await db.call(db.core.outbox_add, cfg.office_chat_id,
                      cash_report(cfg.group_lang, res["week_start"], settlement, pairs, missing, doubles), "cash:" + res["week_start"])
    log.info("Gotówka z arkusza: tydzień %s, %d kierowców, brak %d, podwójne %d", res["week_start"], len(pairs), len(missing), len(doubles))
    return "%s: %d kierowców (nowe %d, zmienione %d), brak %d" % (res["week_start"], len(pairs), res["new"], res["changed"], len(missing))


async def doc_reminders(ctx, today=None):
    """Codziennie 10:00 (albo zaraz po starcie, jeśli bot był wyłączony): OC/przeglądy za <= 30 dni i po terminie.
    Jedna wiadomość dziennie z przyciskami "Zrobione"; przypomnienie znika po wpisaniu nowej daty."""
    cfg = ctx["cfg"]
    today = today or dt.date.today()
    if not cfg.office_chat_id:
        return "pominięto (brak OFFICE_CHAT_ID)"
    items = await db.call(db.core.doc_reminders_due)
    if not items:
        return "brak"
    lang = cfg.group_lang
    await db.call(db.core.outbox_add, cfg.office_chat_id, docs.docs_text(items, lang, today), "docs:" + today.isoformat(),
                  docs.docs_buttons(items, lang))
    return "%d terminów" % len(items)


def debt_report(lang, week, rows):
    """Tekst dla biura: kto po terminie (środa) nie oddał gotówki za tydzień."""
    sun = (dt.date.fromisoformat(week) + dt.timedelta(days=6)).isoformat()
    if not rows:
        return t(lang, "debt_none", mon=_dm(week), sun=_dm(sun))
    lines = [t(lang, "debt_title", mon=_dm(week), sun=_dm(sun), n=len(rows), sum=_zl(sum(r["balance"] for r in rows)))]
    for r in sorted(rows, key=lambda r: (r.get("city") or "", -r["balance"])):
        lines.append(t(lang, "debt_line", name=r["name"], sum=_zl(r["balance"]), city=r.get("city") or "—"))
    return "\n".join(lines)


async def cash_debts(ctx, now=None):
    """Czwartek 9:00: termin oddania gotówki za poprzedni tydzień (pon-nd) minął w środę - raport dla biura."""
    cfg = ctx["cfg"]
    now = now or dt.datetime.now()
    if not cfg.office_chat_id:
        return "pominięto (brak OFFICE_CHAT_ID)"
    week = (now.date() - dt.timedelta(days=now.weekday() + 7)).isoformat()
    view = await db.call(db.core.cash_view, week)
    if all(r["status"] == "none" for r in view["rows"]):
        return "brak danych za %s" % week
    rows = [r for r in view["rows"] if r["balance"] > db.core.CASH_EPS]
    await db.call(db.core.outbox_add, cfg.office_chat_id, debt_report(cfg.group_lang, week, rows), "cash_debt:" + week)
    return "%s: %d do oddania" % (week, len(rows))


def all_jobs():
    return [scheduler.Job("backup_cloud", scheduler.daily(3, 0), backup_cloud),
            scheduler.Job("sheet_cash", scheduler.weekly(0, 11, 0), sheet_cash),
            scheduler.Job("doc_reminders", scheduler.daily(10, 0), doc_reminders),
            scheduler.Job("cash_debts", scheduler.weekly(3, 9, 0), cash_debts)]
