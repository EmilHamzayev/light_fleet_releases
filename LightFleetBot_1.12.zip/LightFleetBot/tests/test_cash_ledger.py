"""Gotówka floty: do oddania = GOTÓWKA − faktury + saldo z poprzednich tygodni; saldo przechodzi dalej samo."""
from base import PASSWORD, FleetTest, core

W1, W2, W3 = "2026-10-19", "2026-10-26", "2026-11-02"  # poniedziałki; rozliczenia w poniedziałek po tygodniu


class CashLedgerTest(FleetTest):
    def setUp(self):
        super().setUp()
        self.g = core.save_driver({"name": "Gennadii Sabadash", "kind": "fleet", "city": "Toruń"})
        self.k = core.save_driver({"name": "Jerzy Kondziela", "kind": "fleet", "city": "Grudziądz"})
        core.fleet_cash_store("2026-10-26", [(self.g, 500.0, 1), (self.k, 300.0, 2)])  # tydzień W1
        core.fleet_cash_store("2026-11-02", [(self.g, 400.0, 1), (self.k, 200.0, 2)])  # tydzień W2

    def add(self, did, week, kind, amount, date="2026-10-28", note=""):
        return core.cash_add({"driver_id": did, "week": week, "kind": kind, "amount": amount, "date": date, "note": note})

    def row(self, did, week=None):
        return next(r for r in core.cash_view(week)["rows"] if r["driver_id"] == did)

    def test_full_payment_after_invoices(self):
        self.add(self.g, W1, "invoice", 120.5)
        self.add(self.g, W1, "cash", 379.5)
        r = self.row(self.g, W1)
        self.assertEqual((r["sheet"], r["invoice"], r["carry"], r["due"], r["cash"], r["balance"], r["status"]),
                         (500.0, 120.5, 0, 379.5, 379.5, 0, "ok"))
        self.assertEqual(self.row(self.g, W2)["carry"], 0)

    def test_shortfall_moves_to_next_week(self):
        self.add(self.g, W1, "cash", 450)  # brakuje 50
        r = self.row(self.g, W1)
        self.assertEqual((r["balance"], r["status"]), (50.0, "partial"))
        r = self.row(self.g, W2)
        self.assertEqual((r["carry"], r["due"], r["status"]), (50.0, 450.0, "unpaid"))

    def test_overpayment_reduces_next_week(self):
        self.add(self.k, W1, "cash", 350)  # 50 za dużo
        self.assertEqual((self.row(self.k, W1)["balance"], self.row(self.k, W1)["status"]), (-50.0, "over"))
        r = self.row(self.k, W2)
        self.assertEqual((r["carry"], r["due"]), (-50.0, 150.0))

    def test_partial_payments_in_parts(self):
        self.add(self.g, W1, "cash", 200, "2026-10-28")
        self.add(self.g, W1, "cash", 300, "2026-10-29", "reszta")
        r = self.row(self.g, W1)
        self.assertEqual((r["cash"], r["balance"], len(r["entries"])), (500.0, 0, 2))
        self.assertEqual(r["entries"][1]["note"], "reszta")

    def test_debt_chain_over_three_weeks(self):
        self.add(self.g, W1, "cash", 400)  # dług 100
        self.add(self.g, W2, "invoice", 50)  # 400 − 50 + 100 = 450
        self.add(self.g, W2, "cash", 300)  # dług 150
        self.assertEqual(self.row(self.g, W2)["balance"], 150.0)
        r = self.row(self.g, W3)  # tydzień bez arkusza - nadal dług
        self.assertEqual((r["sheet"], r["carry"], r["due"], r["status"]), (None, 150.0, 150.0, "unpaid"))
        self.add(self.g, W3, "cash", 150)
        self.assertEqual(self.row(self.g, W3)["status"], "ok")

    def test_default_week_totals_and_city(self):
        v = core.cash_view()
        self.assertEqual(v["week"], W2)
        self.assertEqual(v["weeks"], [W2, W1])
        self.assertEqual((v["total"]["sheet"], v["total"]["debt"], v["total"]["unpaid"]), (600.0, 1400.0, 2))  # W1 nic nie oddane: 800 + 600
        self.assertEqual([r["name"] for r in core.cash_view(W2, "Toruń")["rows"]], ["Gennadii Sabadash"])
        self.assertEqual(v["cities"], ["Grudziądz", "Toruń"])

    def test_week_any_day_means_its_monday(self):
        self.add(self.g, "2026-10-22", "cash", 10)  # czwartek -> tydzień W1
        self.assertEqual(self.row(self.g, W1)["cash"], 10.0)
        self.assertEqual(self.row(self.g, "2026-10-25")["week"], W1)

    def test_archived_driver_with_debt_stays(self):
        self.add(self.k, W1, "cash", 300)
        core.ex("UPDATE drivers SET active=0 WHERE id=?", (self.k,))
        r = self.row(self.k, W2)
        self.assertEqual((r["active"], r["balance"]), (False, 200.0))
        self.assertEqual([d["name"] for d in core.cash_debtors(W2)], ["Gennadii Sabadash", "Jerzy Kondziela"])

    def test_rent_driver_without_data_not_listed(self):
        self.assertNotIn(self.jan, [r["driver_id"] for r in core.cash_view(W2)["rows"]])

    def test_history(self):
        self.add(self.g, W1, "cash", 450)
        h = core.cash_history(self.g)
        self.assertEqual([(x["week"], x["carry"], x["balance"]) for x in h], [(W2, 50.0, 450.0), (W1, 0, 50.0)])

    def test_validation(self):
        self.assertUserError(lambda: self.add(self.g, W1, "inne", 10), "rodzaj")
        self.assertUserError(lambda: self.add(self.g, W1, "cash", 0), "kwot")
        self.assertUserError(lambda: self.add(self.g, W1, "cash", "abc"), "kwot")
        self.assertUserError(lambda: self.add(self.g, "", "cash", 10), "tydzień")
        self.assertUserError(lambda: self.add(self.g, W1, "cash", 10, "2026-13-01"), "data")
        self.assertUserError(lambda: self.add(99999, W1, "cash", 10), "nie istnieje")
        self.assertEqual(self.count("cash_entries"), 0)

    def test_delete_wrong_entry_and_driver(self):
        e = self.add(self.g, W1, "cash", 999)
        self.assertIn("Wpłata 999.00 zł", core.delete_info("cash_entries", e)[0])
        core.delete_record("cash_entries", e, PASSWORD)
        self.assertEqual(self.row(self.g, W1)["cash"], 0)
        self.add(self.g, W1, "cash", 5)
        core.delete_record("drivers", self.g, PASSWORD)
        self.assertEqual(self.count("cash_entries"), 0)

    def test_start_week_ignores_older(self):
        self.assertEqual(core.set_cash_start("2026-10-28"), W2)  # dowolny dzień -> poniedziałek
        r = self.row(self.g, W2)
        self.assertEqual((r["carry"], r["due"]), (0, 400.0))
        self.assertEqual(core.cash_view()["weeks"], [W2])
        self.assertEqual([x["week"] for x in core.cash_history(self.g)], [W2])
        self.assertUserError(lambda: core.set_cash_start(""), "tydzień")

    def test_empty_database(self):
        core.ex("DELETE FROM fleet_cash")
        v = core.cash_view()
        self.assertIsNone(v["week"])
        self.assertEqual(v["weeks"], [])


try:
    import asyncio
    import datetime as dt
    import unittest
    from pathlib import Path
    from types import SimpleNamespace
    from fleetbot import db, jobs
except ImportError:  # biblioteki bota są w .venv
    db = None


@unittest.skipIf(db is None, "brak bibliotek bota (uruchom testy z .venv)")
class CashDebtJobTest(CashLedgerTest):
    def setUp(self):
        super().setUp()
        self.main_db = core.DBX
        db.configure({"mode": "local"}, Path(core.DB))
        self.ctx = {"cfg": SimpleNamespace(office_chat_id=6936017050, group_lang="pl")}

    def tearDown(self):
        bot_db = core.DBX
        if bot_db is not self.main_db and hasattr(bot_db, "conn"):
            db.POOL.submit(bot_db.close).result()
        core.DBX = self.main_db
        super().tearDown()

    def run_job(self, now):
        return asyncio.run(jobs.cash_debts(self.ctx, now))

    def test_thursday_report_previous_week(self):
        asyncio.run(db.call(core.cash_add, {"driver_id": self.g, "week": W1, "kind": "cash", "amount": 500}))
        asyncio.run(db.call(core.cash_add, {"driver_id": self.k, "week": W1, "kind": "cash", "amount": 250.5}))
        self.assertEqual(self.run_job(dt.datetime(2026, 10, 29, 9, 0)), "%s: 1 do oddania" % W1)
        self.run_job(dt.datetime(2026, 10, 29, 15, 0))  # drugi raz - bez duplikatu
        out = asyncio.run(db.call(core.outbox_due))
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0]["text"], "💵 Gotówka 19.10–25.10: nie rozliczyło się 1, razem 49,50 zł\n"
                                         "• Jerzy Kondziela — 49,50 zł (Grudziądz)")

    def test_all_paid_and_no_data(self):
        for did, amount in ((self.g, 500), (self.k, 300)):
            asyncio.run(db.call(core.cash_add, {"driver_id": did, "week": W1, "kind": "cash", "amount": amount}))
        self.run_job(dt.datetime(2026, 10, 29, 9, 0))
        self.assertEqual(asyncio.run(db.call(core.outbox_due))[0]["text"], "✅ Gotówka 19.10–25.10: wszyscy rozliczeni.")
        self.assertTrue(self.run_job(dt.datetime(2026, 10, 15, 9, 0)).startswith("brak danych"))
        self.assertIn("cash_debts", [j.name for j in jobs.all_jobs()])
