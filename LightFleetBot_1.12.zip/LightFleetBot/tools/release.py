"""Wydanie wersji przez internet: instalator programu + archiwum bota -> repozytorium light_fleet_releases.

Użycie (po zbudowaniu instalatora dla bieżącej VERSION):
  python tools/release.py --notes "Co nowego" [--no-push]
Archiwum bota NIE zawiera sekretów (.env, klucz Google) - repozytorium jest publiczne.
"""
import argparse
import base64
import datetime as dt
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import fleet_core as core  # noqa: E402
import updates  # noqa: E402

REPO_URL = "https://github.com/EmilHamzayev/light_fleet_releases.git"
REPO_DIR = ROOT.parent / "light_fleet_releases"
KEY_FILE = Path.home() / ".lightfleet" / "release_ed25519.pem"
BOT_FILES = ["fleet_core.py", "updates.py", "requirements-bot.txt", ".env.example"]
BOT_DIRS = ["fleetbot", "tools", "tests", "service"]
SKIP = {"__pycache__", "nssm.exe", "test_import_app.py"}
SECRET = (".env", "google_service_account.json", ".pem", ".db")


def bot_zip(version, out_dir):
    """Archiwum bota (folder LightFleetBot/ w środku), bez sekretów i baz."""
    path = Path(out_dir) / ("LightFleetBot_%s.zip" % version)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for f in BOT_FILES:
            z.write(ROOT / f, "LightFleetBot/" + f)
        for d in BOT_DIRS:
            for p in sorted((ROOT / d).rglob("*")):
                if p.is_file() and not (SKIP & set(p.parts)) and p.name not in SKIP and not p.name.endswith(".zip"):
                    z.write(p, "LightFleetBot/" + p.relative_to(ROOT).as_posix())
        names = z.namelist()
    bad = [n for n in names if n.endswith(SECRET) and not n.endswith(".env.example")]
    if bad:
        path.unlink()
        raise SystemExit("W archiwum bota są sekrety: %s" % bad)
    return path


def sign(data):
    from cryptography.hazmat.primitives import serialization
    key = serialization.load_pem_private_key(KEY_FILE.read_bytes(), None)
    sig = base64.b64encode(key.sign(data)).decode()
    updates.verify(data, sig)  # ten sam klucz co w programie?
    return sig


def git(*args):
    subprocess.run(["git", "-C", str(REPO_DIR)] + list(args), check=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--notes", default="")
    ap.add_argument("--no-push", action="store_true")
    a = ap.parse_args()
    v = core.VERSION
    installer = ROOT / "dist" / ("LIGHT_Fleet_Manager_Setup_%s.exe" % v)
    if not installer.exists():
        raise SystemExit("Brak instalatora %s - najpierw zbuduj program i instalator." % installer.name)
    if not REPO_DIR.exists():
        subprocess.run(["git", "clone", REPO_URL, str(REPO_DIR)], check=True)
    zip_path = bot_zip(v, ROOT / "dist")
    for old in list(REPO_DIR.glob("*.exe")) + list(REPO_DIR.glob("*.zip")):
        old.unlink()  # w repozytorium tylko ostatnia wersja
    shutil.copy2(installer, REPO_DIR / installer.name)
    shutil.copy2(zip_path, REPO_DIR / zip_path.name)
    shutil.copy2(ROOT / "service" / "update_bot.ps1", REPO_DIR / "update_bot.ps1")  # ręczna aktualizacja bota
    m = {"version": v, "date": dt.date.today().isoformat(), "notes": a.notes,
         "program": {"file": installer.name, "sha256": updates.sha256_file(installer), "size": installer.stat().st_size},
         "bot": {"file": zip_path.name, "sha256": updates.sha256_file(zip_path), "size": zip_path.stat().st_size}}
    data = (json.dumps(m, ensure_ascii=False, indent=1) + "\n").encode("utf-8")
    (REPO_DIR / "version.json").write_bytes(data)
    (REPO_DIR / "version.json.sig").write_text(sign(data) + "\n", encoding="ascii")
    (REPO_DIR / "README.md").write_text("# LIGHT Fleet Manager — aktualizacje\n\nGotowe pliki dla automatycznych aktualizacji "
                                        "programu i bota. Kod jest w prywatnym repozytorium.\n", encoding="utf-8")
    git("add", "-A")
    git("commit", "-m", "Wersja %s" % v)
    if not a.no_push:
        git("push", "-u", "origin", "HEAD:main")
    print("Wydano %s: %s, %s" % (v, installer.name, zip_path.name))


if __name__ == "__main__":
    main()
