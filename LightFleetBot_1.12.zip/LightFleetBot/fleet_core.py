"""Fleet Manager: baza danych (lokalna, własny serwer albo Turso) i logika floty, bez interfejsu."""
import base64
import datetime as dt
import hashlib
import http.client
import json
import os
import re
import shutil
import sqlite3
import sys
import threading
import urllib.parse

VERSION = "1.12"
BASE = os.path.dirname(sys.executable if getattr(sys, "frozen", False) else os.path.abspath(__file__))
APP_DIR_NAME = "LIGHT Fleet Manager Demo" if os.path.isdir(os.path.join(BASE, "demo")) else "LIGHT Fleet Manager"
CLOUD_URL = "libsql://light-fleet-lightpartner.aws-eu-north-1.turso.io"  # domyślna baza w chmurze (bez tokenu)


def _data_dir():
    """Folder data obok programu, jeśli już istnieje (dotychczasowe instalacje); po instalacji - w profilu użytkownika."""
    here = os.path.join(BASE, "data")
    if os.path.isdir(here):
        return here
    root = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(root, APP_DIR_NAME, "data")


DATA = _data_dir()
BACKUPS = os.path.join(DATA, "backups")
DB = os.path.join(DATA, "fleet.db")
CHECK_EVERY_MS = 60 * 60 * 1000  # sprawdzanie oleju i dokumentów co godzinę, gdy program jest otwarty
AUTO_REFRESH_MS = 60 * 1000  # odświeżanie wspólnej bazy (w tle)
CONNECT_TIMEOUT, READ_TIMEOUT = 5, 20  # sek.: okno nie może wisieć minutami bez sieci

os.makedirs(BACKUPS, exist_ok=True)
SEED_CSV = "flota_import.csv"  # dane startowe: plik obok programu (nie w kodzie)
MONTHS = ["styczeń", "luty", "marzec", "kwiecień", "maj", "czerwiec", "lipiec", "sierpień", "wrzesień", "październik", "listopad", "grudzień"]


SCHEMA = """
CREATE TABLE IF NOT EXISTS contractors(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, contact TEXT, notes TEXT, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS drivers(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, phone TEXT, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS cars(id INTEGER PRIMARY KEY, plate TEXT UNIQUE NOT NULL, model TEXT,
    contractor_id INTEGER REFERENCES contractors(id), mileage INTEGER DEFAULT 0, oil_last_km INTEGER DEFAULT 0,
    oil_interval INTEGER DEFAULT 10000, oil_warn_km INTEGER DEFAULT 1000, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS assignments(id INTEGER PRIMARY KEY, car_id INTEGER NOT NULL REFERENCES cars(id),
    driver_id INTEGER NOT NULL REFERENCES drivers(id), start_date TEXT NOT NULL, end_date TEXT);
CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY, car_id INTEGER NOT NULL REFERENCES cars(id), created_at TEXT NOT NULL, text TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS mileage_log(id INTEGER PRIMARY KEY, car_id INTEGER NOT NULL REFERENCES cars(id), created_at TEXT NOT NULL, km INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY, contractor_id INTEGER NOT NULL REFERENCES contractors(id),
    period TEXT NOT NULL, amount REAL, paid_date TEXT, note TEXT);
CREATE TABLE IF NOT EXISTS weekly(id INTEGER PRIMARY KEY, car_id INTEGER NOT NULL REFERENCES cars(id), week_start TEXT NOT NULL,
    paid INTEGER DEFAULT 0, paid_at TEXT, comment TEXT, km INTEGER, UNIQUE(car_id, week_start));
CREATE TABLE IF NOT EXISTS repairs(id INTEGER PRIMARY KEY, car_id INTEGER NOT NULL REFERENCES cars(id), created_at TEXT NOT NULL,
    text TEXT NOT NULL, done_at TEXT, cost REAL);
CREATE TABLE IF NOT EXISTS photos(id INTEGER PRIMARY KEY, car_id INTEGER NOT NULL, name TEXT NOT NULL, data TEXT NOT NULL,
    UNIQUE(car_id, name));
CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS tg_users(telegram_id INTEGER PRIMARY KEY, lang TEXT, created_at TEXT NOT NULL, updated_at TEXT);
CREATE TABLE IF NOT EXISTS outbox(id INTEGER PRIMARY KEY, dedupe_key TEXT UNIQUE, chat_id INTEGER NOT NULL, text TEXT NOT NULL,
    buttons TEXT, created_at TEXT NOT NULL, send_after TEXT, sent_at TEXT, attempts INTEGER DEFAULT 0, last_error TEXT,
    failed INTEGER DEFAULT 0, message_id INTEGER);
CREATE INDEX IF NOT EXISTS ix_outbox_pending ON outbox(sent_at, failed);
CREATE TABLE IF NOT EXISTS job_runs(name TEXT NOT NULL, period TEXT NOT NULL, done_at TEXT NOT NULL, result TEXT,
    PRIMARY KEY(name, period));
CREATE TABLE IF NOT EXISTS bot_lock(name TEXT PRIMARY KEY, owner TEXT, heartbeat_at TEXT);
CREATE TABLE IF NOT EXISTS fleet_crews(id INTEGER PRIMARY KEY, car_id INTEGER NOT NULL REFERENCES cars(id),
    driver_id INTEGER NOT NULL REFERENCES drivers(id), shift TEXT NOT NULL CHECK(shift IN ('day','night')),
    start_date TEXT NOT NULL, end_date TEXT);
CREATE INDEX IF NOT EXISTS ix_crews_car ON fleet_crews(car_id, shift);
CREATE INDEX IF NOT EXISTS ix_crews_drv ON fleet_crews(driver_id);
CREATE TABLE IF NOT EXISTS fleet_cash(id INTEGER PRIMARY KEY, driver_id INTEGER NOT NULL REFERENCES drivers(id),
    week_start TEXT NOT NULL, settlement_date TEXT, cash_sheet REAL, sheet_row INTEGER, read_at TEXT NOT NULL,
    UNIQUE(driver_id, week_start));
CREATE TABLE IF NOT EXISTS cash_entries(id INTEGER PRIMARY KEY, driver_id INTEGER NOT NULL REFERENCES drivers(id),
    week_start TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('cash','invoice')), amount REAL NOT NULL, entry_date TEXT NOT NULL,
    note TEXT, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_cash_entries ON cash_entries(driver_id, week_start);
CREATE TABLE IF NOT EXISTS doc_reminders(id INTEGER PRIMARY KEY, car_id INTEGER NOT NULL REFERENCES cars(id), doc TEXT NOT NULL,
    old_until TEXT, new_until TEXT NOT NULL, done_by INTEGER, done_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS link_codes(id INTEGER PRIMARY KEY, code_hash TEXT UNIQUE NOT NULL, kind TEXT NOT NULL,
    driver_id INTEGER, created_by INTEGER, created_at TEXT NOT NULL, expires_at TEXT NOT NULL, used_at TEXT, used_by INTEGER);
CREATE INDEX IF NOT EXISTS ix_asg_car ON assignments(car_id, end_date);
CREATE INDEX IF NOT EXISTS ix_asg_drv ON assignments(driver_id, end_date);
CREATE INDEX IF NOT EXISTS ix_comments_car ON comments(car_id);
CREATE INDEX IF NOT EXISTS ix_mlog_car ON mileage_log(car_id);
CREATE INDEX IF NOT EXISTS ix_repairs_car ON repairs(car_id, done_at);
CREATE INDEX IF NOT EXISTS ix_pay_contr ON payments(contractor_id);
"""


def today():
    return dt.date.today().isoformat()


def now():
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M")


def num(s, default=None):
    try:
        return int(float(str(s).replace(",", ".").replace(" ", "")))
    except ValueError:
        return default


def flt(s):
    try:
        return float(str(s).replace(",", ".").replace(" ", ""))
    except ValueError:
        return None


def norm_plate(s):
    """Jeden zapis numeru wszędzie (import i ręcznie): wielkie litery, bez spacji."""
    return re.sub(r"\s+", "", s or "").upper()


def valid_date(s):
    try:
        dt.date.fromisoformat(s)
        return True
    except (TypeError, ValueError):
        return False


# ---------------------------------------------------------------- baza danych (lokalna albo wspólna na serwerze)
CONFIG = os.path.join(DATA, "config.json")
PHOTOS = os.path.join(DATA, "photos")
MIGRATIONS = [("cars", "rent_week", "REAL"), ("drivers", "pay_type", "TEXT"), ("assignments", "pay_type", "TEXT"),
              ("cars", "oc_until", "TEXT"), ("cars", "przeglad_until", "TEXT"), ("cars", "owner_rate", "REAL"),
              ("cars", "year", "INTEGER"), ("cars", "fuel", "TEXT"), ("cars", "gearbox", "TEXT"), ("contractors", "nip", "TEXT"),
              ("weekly", "amount", "REAL"), ("payments", "paid_amount", "REAL"),
              ("tg_users", "role", "TEXT"), ("tg_users", "driver_id", "INTEGER"),
              ("cars", "kind", "TEXT NOT NULL DEFAULT 'rent'"), ("drivers", "kind", "TEXT NOT NULL DEFAULT 'rent'"),
              ("cars", "ac_until", "TEXT"), ("cars", "city", "TEXT"), ("drivers", "city", "TEXT"), ("drivers", "sheet_key", "TEXT")]
CITIES = ("Toruń", "Grudziądz")  # miasta floty
SHEET_CITY = {"TRN": "Toruń", "GRDZ": "Grudziądz"}  # kod z kolumny MIASTO w arkuszu rozliczeń
KINDS = ("rent", "fleet")  # wynajem / flota (2 kierowców na zmiany dzień-noc, 50/50)
SHIFTS = ("day", "night")


def load_config():
    try:
        with open(CONFIG, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def save_config(cfg):
    with open(CONFIG, "w", encoding="utf-8") as fh:
        json.dump(cfg, fh, ensure_ascii=False, indent=1)


def apply_migrations(conn, migrations):
    for tbl, col, decl in migrations:
        if col not in [c[1] for c in conn.execute("PRAGMA table_info(%s)" % tbl)]:
            conn.execute("ALTER TABLE %s ADD COLUMN %s %s" % (tbl, col, decl))
    conn.commit()


def photo_stamp(path):
    return "%s_%s" % (dt.datetime.now().strftime("%Y%m%d_%H%M%S"), os.path.basename(path))


class Row:
    """Wiersz wyniku: dostęp po nazwie albo numerze (jak sqlite3.Row)."""
    __slots__ = ("k", "v")

    def __init__(self, keys, vals):
        self.k, self.v = keys, vals

    def __getitem__(self, i):
        return self.v[i] if isinstance(i, int) else self.v[self.k.index(i)]

    def __iter__(self):
        return iter(self.v)

    def __len__(self):
        return len(self.v)

    def keys(self):
        return list(self.k)


class LocalDB:
    remote = False

    def __init__(self, backup=True):
        os.makedirs(BACKUPS, exist_ok=True)
        if backup and os.path.exists(DB):
            b = os.path.join(BACKUPS, "fleet_%s.db" % today())
            if not os.path.exists(b):
                shutil.copy2(DB, b)
        self.conn = sqlite3.connect(DB, timeout=10)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys=ON")

    def clone(self):
        """Osobne połączenie dla wątku w tle."""
        return LocalDB(backup=False)

    def close(self):
        self.conn.close()

    def init(self, schema, migrations):
        self.conn.executescript(schema)
        apply_migrations(self.conn, migrations)

    def query(self, sql, args=()):
        return self.conn.execute(sql, args).fetchall()

    def execute(self, sql, args=()):
        cur = self.conn.execute(sql, args)
        self.conn.commit()
        return cur.lastrowid

    def batch(self, stmts):
        return [self.conn.execute(sql, args).fetchall() for sql, args in stmts]

    def tx(self, stmts):
        """Wszystko albo nic. Zwraca lastrowid każdego polecenia."""
        with self.conn:
            return [self.conn.execute(sql, args).lastrowid for sql, args in stmts]

    def _dir(self, car_id):
        d = os.path.join(PHOTOS, str(car_id))
        os.makedirs(d, exist_ok=True)
        return d

    def photo_list(self, car_id):
        return sorted(os.listdir(self._dir(car_id)))

    def photo_put(self, car_id, path, name=None):
        name = photo_stamp(path)
        shutil.copy2(path, os.path.join(self._dir(car_id), name))
        return name

    def photo_get(self, car_id, name):
        return os.path.join(self._dir(car_id), name)


class HttpConn:
    """Jedno połączenie keep-alive. Krótkie limity czasu; ponowna próba tylko,
    gdy padło stare (uśpione) połączenie, a nie przy braku sieci."""
    u = None
    _c = None

    def close(self):
        try:
            if self._c is not None:
                self._c.close()
        finally:
            self._c = None

    def _send(self, method, path, body, hdr):
        for attempt in (0, 1):
            fresh = self._c is None
            try:
                if fresh:
                    cls = http.client.HTTPSConnection if self.u.scheme == "https" else http.client.HTTPConnection
                    self._c = cls(self.u.hostname, self.u.port, timeout=CONNECT_TIMEOUT)
                    self._c.connect()
                    self._c.sock.settimeout(READ_TIMEOUT)
                self._c.request(method, path, body=body, headers=hdr)
                resp = self._c.getresponse()
                return resp.status, resp.read()
            except (OSError, http.client.HTTPException) as e:
                self.close()
                if fresh or attempt:
                    raise ConnectionError(str(e))

    def _cached(self, car_id, name):
        d = os.path.join(self.tmp, str(car_id))
        os.makedirs(d, exist_ok=True)
        return os.path.join(d, os.path.basename(name))


class RemoteDB(HttpConn):
    """Wspólna baza: program rozmawia z fleet_server.py (HTTP + token)."""
    remote = True

    def __init__(self, cfg):
        u = urllib.parse.urlparse(cfg["server"].strip())
        if u.scheme not in ("http", "https") or not u.hostname:
            raise ConnectionError("Nieprawidłowy adres serwera: %s" % cfg["server"])
        self.cfg, self.u, self.base, self.token, self._c = cfg, u, u.path.rstrip("/"), cfg.get("token", ""), None
        self.v2 = True  # serwer zna "batch"/"tx" (stary serwer - zapytania po kolei)
        self.tmp = os.path.join(DATA, "tmp")
        os.makedirs(self.tmp, exist_ok=True)

    def clone(self):
        return RemoteDB(self.cfg)

    def _call(self, path, payload=None, raw=None, ctype="application/json"):
        body = raw if raw is not None else (json.dumps(payload).encode("utf-8") if payload is not None else None)
        hdr = {"X-Token": self.token}
        if body is not None:
            hdr["Content-Type"] = ctype
        status, data = self._send("POST" if body is not None else "GET", self.base + path, body, hdr)
        if status >= 400:
            try:
                msg = json.loads(data.decode("utf-8"))
            except ValueError:
                msg = {"error": data.decode("utf-8", "replace")}
            if status == 401:
                raise ConnectionError("Nieprawidłowy token.")
            if msg.get("kind") == "integrity":
                raise sqlite3.IntegrityError(msg.get("error"))
            raise RuntimeError("%s: %s" % (status, msg.get("error")))
        return data

    def _api(self, payload):
        return json.loads(self._call("/api", payload).decode("utf-8"))

    def init(self, schema, migrations):
        self._api({"op": "init", "schema": schema, "migrations": migrations})

    def query(self, sql, args=()):
        r = self._api({"op": "query", "sql": sql, "args": list(args)})
        return [Row(r["cols"], row) for row in r["rows"]]

    def execute(self, sql, args=()):
        return self._api({"op": "exec", "sql": sql, "args": list(args)})["lastrowid"]

    def _v2(self, payload):
        """Nowa operacja serwera; None = stary serwer jej nie zna."""
        if not self.v2:
            return None
        try:
            return self._api(payload)
        except RuntimeError as e:
            if "unknown op" not in str(e):
                raise
            self.v2 = False
            return None

    def batch(self, stmts):
        r = self._v2({"op": "batch", "stmts": [[sql, list(args)] for sql, args in stmts]})
        if r is None:
            return [self.query(sql, args) for sql, args in stmts]
        return [[Row(x["cols"], row) for row in x["rows"]] for x in r["results"]]

    def tx(self, stmts):
        r = self._v2({"op": "tx", "stmts": [[sql, list(args)] for sql, args in stmts]})
        if r is None:
            return [self.execute(sql, args) for sql, args in stmts]
        return r["lastrowids"]

    def photo_list(self, car_id):
        return json.loads(self._call("/photos?car=%d" % int(car_id)).decode("utf-8"))

    def photo_put(self, car_id, path, name=None):
        name, raw = prepare_photo(path)
        self._call("/photo?car=%d&name=%s" % (int(car_id), urllib.parse.quote(name)), raw=raw, ctype="application/octet-stream")
        return name

    def photo_get(self, car_id, name):
        path = self._cached(car_id, name)
        if not os.path.isfile(path) or not os.path.getsize(path):
            raw = self._call("/photo?car=%d&name=%s" % (int(car_id), urllib.parse.quote(name)))
            with open(path, "wb") as fh:
                fh.write(raw)
        return path


def prepare_photo(path):
    """Zmniejsza zdjęcie (max 1600 px, JPEG), żeby baza w chmurze nie puchła. Bez Pillow - oryginał."""
    name = photo_stamp(path)
    try:
        from PIL import Image, ImageOps
        import io
        im = ImageOps.exif_transpose(Image.open(path)).convert("RGB")
        im.thumbnail((1600, 1600))
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=82, optimize=True)
        return os.path.splitext(name)[0] + ".jpg", buf.getvalue()
    except Exception:
        with open(path, "rb") as fh:
            raw = fh.read()
        if len(raw) > 6 * 1024 * 1024:
            raise ValueError("Zdjęcie jest za duże.")
        return name, raw


def _enc(v):
    if v is None:
        return {"type": "null"}
    if isinstance(v, bool) or isinstance(v, int):
        return {"type": "integer", "value": str(int(v))}
    if isinstance(v, float):
        return {"type": "float", "value": v}
    return {"type": "text", "value": str(v)}


def _dec(v):
    t = v.get("type")
    if t == "null":
        return None
    if t == "integer":
        return int(v["value"])
    if t == "float":
        return float(v["value"])
    if t == "blob":
        return base64.b64decode(v["base64"])
    return v.get("value")


def _turso_error(err):
    msg, code = err.get("message", ""), str(err.get("code", ""))
    if "CONSTRAINT" in code.upper() or "constraint failed" in msg.lower():
        return sqlite3.IntegrityError(msg)
    return RuntimeError(msg)


def _rows(res):
    cols = [c["name"] for c in res["cols"]]
    return [Row(cols, [_dec(v) for v in row]) for row in res["rows"]]


class TursoDB(HttpConn):
    """Baza w chmurze (Turso = SQLite w internecie). Wspólna dla wszystkich komputerów."""
    remote = True
    cloud = True

    def __init__(self, cfg):
        url = (cfg.get("server") or "").strip().replace("libsql://", "https://").replace("turso://", "https://").rstrip("/")
        u = urllib.parse.urlparse(url)
        if u.scheme != "https" or not u.hostname:
            raise ConnectionError("Nieprawidłowy adres bazy.")
        self.cfg, self.u, self.token, self._c = cfg, u, (cfg.get("token") or "").strip(), None
        self.tmp = os.path.join(DATA, "tmp")
        os.makedirs(self.tmp, exist_ok=True)

    def clone(self):
        return TursoDB(self.cfg)

    def _post(self, body):
        hdr = {"Authorization": "Bearer " + self.token, "Content-Type": "application/json"}
        status, data = self._send("POST", "/v2/pipeline", body, hdr)
        if status in (401, 403):
            raise ConnectionError("Nieprawidłowy token.")
        if status >= 400:
            raise RuntimeError("Błąd bazy w chmurze (%d): %s" % (status, data.decode("utf-8", "replace")[:300]))
        return json.loads(data.decode("utf-8"))

    def pipeline(self, stmts):
        reqs = [{"type": "execute", "stmt": {"sql": sql, "args": [_enc(a) for a in args]}} for sql, args in stmts]
        reqs.append({"type": "close"})
        out = self._post(json.dumps({"requests": reqs}).encode("utf-8"))
        results = []
        for r in out["results"][:len(stmts)]:
            if r.get("type") == "error":
                raise _turso_error(r.get("error", {}))
            results.append(r["response"]["result"])
        return results

    def init(self, schema, migrations):
        ddl = [(s.strip(), ()) for s in schema.split(";") if s.strip()]
        tables = sorted({t for t, _c, _d in migrations})
        res = self.pipeline(ddl + [("PRAGMA table_info(%s)" % t, ()) for t in tables])[len(ddl):]
        have = {t: {r["name"] for r in _rows(x)} for t, x in zip(tables, res)}
        alter = [("ALTER TABLE %s ADD COLUMN %s %s" % (t, c, d), ()) for t, c, d in migrations if c not in have[t]]
        if alter:
            self.pipeline(alter)

    def query(self, sql, args=()):
        return _rows(self.pipeline([(sql, args)])[0])

    def execute(self, sql, args=()):
        res = self.pipeline([(sql, args)])[0]
        return int(res["last_insert_rowid"]) if res.get("last_insert_rowid") is not None else None

    def batch(self, stmts):
        return [_rows(x) for x in self.pipeline(stmts)]

    def tx(self, stmts):
        """Transakcja w jednym żądaniu (Hrana batch): BEGIN, polecenia po kolei, COMMIT albo ROLLBACK."""
        n = len(stmts)
        steps = [{"stmt": {"sql": "BEGIN"}}]
        for i, (sql, args) in enumerate(stmts):
            steps.append({"condition": {"type": "ok", "step": i},
                          "stmt": {"sql": sql, "args": [_enc(a) for a in args]}})
        steps.append({"condition": {"type": "ok", "step": n}, "stmt": {"sql": "COMMIT"}})
        steps.append({"condition": {"type": "not", "cond": {"type": "ok", "step": n + 1}}, "stmt": {"sql": "ROLLBACK"}})
        out = self._post(json.dumps({"requests": [{"type": "batch", "batch": {"steps": steps}}, {"type": "close"}]}).encode("utf-8"))
        r = out["results"][0]
        if r.get("type") == "error":
            raise _turso_error(r.get("error", {}))
        res = r["response"]["result"]
        for err in res["step_errors"][:n + 2]:
            if err:
                raise _turso_error(err)
        return [int(x["last_insert_rowid"]) if x and x.get("last_insert_rowid") is not None else None
                for x in res["step_results"][1:n + 1]]

    def photo_list(self, car_id):
        return [r["name"] for r in self.query("SELECT name FROM photos WHERE car_id=? ORDER BY name", (car_id,))]

    def photo_put(self, car_id, path, name=None):
        pname, data = prepare_photo(path)
        if name:  # zachowaj nazwę, ale z rozszerzeniem faktycznego formatu (np. .png -> .jpg)
            name = os.path.splitext(name)[0] + os.path.splitext(pname)[1]
        self.execute("INSERT OR REPLACE INTO photos(car_id,name,data) VALUES(?,?,?)",
                     (car_id, name or pname, base64.b64encode(data).decode("ascii")))
        return name or pname

    def photo_get(self, car_id, name):
        path = self._cached(car_id, name)
        if not os.path.isfile(path) or not os.path.getsize(path):
            rows = self.query("SELECT data FROM photos WHERE car_id=? AND name=?", (car_id, name))
            with open(path, "wb") as fh:
                fh.write(base64.b64decode(rows[0]["data"]))
        return path


COPY_TABLES = ["contractors", "drivers", "cars", "assignments", "comments", "mileage_log", "payments", "weekly", "repairs"]


def local_has_data():
    if not os.path.exists(DB):
        return False
    try:
        src = sqlite3.connect(DB)
        n = src.execute("SELECT COUNT(*) FROM cars").fetchone()[0]
        src.close()
        return n > 0
    except sqlite3.Error:
        return False


def copy_local_to_cloud():
    """Jednorazowo przenosi lokalną bazę (i zdjęcia) do bazy w chmurze. Zwraca (wiersze, zdjęcia)."""
    src = sqlite3.connect(DB)
    src.row_factory = sqlite3.Row
    have = {r[0] for r in src.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    n_rows = n_ph = 0
    for t in COPY_TABLES:
        if t not in have:
            continue
        mine = [r[1] for r in src.execute("PRAGMA table_info(%s)" % t)]
        theirs = [r["name"] for r in DBX.query("PRAGMA table_info(%s)" % t)]
        cols = [c for c in mine if c in theirs]
        sql = "INSERT OR REPLACE INTO %s(%s) VALUES(%s)" % (t, ",".join(cols), ",".join("?" * len(cols)))
        rows = src.execute("SELECT %s FROM %s" % (",".join(cols), t)).fetchall()
        for i in range(0, len(rows), 40):
            DBX.pipeline([(sql, list(r)) for r in rows[i:i + 40]])
        n_rows += len(rows)
    src.close()
    if os.path.isdir(PHOTOS):
        for cid in os.listdir(PHOTOS):
            d = os.path.join(PHOTOS, cid)
            if cid.isdigit() and os.path.isdir(d):
                for fn in os.listdir(d):
                    try:
                        DBX.photo_put(int(cid), os.path.join(d, fn), name=fn)
                        n_ph += 1
                    except (ValueError, OSError):
                        pass
    return n_rows, n_ph


DBX = None


def init_backend(cfg=None):
    global DBX
    cfg = load_config() if cfg is None else cfg
    mode = cfg.get("mode") or ("server" if cfg.get("server") else "local")
    DBX = TursoDB(cfg) if mode == "cloud" else (RemoteDB(cfg) if mode == "server" else LocalDB())
    DBX.init(SCHEMA, MIGRATIONS)


_tls = threading.local()  # wątek w tle ma własne połączenie (_tls.db)


def db():
    return getattr(_tls, "db", None) or DBX


def q(sql, args=()):
    return db().query(sql, args)


def ex(sql, args=()):
    return db().execute(sql, args)


def qb(stmts):
    """Kilka zapytań w jednym żądaniu do serwera."""
    return db().batch(stmts)


def tx(stmts):
    """Kilka zapisów naraz: wszystko albo nic."""
    stmts = [s for s in stmts if s]
    return db().tx(stmts) if stmts else []


def days_left(v):
    try:
        return (dt.date.fromisoformat(v) - dt.date.today()).days
    except (TypeError, ValueError):
        return None


ALERT_SQL = ("SELECT id, plate, mileage, oil_last_km, oil_interval, oil_warn_km, oc_until, przeglad_until "
             "FROM cars WHERE active=1", ())


def alert_rows():
    """Jedno zapytanie dla baneru i powiadomień (olej + dokumenty)."""
    return q(*ALERT_SQL)


def due_docs(rows=None, days=30):
    out = []
    for r in (alert_rows() if rows is None else rows):
        for col, label in (("oc_until", "OC"), ("przeglad_until", 'Przegląd')):
            left = days_left(r[col])
            if left is not None and left <= days:
                out.append((r, label, r[col], left))
    return sorted(out, key=lambda x: x[3])


def normalize_phone(text):
    d = re.sub(r"\D", "", text or "")
    if d.startswith("00"):
        d = d[2:]
    if len(d) == 9:
        d = "48" + d
    return d if len(d) >= 10 else ""


def copy_files_to_clipboard(paths):
    """Windows: kopiuje pliki do schowka jak w Eksploratorze (potem Ctrl+V w czacie)."""
    if sys.platform != "win32":
        return False
    import subprocess
    lst = ",".join("'%s'" % p.replace("'", "''") for p in paths)
    try:
        subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", "Set-Clipboard -LiteralPath @(%s)" % lst],
                       check=True, timeout=30, creationflags=0x08000000)
        return True
    except Exception:
        return False


def open_chat(channel, phone, text):
    import webbrowser
    if channel == "WhatsApp":
        app_url = "whatsapp://send?phone=%s&text=%s" % (phone, urllib.parse.quote(text))
        web_url = "https://wa.me/%s?text=%s" % (phone, urllib.parse.quote(text))
    else:
        app_url, web_url = "tg://resolve?phone=%s" % phone, "https://t.me/+%s" % phone
    try:
        if sys.platform != "win32":
            raise OSError
        os.startfile(app_url)
    except OSError:
        webbrowser.open(web_url)


def open_file(path):
    import webbrowser
    try:
        if sys.platform == "win32":
            os.startfile(path)
        else:
            webbrowser.open("file://" + path)
    except OSError:
        pass



def oil_left(r):
    if not r["oil_interval"]:
        return None
    return r["oil_last_km"] + r["oil_interval"] - r["mileage"]


def due_cars(rows=None):
    out = []
    for r in (alert_rows() if rows is None else rows):
        left = oil_left(r)
        if left is not None and left <= (r["oil_warn_km"] or 0):
            out.append((r, left))
    return sorted(out, key=lambda x: x[1])


def notify(title, msg):
    try:
        from winotify import Notification
        Notification(app_id="Fleet Manager", title=title, msg=msg).show()
    except Exception:
        pass  # bez winotify zostaje czerwone podświetlenie i baner w programie


# ---------------------------------------------------------------- UI helpers
def money(x):
    return ("%.2f" % (x or 0)).rstrip("0").rstrip(".")


# ---------------------------------------------------------------- logika floty (dla interfejsu)
class UserError(Exception):
    """Błąd do pokazania użytkownikowi (walidacja formularza itp.)."""


PAY_TYPES = {"cash": "Gotówka", "salary": "Z wypłaty"}
CAR_PHOTOS = [("prius plus", "toyota_prius_plus"), ("prius+", "toyota_prius_plus"), ("prius 20", "toyota_prius_20"),
              ("prius 30", "toyota_prius_30"), ("auris", "toyota_auris"), ("corolla", "toyota_corolla"),
              ("fabia", "skoda_fabia"), ("octavia", "skoda_octavia"), ("logan", "dacia_logan")]
FREE_NOTE = "Kierowca: brak (samochód wolny)"


def car_image(model):
    m = re.sub(r"\s+", " ", (model or "").lower())
    return next((f for key, f in CAR_PHOTOS if key in m), None)


def monday_of(d):
    return d - dt.timedelta(days=d.weekday())


def parse_date(s, default=None):
    try:
        return dt.date.fromisoformat(s)
    except (TypeError, ValueError):
        return default


def week_period(mon):
    return "%s – %s" % (mon.isoformat(), (mon + dt.timedelta(days=6)).isoformat())


def comment_stmt(car_id, text):
    return ("INSERT INTO comments(car_id,created_at,text) VALUES(?,?,?)", (car_id, now(), text))


def _d(r):
    return {k: r[k] for k in r.keys()}


# ---- odczyt
def cur_sql(a="a"):
    """Przydział obowiązujący dziś (okres może mieć datę końca)."""
    t = today()
    return ("%s.start_date<='%s' AND (%s.end_date IS NULL OR %s.end_date>='%s') "
            "AND EXISTS (SELECT 1 FROM drivers dd WHERE dd.id=%s.driver_id AND dd.active=1)" % (a, t, a, a, t, a))


def cars_sql():
    return CARS_SQL.replace("{cur}", cur_sql())


CARS_SQL = """SELECT c.*, k.name AS contractor,
  (SELECT a.driver_id FROM assignments a WHERE a.car_id=c.id AND {cur} ORDER BY a.start_date DESC, a.id DESC LIMIT 1) AS driver_id,
  (SELECT d.name FROM assignments a JOIN drivers d ON d.id=a.driver_id WHERE a.car_id=c.id AND {cur} ORDER BY a.start_date DESC, a.id DESC LIMIT 1) AS driver,
  (SELECT a.start_date FROM assignments a WHERE a.car_id=c.id AND {cur} ORDER BY a.start_date DESC, a.id DESC LIMIT 1) AS since,
  (SELECT a.end_date FROM assignments a WHERE a.car_id=c.id AND {cur} ORDER BY a.start_date DESC, a.id DESC LIMIT 1) AS until,
  (SELECT a.pay_type FROM assignments a WHERE a.car_id=c.id AND {cur} ORDER BY a.start_date DESC, a.id DESC LIMIT 1) AS pay_type,
  (SELECT w.paid FROM weekly w WHERE w.car_id=c.id AND w.week_start=?) AS week_paid,
  (SELECT COUNT(*) FROM repairs r WHERE r.car_id=c.id AND r.done_at IS NULL) AS repairs_open
  FROM cars c LEFT JOIN contractors k ON k.id=c.contractor_id"""


def car_view(r):
    c = _d(r)
    left = oil_left(r)
    c["oil_left"] = left
    c["oil_due"] = left is not None and left <= (r["oil_warn_km"] or 0)
    c["image"] = car_image(r["model"])
    c["status"] = "archived" if not r["active"] else ("free" if not r["driver"] else ("paid" if r["week_paid"] else "pending"))
    c["oc_days"], c["prz_days"] = days_left(r["oc_until"]), days_left(r["przeglad_until"])
    return c


def cars_list(arch=False, kind="rent"):
    """Samochody wynajmu (kind=None - wszystkie). Flota ma własny ekran (fleet_view)."""
    mon = monday_of(dt.date.today()).isoformat()
    where = [w for w in ("" if arch else "c.active=1", "c.kind=?" if kind else "") if w]
    return [car_view(r) for r in q(cars_sql() + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY c.plate",
                                   (mon,) + ((kind,) if kind else ()))]


def car_detail(cid):
    mon = monday_of(dt.date.today()).isoformat()
    cars, asg, comments, repairs, weeks, mlog = qb([
        (cars_sql() + " WHERE c.id=?", (mon, cid)),
        ("SELECT a.id, d.name, a.driver_id, a.start_date, a.end_date, a.pay_type FROM assignments a "
         "JOIN drivers d ON d.id=a.driver_id WHERE a.car_id=? ORDER BY a.start_date DESC, a.id DESC", (cid,)),
        ("SELECT id, created_at, text FROM comments WHERE car_id=? ORDER BY id DESC LIMIT 200", (cid,)),
        ("SELECT id, created_at, text, done_at, cost FROM repairs WHERE car_id=? ORDER BY (done_at IS NOT NULL), id DESC", (cid,)),
        ("SELECT week_start, paid, paid_at, amount, comment, km FROM weekly WHERE car_id=? ORDER BY week_start DESC LIMIT 60", (cid,)),
        ("SELECT created_at, km FROM mileage_log WHERE car_id=? ORDER BY id DESC LIMIT 100", (cid,))])
    if not cars:
        raise UserError("Samochód nie istnieje.")
    c = car_view(cars[0])
    crews = q("SELECT f.id, f.shift, f.driver_id, d.name, f.start_date, f.end_date FROM fleet_crews f JOIN drivers d ON d.id=f.driver_id "
              "WHERE f.car_id=? ORDER BY f.start_date DESC, f.id DESC", (cid,)) if c["kind"] == "fleet" else []
    now_crew = {r["shift"]: _d(r) for r in reversed(crews) if r["start_date"] <= today() and (r["end_date"] or INF) >= today()}
    c.update(crews=[_d(r) for r in crews], day=now_crew.get("day"), night=now_crew.get("night"))
    c.update(assignments=[_d(a) for a in asg], comments=[_d(m) for m in comments], repairs=[_d(r) for r in repairs],
             weeks=[_d(w) for w in weeks], mileage_log=[_d(m) for m in mlog])
    return c


WEEK_SQL = """SELECT * FROM (SELECT c.id, c.plate, c.model, c.mileage, c.oil_last_km, c.oil_interval, c.oil_warn_km, c.active, c.rent_week,
  (SELECT group_concat(n, ' → ') FROM (SELECT d2.name AS n FROM assignments a2 JOIN drivers d2 ON d2.id=a2.driver_id
     WHERE a2.car_id=c.id AND a2.start_date<=? AND (a2.end_date IS NULL OR a2.end_date>=?) ORDER BY a2.start_date, a2.id)) AS driver,
  (SELECT a3.pay_type FROM assignments a3 WHERE a3.car_id=c.id AND a3.start_date<=? AND (a3.end_date IS NULL OR a3.end_date>=?)
     ORDER BY a3.start_date DESC, a3.id DESC LIMIT 1) AS pay_type,
  w.paid, w.paid_at, w.amount, w.comment, w.km AS wkm,
  (SELECT m.km FROM mileage_log m WHERE m.car_id=c.id AND substr(m.created_at,1,10)<=? ORDER BY m.id DESC LIMIT 1) AS logkm
  FROM cars c LEFT JOIN weekly w ON w.car_id=c.id AND w.week_start=?) WHERE driver IS NOT NULL"""


def week_view(day=None):
    mon = monday_of(parse_date(day, dt.date.today()))
    sun = mon + dt.timedelta(days=6)
    cur = mon == monday_of(dt.date.today())
    rows = q(WEEK_SQL + (" AND active=1" if cur else "") + " ORDER BY plate",
             (sun.isoformat(), mon.isoformat(), sun.isoformat(), mon.isoformat(), sun.isoformat(), mon.isoformat()))
    out = []
    for r in rows:
        left = oil_left(r)
        km = r["mileage"] if cur else (r["wkm"] if r["wkm"] is not None else r["logkm"])
        out.append({"car_id": r["id"], "plate": r["plate"], "model": r["model"], "image": car_image(r["model"]),
                    "driver": r["driver"], "pay_type": r["pay_type"], "rent": r["rent_week"] or 0,
                    "paid": bool(r["paid"]), "paid_at": r["paid_at"], "comment": r["comment"] or "", "km": km,
                    "amount": (r["amount"] if r["amount"] is not None else (r["rent_week"] or 0)) if r["paid"] else None,
                    "oil_left": left if cur else None, "oil_due": cur and left is not None and left <= (r["oil_warn_km"] or 0)})
    due = sum(x["rent"] for x in out)
    got = sum(x["amount"] for x in out if x["paid"])
    waiting = sum(x["rent"] for x in out if not x["paid"])
    return {"monday": mon.isoformat(), "sunday": sun.isoformat(), "number": mon.isocalendar()[1], "current": cur,
            "rows": out, "kpi": {"got": got, "due": due, "waiting": waiting, "paid_n": sum(1 for x in out if x["paid"]),
                                 "n": len(out)}}


def alerts(rows=None):
    rows = alert_rows() if rows is None else rows
    out = []
    for r, left in due_cars(rows):
        out.append({"car_id": r["id"], "plate": r["plate"], "kind": "oil", "level": "bad" if left <= 0 else "warn",
                    "text": ("Wymiana oleju za %s km" % left) if left > 0 else ("Olej po terminie o %s km" % -left)})
    for r, label, dte, left in due_docs(rows):
        out.append({"car_id": r["id"], "plate": r["plate"], "kind": "doc", "level": "bad" if left < 0 else "warn",
                    "text": ("%s ważny do %s (za %d dni)" % (label, dte, left)) if left >= 0 else ("%s po terminie o %d dni" % (label, -left))})
    return out


def dashboard():
    cars = cars_list()
    wk = week_view()
    contr = q("SELECT COUNT(*) AS n, SUM(amount) AS s FROM payments WHERE paid_date IS NULL")[0]
    events = q("SELECT m.created_at, m.text, c.plate, c.id AS car_id FROM comments m JOIN cars c ON c.id=m.car_id "
               "ORDER BY m.id DESC LIMIT 8")
    no_docs = sum(1 for c in cars if not c["oc_until"] or not c["przeglad_until"])
    busy = [c for c in cars if c["driver"]]
    fleet = sorted(cars, key=lambda c: (c["status"] == "free", c["plate"]))[:8]
    return {"kpi": {"cars": len(cars), "busy": len(busy), "free": len(cars) - len(busy), "week_got": wk["kpi"]["got"],
                    "week_paid_n": wk["kpi"]["paid_n"], "week_n": wk["kpi"]["n"], "week_due": wk["kpi"]["due"],
                    "week_waiting": wk["kpi"]["waiting"],
                    "contr_unpaid_n": contr["n"], "contr_unpaid": contr["s"] or 0, "no_docs": no_docs},
            "week": {"number": wk["number"], "monday": wk["monday"], "sunday": wk["sunday"]},
            "fleet": fleet, "events": [_d(e) for e in events], "alerts": alerts()}


def drivers_list(status="active", kind="rent"):
    mon = dt.date.today().replace(day=1).isoformat()
    rows = q("""SELECT d.*,
      (SELECT c.plate FROM assignments a JOIN cars c ON c.id=a.car_id WHERE a.driver_id=d.id AND {cur} ORDER BY a.start_date DESC, a.id DESC LIMIT 1) AS plate,
      (SELECT c.id FROM assignments a JOIN cars c ON c.id=a.car_id WHERE a.driver_id=d.id AND {cur} ORDER BY a.start_date DESC, a.id DESC LIMIT 1) AS car_id,
      (SELECT c.model FROM assignments a JOIN cars c ON c.id=a.car_id WHERE a.driver_id=d.id AND {cur} ORDER BY a.start_date DESC, a.id DESC LIMIT 1) AS model,
      COALESCE((SELECT a.pay_type FROM assignments a WHERE a.driver_id=d.id AND {cur} ORDER BY a.start_date DESC, a.id DESC LIMIT 1), d.pay_type) AS pay,
      (SELECT MAX(w.paid_at) FROM weekly w JOIN assignments a ON a.car_id=w.car_id AND a.driver_id=d.id
         WHERE w.paid=1 AND w.week_start<=IFNULL(a.end_date,'9999-12-31') AND date(w.week_start,'+6 day')>=a.start_date) AS last_paid,
      (SELECT SUM(COALESCE(w.amount, c.rent_week)) FROM weekly w JOIN assignments a ON a.car_id=w.car_id AND a.driver_id=d.id JOIN cars c ON c.id=w.car_id
         WHERE w.paid=1 AND w.paid_at>=? AND w.week_start<=IFNULL(a.end_date,'9999-12-31') AND date(w.week_start,'+6 day')>=a.start_date) AS month_sum
      FROM drivers d""".replace("{cur}", cur_sql()) + " WHERE " + " AND ".join(
        [{"active": "d.active=1", "archived": "d.active=0"}.get(status, "1")] + (["d.kind=?"] if kind else []))
             + " ORDER BY d.name", (mon,) + ((kind,) if kind else ()))
    return [dict(_d(r), image=car_image(r["model"])) for r in rows]


def contractors_list(status="active"):
    return [_d(r) for r in q(
        "SELECT k.*, (SELECT COUNT(*) FROM cars c WHERE c.contractor_id=k.id AND c.active=1) AS cars, "
        "(SELECT SUM(amount) FROM payments p WHERE p.contractor_id=k.id AND p.paid_date IS NULL) AS unpaid FROM contractors k" +
        {"active": " WHERE k.active=1", "archived": " WHERE k.active=0"}.get(status, "") + " ORDER BY k.name")]


def payments_list(unpaid=False):
    rows, tot = qb([("SELECT p.*, k.name AS contractor FROM payments p JOIN contractors k ON k.id=p.contractor_id" +
                     (" WHERE p.paid_date IS NULL" if unpaid else "") + " ORDER BY p.id DESC", ()),
                    ("SELECT COUNT(*) AS n, SUM(amount) AS s, "
                     "(SELECT SUM(COALESCE(paid_amount, amount)) FROM payments WHERE paid_date IS NOT NULL) AS paid, "
                     "(SELECT COUNT(*) FROM payments WHERE paid_date IS NOT NULL) AS paid_n "
                     "FROM payments WHERE paid_date IS NULL", ())])
    out = []
    for r in rows:
        x = _d(r)
        x["paid_amount"] = (r["paid_amount"] if r["paid_amount"] is not None else r["amount"]) if r["paid_date"] else None
        out.append(x)
    t = tot[0]
    return {"rows": out, "unpaid_n": t["n"], "unpaid_sum": t["s"] or 0, "paid_sum": t["paid"] or 0, "paid_n": t["paid_n"]}


def history(p):
    ms, me = parse_date(p.get("from")), parse_date(p.get("to"))
    if ms and me and ms > me:
        ms, me = me, ms
    size, page = max(1, int(p.get("size") or 20)), max(0, int(p.get("page") or 0))
    like = "%" + (p.get("q") or "").strip() + "%"
    base = ("FROM assignments a JOIN cars c ON c.id=a.car_id JOIN drivers d ON d.id=a.driver_id "
            "LEFT JOIN contractors k ON k.id=c.contractor_id WHERE a.start_date<=? AND (a.end_date IS NULL OR a.end_date>=?) "
            "AND (c.plate LIKE ? OR IFNULL(c.model,'') LIKE ? OR d.name LIKE ? OR IFNULL(k.name,'') LIKE ?)")
    args = ((me or dt.date.max).isoformat(), (ms or dt.date.min).isoformat(), like, like, like, like)
    order = {"plate": "c.plate", "contractor": "IFNULL(k.name,'')", "driver": "d.name", "start": "a.start_date",
             "end": "IFNULL(a.end_date,'9999')"}.get(p.get("sort"), "c.plate")
    sel = ("SELECT a.id, c.id AS car_id, c.plate, c.model, k.name AS contractor, d.name AS driver, a.start_date, a.end_date " + base +
           " ORDER BY %s %s, c.plate, a.start_date LIMIT ? OFFSET ?" % (order, "DESC" if p.get("desc") else "ASC"))
    first, total, rows = qb([("SELECT MIN(start_date) AS d FROM assignments", ()), ("SELECT COUNT(*) AS n " + base, args),
                             (sel, args + (size, page * size))])
    total = total[0]["n"]
    pages = max(1, -(-total // size))
    if page > pages - 1:
        page = pages - 1
        rows = q(sel, args + (size, page * size))
    out = []
    for r in rows:
        s0, e0 = parse_date(r["start_date"]), parse_date(r["end_date"], dt.date.today())
        days = None
        if s0:
            s0, e0 = max(s0, ms) if ms else s0, min(e0, me) if me else e0
            days = max(0, (e0 - s0).days + 1)
        out.append(dict(_d(r), days=days, image=car_image(r["model"])))
    return {"rows": out, "page": page, "pages": pages, "total": total, "first": first[0]["d"]}


def lookups():
    cars, drivers, contr = qb([
        ("SELECT c.id, c.plate, c.model, (SELECT a.driver_id FROM assignments a WHERE a.car_id=c.id AND %s "
         "LIMIT 1) AS driver_id FROM cars c WHERE c.active=1 AND c.kind='rent' ORDER BY c.plate" % cur_sql(), ()),
        ("SELECT id, name, pay_type, active FROM drivers WHERE kind='rent' ORDER BY name", ()),
        ("SELECT id, name FROM contractors WHERE active=1 ORDER BY name", ())])
    return {"cars": [_d(c) for c in cars], "drivers": [_d(d) for d in drivers], "contractors": [_d(k) for k in contr],
            "pay_types": PAY_TYPES}


# ---- zapisy
def save_car(d):
    cid = d.get("id")
    plate = norm_plate(d.get("plate"))
    if not plate:
        raise UserError("Podaj numer rejestracyjny.")
    if any(norm_plate(x["plate"]) == plate for x in q("SELECT plate FROM cars WHERE id IS NOT ?", (cid,))):
        raise UserError("Samochód z takim numerem już istnieje.")
    for key in ("oc_until", "przeglad_until"):
        if d.get(key) and not valid_date(d[key]):
            raise UserError("Nieprawidłowa data.")
    km = num(d.get("mileage"), 0)
    vals = {"plate": plate, "model": (d.get("model") or "").strip(), "contractor_id": d.get("contractor_id") or None,
            "mileage": km, "oil_last_km": num(d.get("oil_last_km"), 0), "oil_interval": num(d.get("oil_interval"), 10000),
            "oil_warn_km": num(d.get("oil_warn_km"), 1000), "rent_week": flt(d.get("rent_week")), "owner_rate": flt(d.get("owner_rate")),
            "oc_until": d.get("oc_until") or None, "przeglad_until": d.get("przeglad_until") or None,
            "year": num(d.get("year")), "fuel": (d.get("fuel") or "").strip() or None, "gearbox": (d.get("gearbox") or "").strip() or None}
    if d.get("kind") in KINDS:
        vals["kind"] = d["kind"]
    if "city" in d:
        vals["city"] = d["city"] if d["city"] in CITIES else None
    cols = list(vals)
    try:
        if cid:
            old = q("SELECT mileage FROM cars WHERE id=?", (cid,))
            if not old:
                raise UserError("Samochód nie istnieje.")
            tx([("UPDATE cars SET %s WHERE id=?" % ",".join("%s=?" % k for k in cols), tuple(vals.values()) + (cid,)),
                ("INSERT INTO mileage_log(car_id,created_at,km) VALUES(?,?,?)", (cid, now(), km)) if km != old[0]["mileage"] else None])
            return cid
        return ex("INSERT INTO cars(%s) VALUES(%s)" % (",".join(cols), ",".join("?" * len(cols))), tuple(vals.values()))
    except sqlite3.IntegrityError:
        raise UserError("Samochód z takim numerem już istnieje.")


def save_contractor(d):
    cid, name = d.get("id"), (d.get("name") or "").strip()
    if not name:
        raise UserError("Podaj nazwę.")
    if q("SELECT 1 FROM contractors WHERE name=? AND id IS NOT ?", (name, cid)):
        raise UserError("Taka nazwa już istnieje.")
    vals = (name, (d.get("contact") or "").strip(), (d.get("nip") or "").strip(), (d.get("notes") or "").strip())
    if cid:
        ex("UPDATE contractors SET name=?,contact=?,nip=?,notes=? WHERE id=?", vals + (cid,))
        return cid
    return ex("INSERT INTO contractors(name,contact,nip,notes) VALUES(?,?,?,?)", vals)


def save_driver(d):
    did, name = d.get("id"), (d.get("name") or "").strip()
    if not name:
        raise UserError("Podaj imię i nazwisko.")
    if q("SELECT 1 FROM drivers WHERE name=? AND id IS NOT ?", (name, did)):
        raise UserError("Kierowca o takim imieniu już istnieje.")
    pay = d.get("pay_type") if d.get("pay_type") in PAY_TYPES else None
    phone = (d.get("phone") or "").strip()
    kind = d.get("kind") if d.get("kind") in KINDS else None
    city = (d["city"] if d["city"] in CITIES else None) if "city" in d else False  # False = bez zmiany
    if did:
        cur = q("SELECT id, pay_type FROM assignments a WHERE driver_id=? AND %s ORDER BY start_date DESC, id DESC LIMIT 1" % cur_sql(), (did,))
        tx([("UPDATE drivers SET name=?,phone=?,pay_type=? WHERE id=?", (name, phone, pay, did)),
            ("UPDATE drivers SET kind=? WHERE id=?", (kind, did)) if kind else None,
            ("UPDATE drivers SET city=? WHERE id=?", (city, did)) if city is not False else None,
            ("UPDATE assignments SET pay_type=? WHERE id=?", (pay, cur[0]["id"])) if cur and pay and pay != cur[0]["pay_type"] else None])
        return did
    return ex("INSERT INTO drivers(name,phone,pay_type,kind,city) VALUES(?,?,?,?,?)",
              (name, phone, pay, kind or "rent", city or None))


def save_payment(d):
    pid = d.get("id")
    if not d.get("contractor_id"):
        raise UserError("Wybierz kontrahenta.")
    f, t = d.get("from"), d.get("to")
    if not (valid_date(f) and valid_date(t)):
        raise UserError("Podaj okres.")
    if d.get("paid_date") and not valid_date(d["paid_date"]):
        raise UserError("Nieprawidłowa data płatności.")
    paid = d.get("paid_date") or None
    paid_amount = flt(d.get("paid_amount")) if paid else None
    vals = (d["contractor_id"], "%s – %s" % (f, t), flt(d.get("amount")), paid, paid_amount, (d.get("note") or "").strip())
    if pid:
        ex("UPDATE payments SET contractor_id=?,period=?,amount=?,paid_date=?,paid_amount=?,note=? WHERE id=?", vals + (pid,))
        return pid
    return ex("INSERT INTO payments(contractor_id,period,amount,paid_date,paid_amount,note) VALUES(?,?,?,?,?,?)", vals)


def toggle_payment(pid, amount=None, date=None):
    """Bez kwoty: cofnięcie zapłaty albo zapłata pełnej kwoty. Z kwotą: zapłacono tyle (może być mniej niż naliczono)."""
    r = q("SELECT paid_date, amount FROM payments WHERE id=?", (pid,))
    if not r:
        raise UserError("Płatność nie istnieje.")
    if amount is None and r[0]["paid_date"]:
        ex("UPDATE payments SET paid_date=NULL, paid_amount=NULL WHERE id=?", (pid,))
        return False
    value = flt(amount) if amount is not None else r[0]["amount"]
    if value is None or value < 0:
        raise UserError("Podaj kwotę.")
    date = date or today()
    if not valid_date(date):
        raise UserError("Nieprawidłowa data.")
    ex("UPDATE payments SET paid_date=?, paid_amount=? WHERE id=?", (date, value, pid))
    return True


def accrue_week(day):
    d0 = parse_date(day)
    if not d0:
        raise UserError("Podaj datę.")
    mon = monday_of(d0)
    sun = mon + dt.timedelta(days=6)
    period = week_period(mon)
    cars, have = qb([
        ("SELECT c.contractor_id, c.plate, c.owner_rate FROM cars c WHERE c.owner_rate > 0 AND c.contractor_id IS NOT NULL "
         "AND EXISTS (SELECT 1 FROM assignments a WHERE a.car_id=c.id AND a.start_date<=? AND (a.end_date IS NULL OR a.end_date>=?)) "
         "ORDER BY c.plate", (sun.isoformat(), mon.isoformat())),
        ("SELECT contractor_id FROM payments WHERE period=?", (period,))])
    if not cars:
        raise UserError("Brak danych do naliczenia za ten tydzień.")
    per = {}
    for c in cars:
        e = per.setdefault(c["contractor_id"], [0.0, []])
        e[0] += c["owner_rate"]
        e[1].append(c["plate"])
    done = {h["contractor_id"] for h in have}
    new = {k: v for k, v in per.items() if k not in done}
    tx([("INSERT INTO payments(contractor_id,period,amount,note) VALUES(?,?,?,?)", (k, period, s, ", ".join(p)))
        for k, (s, p) in new.items()])
    return {"added": len(new), "sum": sum(s for s, p in new.values()), "skipped": len(per) - len(new)}


INF = "9999-12-31"


def _overlaps(start, end, rows):
    """Okresy z rows, które nachodzą na [start, end]; styk w jednym dniu (koniec = początek) jest dozwolony."""
    e = end or INF
    return [r for r in rows if r["start_date"] < e and start < (r["end_date"] or INF)]


def day_before(s):
    return (dt.date.fromisoformat(s) - dt.timedelta(days=1)).isoformat()


def dmy(s):
    return "%s.%s.%s" % (s[8:10], s[5:7], s[:4]) if s else ""


def _span(r):
    return "%s – %s" % (dmy(r["start_date"]), dmy(r["end_date"]) or "obecnie")


def assign_plan(did, car_id, date, pay, new_name=None, end=None):
    """(polecenia, opis zmian). Nowy okres [date, end]; end puste = obecnie.
    Okresy zaczęte wcześniej kończą się w dniu date, późniejsze nachodzące = błąd."""
    if end and end < date:
        raise UserError("Data „Do” jest wcześniejsza niż „Od”.")
    car_rows, drv_rows, drv, car = qb([
        ("SELECT a.id, a.driver_id, a.pay_type, a.start_date, a.end_date, d.name FROM assignments a "
         "JOIN drivers d ON d.id=a.driver_id WHERE a.car_id=?", (car_id,)),
        ("SELECT a.id, a.car_id, a.start_date, a.end_date, c.plate FROM assignments a JOIN cars c ON c.id=a.car_id "
         "WHERE a.driver_id=? AND a.car_id IS NOT ?", (did, car_id)),
        ("SELECT name FROM drivers WHERE id=?", (did,)),
        ("SELECT plate FROM cars WHERE id=?", (car_id,))])
    name = new_name or (drv[0]["name"] if drv else None)
    plate = car[0]["plate"] if car else ""
    stmts, notes = [], []

    def cut(r, who, where):
        if r["start_date"] > date:
            raise UserError("Okres nakłada się na %s na %s (%s). Popraw lub usuń tamten okres." % (who, where, _span(r)))
        if r["start_date"] == date:  # zmiana tego samego dnia: poprzedni wpis był pomyłką
            stmts.append(("DELETE FROM assignments WHERE id=?", (r["id"],)))
        else:  # ostatni dzień poprzedniego kierowcy - dzień przed zmianą
            stmts.append(("UPDATE assignments SET end_date=? WHERE id=?", (day_before(date), r["id"])))

    if new_name:
        stmts.append(("INSERT INTO drivers(name,pay_type) VALUES(?,?)", (new_name, pay)))
    for r in _overlaps(date, end if car_id else None, drv_rows if did else []):
        cut(r, name, r["plate"])
        stmts.append(comment_stmt(r["car_id"], FREE_NOTE))
        notes.append("%s schodzi z %s (%s)" % (name, r["plate"], dmy(date)))
        notes.append("%s zostaje bez kierowcy" % r["plate"])
    if not car_id:
        return stmts, notes
    over = _overlaps(date, end, car_rows)
    mine = [r for r in over if did and r["driver_id"] == did]
    if mine and not end and len(over) == 1 and mine[0]["start_date"] <= date and not mine[0]["end_date"]:
        if pay and pay != mine[0]["pay_type"]:
            stmts.append(("UPDATE assignments SET pay_type=? WHERE id=?", (pay, mine[0]["id"])))
        return stmts, notes
    for r in over:
        cut(r, r["name"], plate)
        notes.append("%s zdjęty z %s (%s)" % (r["name"], plate, dmy(date)))
    if name:
        who = "(SELECT id FROM drivers WHERE name=?)" if new_name else "?"
        stmts.append(("INSERT INTO assignments(car_id,driver_id,start_date,end_date,pay_type) VALUES(?,%s,?,?,?)" % who,
                      (car_id, new_name or did, date, end, pay)))
        stmts.append(comment_stmt(car_id, "Kierowca: %s" % name + (" (%s – %s)" % (dmy(date), dmy(end)) if end else "")))
        notes.append("%s na %s " % (name, plate) + ("%s – %s" % (dmy(date), dmy(end)) if end else "od %s" % dmy(date)))
    else:
        stmts.append(comment_stmt(car_id, FREE_NOTE))
        notes.append("%s zostaje bez kierowcy" % plate)
    return stmts, notes


def _assign_args(d):
    car_id = d.get("car_id") or None
    did = d.get("driver_id") or None
    new_name = (d.get("new_name") or "").strip() or None
    if new_name:
        ex_ = q("SELECT id FROM drivers WHERE name=?", (new_name,))
        if ex_:
            did, new_name = ex_[0]["id"], None
    if not car_id and not did:
        raise UserError("Wybierz samochód.")
    if not valid_date(d.get("date")):
        raise UserError("Podaj datę.")
    end = d.get("end") or None
    if end and not valid_date(end):
        raise UserError("Nieprawidłowa data.")
    pay = d.get("pay_type") if d.get("pay_type") in PAY_TYPES else None
    if not pay and did:
        r = q("SELECT pay_type FROM drivers WHERE id=?", (did,))
        pay = r[0]["pay_type"] if r else None
    return did, car_id, d["date"], pay, new_name, end


def assign_preview(d):
    return assign_plan(*_assign_args(d))[1]


def assign_apply(d):
    did, car_id, date, pay, new_name, end = _assign_args(d)
    stmts, notes = assign_plan(did, car_id, date, pay, new_name, end)
    if did:
        stmts.insert(0, ("UPDATE drivers SET active=1, pay_type=? WHERE id=?", (pay, did)))
    tx(stmts)
    return notes


def save_assignment(d):
    """Poprawka dat i płatności jednego okresu."""
    aid = d.get("id")
    start, end = d.get("start") or None, d.get("end") or None
    if not valid_date(start) or (end and not valid_date(end)):
        raise UserError("Podaj datę.")
    if end and end < start:
        raise UserError("Data „Do” jest wcześniejsza niż „Od”.")
    cur = q("SELECT car_id, driver_id FROM assignments WHERE id=?", (aid,))
    if not cur:
        raise UserError("Wpis nie istnieje.")
    by_car, by_drv = qb([
        ("SELECT a.start_date, a.end_date, d.name AS who FROM assignments a JOIN drivers d ON d.id=a.driver_id "
         "WHERE a.car_id=? AND a.id<>?", (cur[0]["car_id"], aid)),
        ("SELECT a.start_date, a.end_date, c.plate AS who FROM assignments a JOIN cars c ON c.id=a.car_id "
         "WHERE a.driver_id=? AND a.id<>?", (cur[0]["driver_id"], aid))])
    for r in _overlaps(start, end, by_car) + _overlaps(start, end, by_drv):
        raise UserError("Okres nakłada się na %s (%s)." % (r["who"], _span(r)))
    pay = d.get("pay_type") if d.get("pay_type") in PAY_TYPES else None
    ex("UPDATE assignments SET start_date=?, end_date=?, pay_type=? WHERE id=?", (start, end, pay, aid))
    return True


def has_archive_password():
    return bool(q("SELECT 1 FROM app_settings WHERE key='archive_password_sha256'"))


def _password_stmts(password, new_password=False):
    """Sprawdza wspólne hasło (archiwum i usuwanie); przy pierwszym użyciu - zapis nowego hasła."""
    digest = hashlib.sha256((password or "").encode("utf-8")).hexdigest()
    row = q("SELECT value FROM app_settings WHERE key='archive_password_sha256'")
    if not row:
        if not new_password or len(password or "") < 4:
            raise UserError("Hasło musi mieć co najmniej 4 znaki.")
        return [("INSERT INTO app_settings(key,value) VALUES('archive_password_sha256',?)", (digest,))]
    if digest != row[0]["value"]:
        raise UserError("Nieprawidłowe hasło.")
    return []


def archive(table, iid, password, new_password=False):
    if table not in ("cars", "drivers", "contractors"):
        raise UserError("Nieznany typ.")
    stmts = _password_stmts(password, new_password)
    r = q("SELECT active FROM %s WHERE id=?" % table, (iid,))
    if not r:
        raise UserError("Wpis nie istnieje.")
    active = r[0]["active"]
    open_sql = "AND (end_date IS NULL OR end_date>?)"
    if active and table == "cars":
        stmts.append(("UPDATE assignments SET end_date=MAX(start_date, ?) WHERE car_id=? " + open_sql, (day_before(today()), iid, today())))
    if active and table == "drivers":
        for a in q("SELECT id, car_id, start_date FROM assignments WHERE driver_id=? " + open_sql, (iid, today())):
            stmts += [("UPDATE assignments SET end_date=? WHERE id=?", (max(day_before(today()), a["start_date"]), a["id"])),
                      comment_stmt(a["car_id"], FREE_NOTE)]
    stmts.append(("UPDATE %s SET active=? WHERE id=?" % table, (0 if active else 1, iid)))
    tx(stmts)
    return not active



# ---- flota: samochody z dwoma kierowcami (zmiana dzienna i nocna)
SHIFT_PL = {"day": "dzienna", "night": "nocna"}


def fleet_view():
    t = today()
    cars, crews, drivers = qb([
        ("SELECT id, plate, model, year, mileage, city, oc_until, przeglad_until FROM cars WHERE kind='fleet' AND active=1 ORDER BY plate", ()),
        ("SELECT f.car_id, f.shift, f.driver_id, d.name, f.start_date FROM fleet_crews f JOIN drivers d ON d.id=f.driver_id "
         "WHERE f.start_date<=? AND (f.end_date IS NULL OR f.end_date>=?) AND d.active=1 ORDER BY f.start_date, f.id", (t, t)),
        ("SELECT d.id, d.name, d.phone, d.city, d.sheet_key, EXISTS(SELECT 1 FROM tg_users u WHERE u.driver_id=d.id) AS tg FROM drivers d "
         "WHERE d.kind='fleet' AND d.active=1 ORDER BY d.name", ())])
    week = q("SELECT MAX(week_start) AS w FROM fleet_cash")[0]["w"]
    cash = {r["driver_id"]: r["cash_sheet"] for r in q("SELECT driver_id, cash_sheet FROM fleet_cash WHERE week_start=?", (week,))} if week else {}
    by_car, by_driver = {}, {}
    for r in crews:  # późniejszy start wygrywa
        by_car[(r["car_id"], r["shift"])] = _d(r)
        by_driver[r["driver_id"]] = _d(r)
    plates = {c["id"]: c["plate"] for c in cars}
    out_cars = []
    for c in cars:
        x = _d(c)
        x.update(image=car_image(c["model"]), oc_days=days_left(c["oc_until"]), prz_days=days_left(c["przeglad_until"]),
                 day=by_car.get((c["id"], "day")), night=by_car.get((c["id"], "night")))
        out_cars.append(x)
    out_drivers = []
    for d in drivers:
        cr = by_driver.get(d["id"])
        out_drivers.append(dict(_d(d), tg=bool(d["tg"]), car_id=cr["car_id"] if cr else None,
                                plate=plates.get(cr["car_id"]) if cr else None, shift=cr["shift"] if cr else None,
                                cash=cash.get(d["id"])))
    filled = sum(1 for c in out_cars for s in SHIFTS if c[s])
    return {"cars": out_cars, "drivers": out_drivers, "cash_week": week,
            "kpi": {"cars": len(out_cars), "drivers": len(out_drivers), "free": 2 * len(out_cars) - filled,
                    "docs": sum(1 for c in out_cars for k in ("oc_days", "prz_days") if c[k] is not None and c[k] <= 30)}}


def fleet_crew_set(car_id, shift, driver_id, date):
    """Kierowca na zmianę (albo None - zmiana wolna) od daty. Poprzedni na tej zmianie kończy dzień wcześniej;
    kierowca schodzi z innej zmiany/samochodu (jeden kierowca = jedna zmiana)."""
    if shift not in SHIFTS:
        raise UserError("Wybierz zmianę.")
    if not valid_date(date):
        raise UserError("Podaj datę.")
    car = q("SELECT plate FROM cars WHERE id=? AND kind='fleet' AND active=1", (car_id,))
    if not car:
        raise UserError("Samochód floty nie istnieje.")
    name = None
    if driver_id:
        r = q("SELECT name FROM drivers WHERE id=? AND kind='fleet' AND active=1", (driver_id,))
        if not r:
            raise UserError("Kierowca floty nie istnieje.")
        name = r[0]["name"]
    rows = q("SELECT f.id, f.car_id, f.shift, f.driver_id, f.start_date, c.plate FROM fleet_crews f JOIN cars c ON c.id=f.car_id "
             "WHERE (f.end_date IS NULL OR f.end_date>=?) AND ((f.car_id=? AND f.shift=?) OR f.driver_id=?)",
             (date, car_id, shift, driver_id or -1))
    stmts, notes = [], []
    for r in rows:
        if r["driver_id"] == driver_id and r["car_id"] == car_id and r["shift"] == shift and r["start_date"] <= date:
            return []  # już na tej zmianie
        if r["start_date"] >= date:
            stmts.append(("DELETE FROM fleet_crews WHERE id=?", (r["id"],)))
        else:
            stmts.append(("UPDATE fleet_crews SET end_date=? WHERE id=?", (day_before(date), r["id"])))
        if r["car_id"] != car_id or r["shift"] != shift:
            stmts.append(comment_stmt(r["car_id"], "Zmiana %s: brak kierowcy" % SHIFT_PL[r["shift"]]))
            notes.append("%s: zmiana %s wolna" % (r["plate"], SHIFT_PL[r["shift"]]))
    if driver_id:
        stmts.append(("INSERT INTO fleet_crews(car_id,driver_id,shift,start_date) VALUES(?,?,?,?)", (car_id, driver_id, shift, date)))
    stmts.append(comment_stmt(car_id, "Zmiana %s: %s" % (SHIFT_PL[shift], name or "brak kierowcy")))
    notes.append("%s: zmiana %s — %s od %s" % (car[0]["plate"], SHIFT_PL[shift], name or "wolna", dmy(date)))
    tx(stmts)
    return notes


def norm_name(s):
    """Imię i nazwisko do porównań z arkuszem: bez wielkości liter i podwójnych spacji (polskie litery zostają)."""
    return " ".join((s or "").split()).casefold()


def fleet_import_drivers(rows):
    """Kierowcy floty z arkusza rozliczeń: [{name, city, sheet_key}]. Szuka po ID z arkusza, potem po imieniu;
    istniejący dostaje kind=fleet, miasto i ID, nowy jest dodawany. Zwraca {'added': [...], 'updated': [...]}."""
    have = q("SELECT id, name, sheet_key FROM drivers")
    by_key = {r["sheet_key"]: r for r in have if r["sheet_key"]}
    by_name = {norm_name(r["name"]): r for r in have}
    stmts, added, updated = [], [], []
    for x in rows:
        name, key = " ".join((x.get("name") or "").split()), (x.get("sheet_key") or "").strip() or None
        city = x.get("city") if x.get("city") in CITIES else None
        if not name:
            raise UserError("Brak imienia w danych z arkusza.")
        r = by_key.get(key) or by_name.get(norm_name(name))
        if r:
            stmts.append(("UPDATE drivers SET kind='fleet', city=?, sheet_key=COALESCE(?, sheet_key), active=1 WHERE id=?", (city, key, r["id"])))
            updated.append(r["name"])
        else:
            stmts.append(("INSERT INTO drivers(name,kind,city,sheet_key) VALUES(?,'fleet',?,?)", (name, city, key)))
            added.append(name)
            by_name[norm_name(name)] = {"id": None, "name": name, "sheet_key": key}
    tx(stmts)
    return {"added": added, "updated": updated}



# ---- gotówka kierowców floty z arkusza rozliczeń (co tydzień)
def cash_week_of(settlement):
    """Rozliczenie z poniedziałku dotyczy poprzedniego tygodnia (pon-nd). Zwraca ISO poniedziałku tamtego tygodnia."""
    d = parse_date(settlement)
    if not d:
        raise UserError("Nieprawidłowa data rozliczenia.")
    return (monday_of(d) - dt.timedelta(days=7)).isoformat()


def fleet_cash_store(settlement, items):
    """items: [(driver_id, kwota_gotówki, wiersz_arkusza)]. Zapis/aktualizacja za tydzień rozliczenia.
    Zwraca {'week_start', 'new', 'changed', 'same'}."""
    week = cash_week_of(settlement)
    old = {r["driver_id"]: r["cash_sheet"] for r in q("SELECT driver_id, cash_sheet FROM fleet_cash WHERE week_start=?", (week,))}
    stmts, res = [], {"week_start": week, "new": 0, "changed": 0, "same": 0}
    for did, cash, row in items:
        key = "new" if did not in old else ("same" if old[did] == cash else "changed")
        res[key] += 1
        if key != "same":
            stmts.append(("INSERT INTO fleet_cash(driver_id,week_start,settlement_date,cash_sheet,sheet_row,read_at) VALUES(?,?,?,?,?,?) "
                          "ON CONFLICT(driver_id,week_start) DO UPDATE SET cash_sheet=excluded.cash_sheet, sheet_row=excluded.sheet_row, "
                          "settlement_date=excluded.settlement_date, read_at=excluded.read_at",
                          (did, week, parse_date(settlement).isoformat(), cash, row, now_s())))
    tx(stmts)
    return res


def fleet_cash_week(week_start):
    return [_d(r) for r in q("SELECT c.driver_id, d.name, d.city, c.cash_sheet FROM fleet_cash c JOIN drivers d ON d.id=c.driver_id "
                             "WHERE c.week_start=? ORDER BY d.city, d.name", (week_start,))]


# ---- gotówka floty: do oddania = GOTÓWKA z arkusza − faktury + saldo z poprzednich tygodni; minus to, co oddał
# Saldo (dług albo nadpłata) przechodzi na następny tydzień samo: liczymy je z wpisów, nic nie przechowujemy osobno.
CASH_KINDS = {"cash": "Wpłata", "invoice": "Faktury"}
CASH_EPS = 0.005


def _r2(x):
    return round(x + 0.0, 2)


def cash_start():
    """Pierwszy tydzień rozliczeń w programie (app_settings.cash_start_week); wcześniejsze tygodnie nie liczą się do salda."""
    r = q("SELECT value FROM app_settings WHERE key='cash_start_week'")
    return r[0]["value"] if r and r[0]["value"] else None


def set_cash_start(week):
    w = parse_date(week)
    if not w:
        raise UserError("Wybierz tydzień.")
    w = monday_of(w).isoformat()
    ex("INSERT INTO app_settings(key,value) VALUES('cash_start_week',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (w,))
    return w


def cash_weeks():
    """Tygodnie (poniedziałki) z danymi: arkusz albo wpisy, od najnowszego (od tygodnia startowego)."""
    start = cash_start() or ""
    return [r["w"] for r in q("SELECT w FROM (SELECT week_start AS w FROM fleet_cash UNION SELECT week_start FROM cash_entries) "
                              "WHERE w>=? ORDER BY 1 DESC", (start,))]


def _cash_ledger(driver_id=None):
    """{driver_id: {week: {'sheet', 'invoice', 'cash', 'entries': [...]}}}"""
    where, args = ("WHERE week_start>=? AND driver_id=?", (cash_start() or "", driver_id)) if driver_id else         ("WHERE week_start>=?", (cash_start() or "",))
    sheet, entries = qb([("SELECT driver_id, week_start, cash_sheet FROM fleet_cash %s" % where, args),
                         ("SELECT id, driver_id, week_start, kind, amount, entry_date, note FROM cash_entries %s ORDER BY entry_date, id" % where, args)])
    led = {}

    def cell(did, w):
        return led.setdefault(did, {}).setdefault(w, {"sheet": None, "invoice": 0.0, "cash": 0.0, "entries": []})
    for r in sheet:
        cell(r["driver_id"], r["week_start"])["sheet"] = r["cash_sheet"]
    for r in entries:
        c = cell(r["driver_id"], r["week_start"])
        c[r["kind"]] += r["amount"] or 0
        c["entries"].append(_d(r))
    return led


def _cash_status(x):
    if x["sheet"] is None and not x["entries"] and abs(x["carry"]) < CASH_EPS:
        return "none"
    if abs(x["balance"]) < CASH_EPS:
        return "ok"
    if x["balance"] < 0:
        return "over"
    return "partial" if x["cash"] > 0 else "unpaid"


def _cash_row(weeks, week):
    """Wiersz tygodnia dla jednego kierowcy: saldo z wcześniejszych tygodni + ten tydzień."""
    carry = sum((c["sheet"] or 0) - c["invoice"] - c["cash"] for w, c in weeks.items() if w < week)
    c = weeks.get(week) or {"sheet": None, "invoice": 0.0, "cash": 0.0, "entries": []}
    due = (c["sheet"] or 0) - c["invoice"] + carry
    x = {"week": week, "sheet": c["sheet"], "invoice": _r2(c["invoice"]), "carry": _r2(carry), "due": _r2(due),
         "cash": _r2(c["cash"]), "balance": _r2(due - c["cash"]), "entries": c["entries"]}
    x["status"] = _cash_status(x)
    return x


def cash_view(week=None, city=None):
    """Ekran "Gotówka": kierowcy floty za tydzień (domyślnie ostatni z danymi). Kierowcy spoza floty / w archiwum -
    tylko jeśli mają dane albo saldo."""
    weeks = cash_weeks()
    week = monday_of(parse_date(week)).isoformat() if week and parse_date(week) else (weeks[0] if weeks else None)
    led = _cash_ledger()
    drivers = q("SELECT d.id, d.name, d.city, d.kind, d.active FROM drivers d WHERE (d.kind='fleet' AND d.active=1) "
                "OR d.id IN (SELECT driver_id FROM fleet_cash UNION SELECT driver_id FROM cash_entries) ORDER BY d.name")
    crews = {r["driver_id"]: _d(r) for r in q("SELECT f.driver_id, f.shift, c.plate FROM fleet_crews f JOIN cars c ON c.id=f.car_id "
                                              "WHERE f.start_date<=? AND (f.end_date IS NULL OR f.end_date>=?) ORDER BY f.start_date",
                                              (today(), today()))}
    rows = []
    for d in drivers:
        if city and d["city"] != city:
            continue
        x = _cash_row(led.get(d["id"], {}), week) if week else {"status": "none", "balance": 0, "carry": 0, "entries": []}
        if (not d["active"] or d["kind"] != "fleet") and x["status"] == "none":
            continue
        cr = crews.get(d["id"])
        rows.append(dict(x, driver_id=d["id"], name=d["name"], city=d["city"], active=bool(d["active"]),
                         plate=cr["plate"] if cr else None, shift=cr["shift"] if cr else None))
    tot = {k: _r2(sum(r.get(k) or 0 for r in rows)) for k in ("sheet", "invoice", "due", "cash")}
    tot["debt"] = _r2(sum(r["balance"] for r in rows if r["balance"] > CASH_EPS))
    tot["unpaid"] = sum(1 for r in rows if r["balance"] > CASH_EPS)
    return {"week": week, "weeks": weeks, "rows": rows, "total": tot,
            "cities": sorted({d["city"] for d in drivers if d["city"]})}


def cash_add(d):
    """Wpis biura: faktury (kind='invoice') albo oddana gotówka (kind='cash') za tydzień kierowcy."""
    kind = d.get("kind")
    if kind not in CASH_KINDS:
        raise UserError("Wybierz rodzaj wpisu.")
    w = parse_date(d.get("week"))
    if not w:
        raise UserError("Wybierz tydzień.")
    amount = flt(d.get("amount"))
    if amount is None or amount <= 0:
        raise UserError("Podaj kwotę.")
    date = d.get("date") or today()
    if not valid_date(date):
        raise UserError("Nieprawidłowa data.")
    if not q("SELECT 1 FROM drivers WHERE id=?", (d.get("driver_id"),)):
        raise UserError("Kierowca nie istnieje.")
    return ex("INSERT INTO cash_entries(driver_id,week_start,kind,amount,entry_date,note,created_at) VALUES(?,?,?,?,?,?,?)",
              (int(d["driver_id"]), monday_of(w).isoformat(), kind, _r2(amount), date, (d.get("note") or "").strip() or None, now()))


def cash_history(driver_id):
    """Wszystkie tygodnie kierowcy (od najnowszego) z saldem przeniesionym z poprzednich."""
    weeks = _cash_ledger(driver_id).get(int(driver_id), {})
    return [_cash_row(weeks, w) for w in sorted(weeks, reverse=True)]


def cash_debtors(week):
    """Do raportu biura: kto po terminie ma jeszcze do oddania (saldo > 0) za dany tydzień."""
    return [r for r in cash_view(week)["rows"] if r["balance"] > CASH_EPS]


# ---- wyszukiwanie dla bota biura: numer rejestracyjny albo imię kierowcy (wynajem i flota)
def office_search(text, limit=5):
    """{'cars': [...], 'drivers': [...], 'more': bool, 'cash_week': ...} - bez AI, tylko dane z bazy."""
    text = " ".join((text or "").split())
    empty = {"cars": [], "drivers": [], "more": False, "cash_week": None}
    if len(text) < 3:
        return empty
    fv = fleet_view()
    crews = {c["id"]: c for c in fv["cars"]}
    plate = norm_plate(text)
    cars = []
    for c in cars_list(False, None):
        if plate and plate in norm_plate(c["plate"]):
            f = crews.get(c["id"])
            cars.append(dict(c, day=f["day"] if f else None, night=f["night"] if f else None))
    linked = {r["driver_id"] for r in q("SELECT driver_id FROM tg_users WHERE driver_id IS NOT NULL")}
    n = norm_name(text)
    drivers = []
    for d in drivers_list("active", "rent"):
        if n in norm_name(d["name"]):
            drivers.append({"id": d["id"], "name": d["name"], "kind": "rent", "phone": d["phone"], "city": None,
                            "plate": d["plate"], "shift": None, "cash": None, "tg": d["id"] in linked})
    for d in fv["drivers"]:
        if n in norm_name(d["name"]):
            drivers.append({"id": d["id"], "name": d["name"], "kind": "fleet", "phone": d["phone"], "city": d["city"],
                            "plate": d["plate"], "shift": d["shift"], "cash": d["cash"], "tg": d["tg"]})
    return {"cars": cars[:limit], "drivers": drivers[:limit], "more": len(cars) > limit or len(drivers) > limit,
            "cash_week": fv["cash_week"]}


# ---- OC / przegląd: przypomnienia bota i "Zrobione" (nowa data)
DOC_COLS = {"oc": ("oc_until", "OC"), "prz": ("przeglad_until", "Przegląd")}
DOC_REMIND_DAYS = 30
DOC_MAX_YEARS = 5


def doc_reminders_due(days=DOC_REMIND_DAYS):
    """Aktywne samochody z OC/przeglądem za <= days dni albo po terminie (pusta data = bez przypomnień)."""
    out = []
    for r, label, until, left in due_docs(days=days):
        doc = "oc" if label == "OC" else "prz"
        out.append({"car_id": r["id"], "plate": r["plate"], "doc": doc, "label": label, "until": until, "days": left})
    return out


def parse_day(text):
    """'15.11.2026', '5.1.2027', '2026-11-15' -> date albo None."""
    s = (text or "").strip()
    m = re.fullmatch(r"(\d{1,2})[./-](\d{1,2})[./-](\d{4})", s)
    try:
        if m:
            return dt.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
        return dt.date.fromisoformat(s)
    except ValueError:
        return None


def doc_info(car_id, doc):
    if doc not in DOC_COLS:
        raise UserError("Nieznany dokument.")
    col, label = DOC_COLS[doc]
    rows = q("SELECT id, plate, %s AS until FROM cars WHERE id=? AND active=1" % col, (int(car_id),))
    if not rows:
        raise UserError("Samochód nie istnieje.")
    r = _d(rows[0])
    return {"car_id": r["id"], "plate": r["plate"], "doc": doc, "label": label, "until": r["until"],
            "days": days_left(r["until"])}


def doc_done(car_id, doc, new_until, done_by=None):
    """Nowa data OC/przeglądu: zapis w samochodzie + wpis w historii samochodu + doc_reminders (jedna transakcja)."""
    info = doc_info(car_id, doc)
    d = new_until if isinstance(new_until, dt.date) else parse_day(new_until)
    if d is None:
        raise UserError("Nieprawidłowa data.")
    if d <= dt.date.today():
        raise UserError("Data musi być w przyszłości.")
    if d > dt.date.today() + dt.timedelta(days=366 * DOC_MAX_YEARS):
        raise UserError("Data jest zbyt odległa.")
    col = DOC_COLS[doc][0]
    new = d.isoformat()
    old = info["until"]
    text = "%s ważne do %s (było: %s)" % (info["label"], d.strftime("%d.%m.%Y"),
                                           dt.date.fromisoformat(old).strftime("%d.%m.%Y") if old else "brak")
    tx([("UPDATE cars SET %s=? WHERE id=?" % col, (new, info["car_id"])),
        comment_stmt(info["car_id"], text),
        ("INSERT INTO doc_reminders(car_id,doc,old_until,new_until,done_by,done_at) VALUES(?,?,?,?,?,?)",
         (info["car_id"], doc, old, new, done_by, now()))])
    return dict(info, old=old, until=new, days=days_left(new))


BOT_USERNAME = "LightPartnerBiuroBot"


def tg_link_code(driver_id):
    """Jednorazowy kod i link do bota dla kierowcy (z programu)."""
    c = link_code_create("driver", None, driver_id)
    c["link"] = "https://t.me/%s?start=%s" % (BOT_USERNAME, c["code"])
    return c

CAR_CHILDREN = ["assignments", "fleet_crews", "comments", "mileage_log", "weekly", "repairs", "photos"]


def delete_info(table, iid):
    """Co zostanie usunięte - do okna potwierdzenia."""
    if table == "assignments":
        r = q("SELECT d.name, c.plate, a.start_date, a.end_date FROM assignments a JOIN drivers d ON d.id=a.driver_id "
              "JOIN cars c ON c.id=a.car_id WHERE a.id=?", (iid,))
        return ["%s · %s · %s" % (r[0]["name"], r[0]["plate"], _span(r[0]))] if r else []
    if table == "drivers":
        r, n = qb([("SELECT name FROM drivers WHERE id=?", (iid,)),
                   ("SELECT (SELECT COUNT(*) FROM assignments WHERE driver_id=?) + (SELECT COUNT(*) FROM fleet_crews WHERE driver_id=?) AS n",
                    (iid, iid))])
        return ["Kierowca: %s" % r[0]["name"], "Okresy na samochodach: %d" % n[0]["n"]] if r else []
    if table == "cars":
        res = qb([("SELECT plate, model FROM cars WHERE id=?", (iid,))] +
                 [("SELECT COUNT(*) AS n FROM %s WHERE car_id=?" % t, (iid,)) for t in CAR_CHILDREN])
        if not res[0]:
            return []
        n = dict(zip(CAR_CHILDREN, (x[0]["n"] for x in res[1:])))
        return ["Samochód: %s %s" % (res[0][0]["plate"], res[0][0]["model"] or ""),
                "Okresy kierowców: %d, płatności tygodniowe: %d" % (n["assignments"] + n["fleet_crews"], n["weekly"]),
                "Notatki: %d, naprawy: %d, zdjęcia: %d" % (n["comments"], n["repairs"], n["photos"])]
    if table == "contractors":
        r, cars, n = qb([("SELECT name FROM contractors WHERE id=?", (iid,)), ("SELECT plate FROM cars WHERE contractor_id=?", (iid,)),
                         ("SELECT COUNT(*) AS n FROM payments WHERE contractor_id=?", (iid,))])
        if cars:
            raise UserError("Kontrahent ma samochody: %s. Najpierw zmień kontrahenta w tych samochodach." % ", ".join(c["plate"] for c in cars))
        return ["Kontrahent: %s" % r[0]["name"], "Płatności: %d" % n[0]["n"]] if r else []
    if table == "cash_entries":
        r = q("SELECT d.name, e.week_start, e.kind, e.amount FROM cash_entries e JOIN drivers d ON d.id=e.driver_id WHERE e.id=?", (iid,))
        return ["%s · %s · %s %.2f zł" % (r[0]["name"], r[0]["week_start"], CASH_KINDS[r[0]["kind"]], r[0]["amount"])] if r else []
    if table == "payments":
        r = q("SELECT k.name, p.period, p.amount FROM payments p JOIN contractors k ON k.id=p.contractor_id WHERE p.id=?", (iid,))
        return ["%s · %s · %.2f zł" % (r[0]["name"], r[0]["period"], r[0]["amount"] or 0)] if r else []
    raise UserError("Nieznany typ.")


def delete_record(table, iid, password, new_password=False):
    """Usuwa błędny wpis na zawsze (z hasłem)."""
    stmts = _password_stmts(password, new_password)
    if not delete_info(table, iid):
        raise UserError("Wpis nie istnieje.")
    if table == "drivers":
        stmts += [("DELETE FROM assignments WHERE driver_id=?", (iid,)), ("DELETE FROM fleet_crews WHERE driver_id=?", (iid,)),
                  ("DELETE FROM fleet_cash WHERE driver_id=?", (iid,)), ("DELETE FROM cash_entries WHERE driver_id=?", (iid,))]
    elif table == "cars":
        stmts += [("DELETE FROM %s WHERE car_id=?" % t, (iid,)) for t in CAR_CHILDREN]
    elif table == "contractors":
        stmts.append(("DELETE FROM payments WHERE contractor_id=?", (iid,)))
    stmts.append(("DELETE FROM %s WHERE id=?" % table, (iid,)))
    tx(stmts)
    return True


def week_stmt(car_id, mon, **f):
    cols = ", ".join(f)
    upd = ", ".join("%s=excluded.%s" % (k, k) for k in f)
    return ("INSERT INTO weekly(car_id,week_start,%s) VALUES(?,?,%s) ON CONFLICT(car_id,week_start) DO UPDATE SET %s"
            % (cols, ",".join("?" * len(f)), upd), (car_id, mon) + tuple(f.values()))


def set_week(d):
    mon = monday_of(parse_date(d.get("monday"), dt.date.today())).isoformat()
    cid = d["car_id"]
    if "paid" in d:
        if d["paid"]:
            if d.get("amount") in (None, ""):
                r = q("SELECT rent_week FROM cars WHERE id=?", (cid,))
                amount = (r[0]["rent_week"] or 0) if r else 0
            else:
                amount = flt(d["amount"])
            if amount is None or amount < 0:
                raise UserError("Podaj kwotę.")
            date = d.get("paid_at") or today()
            if not valid_date(date):
                raise UserError("Nieprawidłowa data.")
            ex(*week_stmt(cid, mon, paid=1, paid_at=date, amount=amount))
        else:
            ex(*week_stmt(cid, mon, paid=0, paid_at=None, amount=None))
    if "comment" in d:
        ex(*week_stmt(cid, mon, comment=(d["comment"] or "").strip()))
    if "km" in d:
        set_mileage(cid, d["km"], week=mon)
    return True


def set_mileage(cid, km, week=None):
    km = num(km)
    if km is None:
        raise UserError("Wpisz liczbę.")
    tx([("UPDATE cars SET mileage=? WHERE id=?", (km, cid)),
        ("INSERT INTO mileage_log(car_id,created_at,km) VALUES(?,?,?)", (cid, now(), km)),
        week_stmt(cid, week, km=km) if week else None])
    return km


def oil_done(cid, km):
    km = num(km)
    if km is None:
        raise UserError("Wpisz liczbę.")
    c = q("SELECT mileage FROM cars WHERE id=?", (cid,))[0]
    tx([("UPDATE cars SET oil_last_km=?, mileage=MAX(mileage,?) WHERE id=?", (km, km, cid)),
        ("INSERT INTO mileage_log(car_id,created_at,km) VALUES(?,?,?)", (cid, now(), km)) if km > c["mileage"] else None,
        comment_stmt(cid, "Wymiana oleju przy %d km" % km)])
    return km


def add_repair(cid, text, cost=None):
    text = (text or "").strip()
    if not text:
        raise UserError("Opisz naprawę.")
    return ex("INSERT INTO repairs(car_id,created_at,text,cost) VALUES(?,?,?,?)", (cid, now(), text, flt(cost)))


def done_repair(rid, date, cost=None):
    if not valid_date(date):
        raise UserError("Podaj datę.")
    r = q("SELECT car_id, text FROM repairs WHERE id=?", (rid,))
    if not r:
        raise UserError("Naprawa nie istnieje.")
    tx([("UPDATE repairs SET done_at=?, cost=COALESCE(?, cost) WHERE id=?", (date, flt(cost), rid)),
        comment_stmt(r[0]["car_id"], "Naprawa wykonana: %s" % r[0]["text"])])
    return True


def add_comment(cid, text):
    text = (text or "").strip()
    if not text:
        raise UserError("Wpisz treść.")
    ex(*comment_stmt(cid, text))
    return True


def import_rows(rows):
    kontr, plates = qb([("SELECT name, contact FROM contractors", ()), ("SELECT plate FROM cars", ())])
    known = {r["name"]: r["contact"] for r in kontr}
    have = {norm_plate(r["plate"]) for r in plates}
    stmts, nk, nc, skip = [], 0, 0, 0
    for r in rows:
        r = {(k or "").strip().lower(): (str(v) if v is not None else "").strip() for k, v in r.items()}
        plate, name, tel = norm_plate(r.get("numer")), r.get("kontrahent", ""), r.get("telefon", "")
        if not plate or not name:
            continue
        if name not in known:
            stmts.append(("INSERT INTO contractors(name,contact) VALUES(?,?)", (name, tel)))
            known[name] = tel
            nk += 1
        elif tel and not known[name]:
            stmts.append(("UPDATE contractors SET contact=? WHERE name=?", (tel, name)))
            known[name] = tel
        if plate in have:
            skip += 1
            continue
        have.add(plate)
        stmts.append(("INSERT INTO cars(plate,model,contractor_id,mileage,oil_last_km,rent_week) "
                      "VALUES(?,?,(SELECT id FROM contractors WHERE name=?),?,?,?)",
                      (plate, r.get("marka", ""), name, num(r.get("przebieg"), 0), num(r.get("olej_km"), 0), flt(r.get("czynsz")))))
        nc += 1
    tx(stmts)
    return {"contractors": nk, "cars": nc, "skipped": skip}


def import_csv_text(raw):
    import csv
    lines = (raw or "").lstrip("﻿").splitlines()
    if not lines:
        raise UserError("Plik jest pusty.")
    delim = ";" if ";" in lines[0] else ","
    return import_rows(list(csv.DictReader(lines, delimiter=delim)))


def week_csv(day=None):
    import csv
    import io
    w = week_view(day)
    buf = io.StringIO()
    out = csv.writer(buf, delimiter=";")
    out.writerow(["Tydzień", "Nr rej.", "Model", "Kierowca", "Płatność", "Stawka", "Zapłacono", "Kwota zapłacona", "Data",
                  "Przebieg", "Komentarz"])
    for r in w["rows"]:
        out.writerow([w["number"], r["plate"], r["model"], r["driver"], PAY_TYPES.get(r["pay_type"], ""), money(r["rent"]),
                      "tak" if r["paid"] else "nie", money(r["amount"]) if r["paid"] else "", r["paid_at"] or "",
                      r["km"] if r["km"] is not None else "", r["comment"]])
    return {"name": "tydzien_%d_%s.csv" % (w["number"], w["monday"]), "text": buf.getvalue()}


# ---- użytkownicy bota Telegram
BOT_LANGS = ("pl", "ru", "uk")


def tg_lang(telegram_id):
    r = q("SELECT lang FROM tg_users WHERE telegram_id=?", (int(telegram_id),))
    return r[0]["lang"] if r else None


def tg_set_lang(telegram_id, lang):
    if lang not in BOT_LANGS:
        raise UserError("Nieznany język.")
    ex("INSERT INTO tg_users(telegram_id,lang,created_at) VALUES(?,?,?) "
       "ON CONFLICT(telegram_id) DO UPDATE SET lang=excluded.lang, updated_at=?", (int(telegram_id), lang, now(), now()))
    return lang


def tg_user(telegram_id):
    """Rola użytkownika bota: {'lang', 'role' ('office'/'driver'/None), 'driver_id', 'driver'}."""
    r = q("SELECT u.lang, u.role, u.driver_id, d.name AS driver FROM tg_users u LEFT JOIN drivers d ON d.id=u.driver_id "
          "WHERE u.telegram_id=?", (int(telegram_id),))
    return _d(r[0]) if r else {"lang": None, "role": None, "driver_id": None, "driver": None}


def tg_office_ids():
    return [r["telegram_id"] for r in q("SELECT telegram_id FROM tg_users WHERE role='office'")]


# ---- kolejka wiadomości bota (outbox) i wykonane zadania (job_runs)
OUTBOX_MAX_ATTEMPTS = 10


def outbox_add(chat_id, text, key=None, buttons=None, send_after=None):
    """Wiadomość do wysłania. key = klucz bez duplikatów (ta sama wiadomość dwa razy się nie doda). Zwraca id albo None."""
    if not text or not str(text).strip():
        raise UserError("Pusta wiadomość.")
    btn = json.dumps(buttons, ensure_ascii=False) if buttons else None
    if key and q("SELECT 1 FROM outbox WHERE dedupe_key=?", (key,)):
        return None
    try:
        return ex("INSERT INTO outbox(dedupe_key,chat_id,text,buttons,created_at,send_after) VALUES(?,?,?,?,?,?)",
                  (key, int(chat_id), text, btn, now_s(), send_after))
    except sqlite3.IntegrityError:  # ten sam klucz dodany równolegle
        return None


def outbox_due(limit=20):
    rows = q("SELECT id, chat_id, text, buttons, attempts FROM outbox WHERE sent_at IS NULL AND failed=0 "
             "AND (send_after IS NULL OR send_after<=?) ORDER BY id LIMIT ?", (now_s(), int(limit)))
    return [dict(_d(r), buttons=json.loads(r["buttons"]) if r["buttons"] else None) for r in rows]


def outbox_sent(oid, message_id=None):
    ex("UPDATE outbox SET sent_at=?, message_id=?, attempts=attempts+1, last_error=NULL WHERE id=?", (now_s(), message_id, oid))


def outbox_failed(oid, error, permanent=False):
    """Błąd wysyłki. permanent (np. czat nie istnieje) albo po OUTBOX_MAX_ATTEMPTS próbach - więcej nie próbujemy."""
    ex("UPDATE outbox SET attempts=attempts+1, last_error=?, failed=CASE WHEN ? OR attempts+1>=? THEN 1 ELSE 0 END WHERE id=?",
       (str(error)[:500], 1 if permanent else 0, OUTBOX_MAX_ATTEMPTS, oid))


def job_done(name, period):
    return bool(q("SELECT 1 FROM job_runs WHERE name=? AND period=?", (name, period)))


def job_mark(name, period, result=None):
    ex("INSERT OR IGNORE INTO job_runs(name,period,done_at,result) VALUES(?,?,?,?)", (name, period, now_s(), result))


def now_s(delta_seconds=0):
    return (dt.datetime.now() + dt.timedelta(seconds=delta_seconds)).strftime("%Y-%m-%d %H:%M:%S")


# ---- zamek "działa tylko jeden bot": właściciel odświeża znacznik; nieodświeżany przez LOCK_STALE s - wygasa
LOCK_STALE = 120


def bot_lock_acquire(owner, name="bot"):
    """True = zamek nasz. False = inny bot działa (świeży znacznik). Jedno UPDATE - bez wyścigu."""
    ex("INSERT OR IGNORE INTO bot_lock(name,owner,heartbeat_at) VALUES(?,NULL,'')", (name,))
    ex("UPDATE bot_lock SET owner=?, heartbeat_at=? WHERE name=? AND (owner=? OR owner IS NULL OR heartbeat_at<?)",
       (owner, now_s(), name, owner, now_s(-LOCK_STALE)))
    return bot_lock_holder(name)["owner"] == owner


def bot_lock_refresh(owner, name="bot"):
    """False = zamek przejął ktoś inny (np. ten bot był zawieszony dłużej niż LOCK_STALE)."""
    ex("UPDATE bot_lock SET heartbeat_at=? WHERE name=? AND owner=?", (now_s(), name, owner))
    return bot_lock_holder(name)["owner"] == owner


def bot_lock_release(owner, name="bot"):
    ex("UPDATE bot_lock SET owner=NULL, heartbeat_at='' WHERE name=? AND owner=?", (name, owner))


def bot_lock_holder(name="bot"):
    r = q("SELECT owner, heartbeat_at FROM bot_lock WHERE name=?", (name,))
    return _d(r[0]) if r else {"owner": None, "heartbeat_at": None}


CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # bez O/0, I/1 - łatwo przepisać
CODE_LEN = 8
CODE_HOURS = 24


def _code_hash(code):
    return hashlib.sha256(re.sub(r"[^A-Z0-9]", "", (code or "").upper()).encode()).hexdigest()


def link_code_create(kind, created_by, driver_id=None):
    """Jednorazowy kod przypięcia Telegrama: kind 'driver' (do kierowcy) albo 'office' (pracownik biura).
    W bazie tylko skrót (SHA-256); kod w czystej postaci zwracany raz."""
    import secrets
    if kind not in ("driver", "office"):
        raise UserError("Nieznany typ kodu.")
    if kind == "driver" and not q("SELECT 1 FROM drivers WHERE id=? AND active=1", (driver_id,)):
        raise UserError("Kierowca nie istnieje.")
    code = ""
    while not re.search(r"\d", code):  # zawsze z cyfrą (bot rozpoznaje kod po cyfrze)
        code = "".join(secrets.choice(CODE_CHARS) for _ in range(CODE_LEN))
    expires = (dt.datetime.now() + dt.timedelta(hours=CODE_HOURS)).strftime("%Y-%m-%d %H:%M")
    ex("INSERT INTO link_codes(code_hash,kind,driver_id,created_by,created_at,expires_at) VALUES(?,?,?,?,?,?)",
       (_code_hash(code), kind, driver_id if kind == "driver" else None, created_by, now(), expires))
    return {"code": code, "expires_at": expires}


def link_code_use(telegram_id, code):
    """Wpisany kod -> rola. Kierowca może mieć tylko jeden Telegram: poprzednie przypięcie jest zdejmowane."""
    r = q("SELECT c.id, c.kind, c.driver_id, c.expires_at, c.used_at, d.name, d.active FROM link_codes c "
          "LEFT JOIN drivers d ON d.id=c.driver_id WHERE c.code_hash=?", (_code_hash(code),))
    if not r:
        raise UserError("Nieprawidłowy kod.")
    c = r[0]
    if c["used_at"]:
        raise UserError("Kod został już użyty.")
    if c["expires_at"] < now():
        raise UserError("Kod wygasł.")
    if c["kind"] == "driver" and not c["active"]:
        raise UserError("Kierowca nie istnieje.")
    tid = int(telegram_id)
    role, did = ("driver", c["driver_id"]) if c["kind"] == "driver" else ("office", None)
    tx([("UPDATE tg_users SET driver_id=NULL, role=NULL, updated_at=? WHERE driver_id=? AND telegram_id<>?", (now(), did, tid)) if did else None,
        ("INSERT INTO tg_users(telegram_id,role,driver_id,created_at) VALUES(?,?,?,?) ON CONFLICT(telegram_id) "
         "DO UPDATE SET role=excluded.role, driver_id=excluded.driver_id, updated_at=?", (tid, role, did, now(), now())),
        ("UPDATE link_codes SET used_at=?, used_by=? WHERE id=?", (now(), tid, c["id"]))])
    return {"role": role, "driver_id": did, "driver": c["name"] if did else None}


def db_empty():
    return not q("SELECT (SELECT COUNT(*) FROM cars) + (SELECT COUNT(*) FROM contractors) AS n")[0]["n"]


# ---- zdjęcia auta (z karty)
def photo_label(n):
    m = re.match(r"(\d{4})(\d{2})(\d{2})_(\d{2})(\d{2})\d{2}_(.*)", n)
    return ("%s.%s.%s %s:%s" % (m[3], m[2], m[1], m[4], m[5])) if m else n


def car_photos(cid):
    out = []
    for n in DBX.photo_list(cid):
        thumb = None
        try:
            from PIL import Image
            import io
            im = Image.open(DBX.photo_get(cid, n))
            im.thumbnail((360, 240))
            buf = io.BytesIO()
            im.convert("RGB").save(buf, "JPEG", quality=80)
            thumb = "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
        except Exception:
            pass
        out.append({"name": n, "label": photo_label(n), "thumb": thumb})
    return out


def add_photo(cid, filename, b64):
    tmp = os.path.join(DATA, "tmp", "upload")
    os.makedirs(tmp, exist_ok=True)
    path = os.path.join(tmp, os.path.basename(filename or "foto.jpg"))
    with open(path, "wb") as fh:
        fh.write(base64.b64decode(b64.split(",", 1)[-1]))
    try:
        return DBX.photo_put(cid, path)
    finally:
        os.remove(path)


def open_photo(cid, name):
    open_file(DBX.photo_get(cid, name))
    return True


def send_photos(cid, names, channel, text):
    c = q("SELECT c.plate, k.name, k.contact FROM cars c LEFT JOIN contractors k ON k.id=c.contractor_id WHERE c.id=?", (cid,))
    phone = normalize_phone(c[0]["contact"]) if c else ""
    if not phone:
        raise UserError("Kontrahent nie ma numeru telefonu.")
    if not names:
        raise UserError("Zaznacz zdjęcia.")
    paths = [DBX.photo_get(cid, n) for n in names]
    copied = copy_files_to_clipboard(paths)
    open_chat(channel, phone, text)
    ex(*comment_stmt(cid, "Zdjęcia dla kontrahenta %s (%s): %d szt." % (c[0]["name"], channel, len(names))))
    return {"copied": copied, "folder": os.path.dirname(paths[0])}
